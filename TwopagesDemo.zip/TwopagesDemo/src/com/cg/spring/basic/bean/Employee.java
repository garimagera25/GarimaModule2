package com.cg.spring.basic.bean;

import java.util.ArrayList;

import org.springframework.beans.factory.InitializingBean;

public class Employee {
//	 implements InitializingBean
	private String empName;
	Department dept;
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public Department getDept() {
		return dept;
	}
	public void setDept(Department dept) {
		this.dept = dept;
	}
	/******************************Autowiring********************/
//	public Employee(Department d)
//	{
//		System.out.println("welcome to constrcutor made for autowiring");
//		dept =d;
//	}
	public Employee(String empName, Department dept) {
		super();
		this.empName = empName;
		this.dept = dept;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
//	public void allocate()
//	{
//		
//	}
//	public void release()
//	{
//		
//	}
	@Override
	public String toString() {
		return "Employee [empName=" + empName + ", dept=" + dept + "]";
	}
	
	/***********everytime employee object is called it will be called automatically uncomment implements InitializingBean  **********************/
//	@Override
//	public void afterPropertiesSet() throws Exception {
//		// TODO Auto-generated method stub
//		
//	}

	

}
