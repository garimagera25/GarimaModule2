package com.cg.spring.basic.pl;



import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.cg.spring.basic.bean.Employee;
@SuppressWarnings("deprecation")
public class Client {
	public static void main(String[] args) {
		/****************************standard**********/
			//		Employee emp = new Employee();
		
		
		
		/********************spring container should create Employee Object*******/
		
		
		Resource resource = new ClassPathResource("beans.xml");
		XmlBeanFactory factory = new XmlBeanFactory(resource);
		
		
		/*******************************************************application context****************/
		//ApplicationContext  context = new ClassPathXmlApplicationContext("beans.xml");
		//Employee emp = (Employee)context.getBean("emp");
		
		
		Employee emp = (Employee)factory.getBean("emp");
		System.out.println(emp.getEmpName());
		System.out.println(emp.getDept());
	}
}
