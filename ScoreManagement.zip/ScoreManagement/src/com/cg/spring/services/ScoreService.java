package com.cg.spring.services;

import java.util.List;

import com.cg.spring.entities.ScoreDetails;
import com.cg.spring.entities.TraineeDetails;
import com.cg.spring.exceptions.ScrException;

public interface ScoreService {

	List<TraineeDetails> getTraineeId();

	ScoreDetails addScoreDetails(ScoreDetails score) throws ScrException;
	public int countRecord(int tarineeid,String name);

	


}
