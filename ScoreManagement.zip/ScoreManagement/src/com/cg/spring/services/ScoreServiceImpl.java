package com.cg.spring.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.spring.dao.ScoreDao;
import com.cg.spring.entities.ScoreDetails;
import com.cg.spring.entities.TraineeDetails;
import com.cg.spring.exceptions.ScrException;
@Transactional
@Service
public class ScoreServiceImpl implements ScoreService {
	@Autowired
	ScoreDao dao;
	
	@Override
	public List<TraineeDetails> getTraineeId() {
		// TODO Auto-generated method stub
		return dao.getTraineeId();
	}
	public int gradeCalculate(ScoreDetails score)
	{
		//System.out.println(score);
		double total =score.getMpt()+score.getMtt()+score.getAssMarks();
		score.setTotal(total);		
		int grade=0;
		if(total<49&& total>0)
		{
			 grade=0;
		}
		else if(total<59&&total>50)
		{
			grade=1;
			
		}
		else if(total<69&&total>=60)
		{
			grade=2;
			
		}
		else if(total<79&&total>=70)
		{
			grade=3;
			
		}
		else if(total<89&&total>=80)
		{
			grade=4;
			
		}
		else if(total<100&&total>=90)
		{
			grade=5;
			
		}
		
		
		return grade;
	}
	@Override
	public ScoreDetails addScoreDetails(ScoreDetails score) throws ScrException {
		
		int grade= gradeCalculate(score);
		score.setGrade(grade);
		System.out.println("in service class  .. "+ score.getTno());
		return dao.addScoreDetails(score);
		/*//try{
		int count=countRecord(score.getTno(),score.getMname());
		//return score1;
		if(count >= 1)
		{
			System.out.println("Checking named queries  already exist");
			throw new ScrException("problem in fetching list");			
		}
		else
		{
			System.out.println("continue inserting  ");
			return dao.addScoreDetails(score);
		}	*/
		//}
//		catch (Exception e) {
//			throw new ScrException("problem in fetching data");
//		}
		
	}
	@Override
	public int countRecord(int traineeid,String mname) {
		// TODO Auto-generated method stub
		System.out.println("in count record method...");
		return dao.countRecord(traineeid ,mname);
	}

	

}
