package com.cg.spring.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

@Entity

//@NamedQueries({
//    @NamedQuery(name="Country.findAll",
//                query="SELECT c FROM Country c"),
//    @NamedQuery(name="Country.findByName",
//                query="SELECT c FROM Country c WHERE c.name = :name"),
//}) 
//Query query = em.createNamedQuery("SELECT c FROM Country c");
//List results = query.getResultList();

@Table(name="ScoreDetails")
@SequenceGenerator(name="scoresno_id_seq",sequenceName="sno_seq")
public class ScoreDetails {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="scoresno_id_seq")
	@Column(name="sno")
	private int sno;
	@Column(name="trainee_id")
	private int tno;
	@Column(name="module_name")
	private String mname;
	 @NotNull @Min(0) @Max(70)
	@Column(name="mpt")
	private int mpt;
	 @NotNull @Min(0) @Max(15)
	@Column(name="mtt")
	private int mtt;
	 @NotNull @Min(0) @Max(15)
	@Column(name="ass_marks")
	private double assMarks;
	@Column(name="total")
	private double total;
	@Column(name="grade")
	private int grade;
	
	
	public ScoreDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getSno() {
		return sno;
	}
	public void setSno(int sno) {
		this.sno = sno;
	}
	
	public int getTno() {
		return tno;
	}
	public void setTno(int tno) {
		this.tno = tno;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public int getMpt() {
		return mpt;
	}
	public void setMpt(int mpt) {
		this.mpt = mpt;
	}
	public int getMtt() {
		return mtt;
	}
	public void setMtt(int mtt) {
		this.mtt = mtt;
	}
	public double getAssMarks() {
		return assMarks;
	}
	public void setAssMarks(double assMarks) {
		this.assMarks = assMarks;
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}
	@Override
	public String toString() {
		return "ScoreDetails [sno=" + sno + ", tno=" + tno + ", mname=" + mname
				+ ", mpt=" + mpt + ", mtt=" + mtt + ", assMarks=" + assMarks
				+ ", total=" + total + ", grade=" + grade + "]";
	}
	
	
}
