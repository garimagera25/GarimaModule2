package com.cg.spring.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.spring.entities.ScoreDetails;
import com.cg.spring.entities.TraineeDetails;
import com.cg.spring.exceptions.ScrException;
import com.cg.spring.services.ScoreService;

@Controller
public class ScoreController {
	@Autowired
	ScoreService service;
	
	@RequestMapping("/addPage")
	public String showTraineeId(Model model){
		ScoreDetails score = new ScoreDetails();
		List<TraineeDetails> list=service.getTraineeId();
		model.addAttribute("tlist",list);
		model.addAttribute("score",score);
		return "AddAssessment";
	
	}
	
	@RequestMapping("/addScore")
	public String insertAssessmentScore(Model model , @Valid @ModelAttribute("score") ScoreDetails score,BindingResult result) throws ScrException
	{
		if(result.hasErrors())
		{
			List<TraineeDetails> list=service.getTraineeId();
			model.addAttribute("tlist",list);
			return "AddAssessment";
		}
		else{
			System.out.println("i m in addScore");
			try{
			ScoreDetails score2=service.addScoreDetails(score);
			model.addAttribute("score",score2);
			model.addAttribute("successMsg", "Score Detail Inserted Successfully with grade"+ score2.getGrade());
			return "Success";
			}
			catch(Exception e)
			{
				model.addAttribute("errorMsg", "Score Detail cannot be Inserted with grade");
				return "Success";
			}
			
			
		}
		
		
	}
	
}
