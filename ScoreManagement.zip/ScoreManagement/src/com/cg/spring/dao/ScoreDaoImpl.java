package com.cg.spring.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.spring.entities.ScoreDetails;
import com.cg.spring.entities.TraineeDetails;

@Repository
public class ScoreDaoImpl implements ScoreDao {
	@PersistenceContext
	EntityManager entityManager;
	@Override
	public List<TraineeDetails> getTraineeId() {
		TypedQuery<TraineeDetails> query= entityManager.createQuery("from TraineeDetails",TraineeDetails.class);
		List<TraineeDetails> tlist = query.getResultList();
		System.out.println("in dao impl"+tlist);
		return tlist;
	}
	@Override
	public ScoreDetails addScoreDetails(ScoreDetails score) {
		System.out.println("in dao class "+ score.getTno());
		entityManager.persist(score);
		entityManager.flush();
		return score;
	}
	@Override
	public int countRecord(int traineeid, String mname) {
		
		 System.out.println("in dao class for count..."+traineeid + "  "+ mname);
		 
		 
		TypedQuery<Integer> query = entityManager.createQuery("select count(score) from  ScoreDetails score where score.tno=:no and mname=:name" , Integer.class);
		
		query.setParameter("no", traineeid);
		query.setParameter("name", mname);
		System.out.println("in dao class ");
		
		int count=	query.getSingleResult();
		System.out.println("after getting ");
		return count;
		
//		ScoreDetails score =entityManager.find(ScoreDetails.class,tno,mname);
//		return score;
	}
	
	

}
