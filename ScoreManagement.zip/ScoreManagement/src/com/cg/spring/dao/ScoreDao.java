package com.cg.spring.dao;

import java.util.List;

import com.cg.spring.entities.ScoreDetails;
import com.cg.spring.entities.TraineeDetails;

public interface ScoreDao {
	List<TraineeDetails> getTraineeId();
	
	ScoreDetails addScoreDetails(ScoreDetails score);
	

	int countRecord(int traineeid, String mname);
}
