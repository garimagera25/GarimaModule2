package com.cg.spring.ce.dto;

import java.time.LocalDate;
import java.util.ArrayList;

public class Employee {
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	private int empId;
	private String empName;
	private double salary;
	private ArrayList<String> skills;
	private LocalDate doj;
	public Employee(int id,String name,double sal)
	{
		empId=id;
		empName=name;
		salary = sal;
	}
public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}
public ArrayList<String> getSkills() {
	return skills;
}
public void setSkills(ArrayList<String> skills) {
	this.skills = skills;
}
public LocalDate getDoj() {
	return doj;
}
public void setDoj(LocalDate doj) {
	this.doj = doj;
}

}
