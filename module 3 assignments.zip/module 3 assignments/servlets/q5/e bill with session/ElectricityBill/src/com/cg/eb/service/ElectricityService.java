package com.cg.eb.service;

import com.cg.eb.dto.BillDetails;
import com.cg.eb.exception.BillException;

public interface ElectricityService {
	public int registerDetails(BillDetails bill) throws BillException;
	public String getName(int cusNo) throws BillException;
}
