package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class credentials
 */
@WebServlet("/credentials")
public class CredentialsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CredentialsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String Uname=request.getParameter("Uname");
		String password=request.getParameter("password");
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		

		String target="";
		if(Uname.equals("admin") && password.equals("admin123"))
//			dbUsername.equals(username) && dbPassword.equals(password)
		{
//			out.print("<h2>Username or password correct</h2>");
				target="index.html";
		}
		else
		{
			
				target="credentials.html";
				
		}
		RequestDispatcher disp = request.getRequestDispatcher(target);
		disp.forward(request, response);
		out.print("<h2>Username or password incorrect</h2>");
	}
	

}
