package com.cg.eb.service;


import com.cg.eb.dao.ElectricityDao;
import com.cg.eb.dao.ElectricityDaoImpl;
import com.cg.eb.dto.BillDetails;
import com.cg.eb.exception.BillException;


public class ElectricityServiceImpl implements ElectricityService {
	ElectricityDao Dao= new ElectricityDaoImpl();
	
	public int registerDetails(BillDetails bill) throws BillException {
	
	return Dao.insertDetails(bill);
}

	@Override
	public String getName(int cusNo) throws BillException {
		// TODO Auto-generated method stub
		return Dao.getName(cusNo);
	}

}
