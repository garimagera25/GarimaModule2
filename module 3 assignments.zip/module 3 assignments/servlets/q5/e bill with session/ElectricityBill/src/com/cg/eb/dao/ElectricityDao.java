package com.cg.eb.dao;

import com.cg.eb.dto.BillDetails;
import com.cg.eb.exception.BillException;

public interface ElectricityDao {

	int insertDetails(BillDetails bill) throws BillException;
	String getName(int cusNo) throws BillException;
}
