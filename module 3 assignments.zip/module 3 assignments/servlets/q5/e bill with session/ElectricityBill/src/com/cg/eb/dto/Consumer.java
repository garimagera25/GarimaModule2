package com.cg.eb.dto;

public class Consumer {
private int consumerNo;
private String name;
private String address;

public Consumer() {

	// TODO Auto-generated constructor stub
}

public void setConsumerNo(int consumerNo) {
	this.consumerNo = consumerNo;
}
public int getConsumerNo() {
	return consumerNo;
}

public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}

public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
}
