package com.cg.eb.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.eb.dto.BillDetails;
import com.cg.eb.dto.Consumer;
import com.cg.eb.exception.BillException;


public class ElectricityDaoImpl implements ElectricityDao {
	Connection conn;
	@Override
	public int insertDetails(BillDetails bill) throws BillException {
		
		int r=0;
		//CREATE TABLE BillDetails( bill_num NUMBER(6) PRIMARY KEY, consumer_num NUMBER(6) REFERENCES Consumers(consumer_num), 
//		cur_reading NUMBER(5,2), unitConsumed NUMBER(5,2), netAmount NUMBER(5,2), bill_date DATE DEFAULT SYSDATE); 
//		CREATE SEQUENCE seq_bill_num START WITH 100;
		
		String insQry=
				"INSERT INTO BillDetails (bill_num, consumer_num,cur_reading ,unitConsumed,netAmount,bill_date) values (seq_bill_num.nextval,?,?,?,?,?) ";
		int billNum=0;
		
				try {
					conn= DBUtil.getConnection();
					PreparedStatement ps = conn.prepareStatement(insQry);
					
				
			ps.setInt(1, bill.getConsumerNum());
			ps.setDouble(2, bill.getCusReading());
			ps.setDouble(3,bill.getUnitConsumed());
			ps.setDouble(4, bill.getNetAmount());
			ps.setDate(5, Date.valueOf(bill.getBillDate()));
				
					 r= ps.executeUpdate();//when there is integrity constraint this will throw error thats why control to catch
					
					if(r==1){
							Statement st= conn.createStatement();
							ResultSet rs= st.executeQuery("select seq_bill_num.currval from dual");
							if(rs.next())
								billNum=rs.getInt(1);
							else 
							
								throw new BillException("Consumer Number does not exist");
					}
					
					
				} catch (SQLException e) {
					
//					throw new BillException(e.getMessage());
					throw new BillException("Consumer Num does not exist");
					
				}
				return billNum;
				}
	
	//CREATE TABLE Consumers( consumer_num NUMBER(6) PRIMARY KEY, consumer_name VARCHAR2(20) NOT NULL, address VARCHAR2(30) );
	@Override
	public String getName(int cusNo) throws BillException {
		String qry= "SELECT consumer_name FROM Consumers WHERE consumer_num=?";
		Consumer con= new  Consumer();//creating object of consumer
		conn =DBUtil.getConnection();
		
		try {
			PreparedStatement pst = conn.prepareStatement(qry);
			pst.setInt(1, cusNo);
			ResultSet rst = pst.executeQuery();
			if(rst.next())
			{
				con.setName(rst.getString(1));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new BillException("error occured in name");
		}
		
		return con.getName();
	}
		
	}

