package com.cg.eb.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.eb.dto.BillDetails;

/**
 * Servlet implementation class SuccessServlet
 */
@WebServlet("/success")
public class SuccessServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SuccessServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		 BillDetails bill = (BillDetails) request.getAttribute("bill");
		 HttpSession session = request.getSession(false);
		 String cname=(String)request.getAttribute("cname");
		 
		 	out.print("<h1>Welcome "+cname+"</h1>");
			out.print("<h1>Thanks</h1>");
			out.print("<h2>Registered</h2>");
			out.print("<h3>Electricity bill for id:"+bill.getConsumerNum()+"</h3>");
			out.print("<h3>UnitConsumed:"+bill.getUnitConsumed()+"</h3>");
			out.print("<h3>NetAmount:"+bill.getNetAmount()+"</h3>");
			
//			response.sendRedirect("Thankyou");
	}

}
