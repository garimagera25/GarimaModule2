package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.time.LocalDate;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.eb.dto.BillDetails;
import com.cg.eb.exception.BillException;
import com.cg.eb.service.ElectricityService;
import com.cg.eb.service.ElectricityServiceImpl;


/**
 * Servlet implementation class ElectricityBillServlet
 */
@WebServlet("/electricity")
public class ElectricityBillServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ElectricityBillServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	
	 public double calculateBill(double lread,double cread)
		{
		 double netAmount=0;
			//Units consumed = (Last month meter reading) � (Current month meter reading) Net Amount = Unit consumed * 1.15 + Fixed Charge Assume Fixed Charge is always Rs.100.	
						double unitConsumed= cread-lread;
						double r=1.15;
						int fixCharge=100;
						 netAmount = unitConsumed*r+fixCharge;	 	
				 return netAmount;
				
		}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ElectricityService eser = new ElectricityServiceImpl();
		int cno= Integer.parseInt(request.getParameter("cnumber"));
		double lread=Double.valueOf(request.getParameter("lreading"));
		double cread=Double.valueOf(request.getParameter("creading"));
		double unitConsumed=cread-lread;
		double Amount;
		
		 LocalDate date = LocalDate.now();
	
			//calling welcome name function
//		 eser.getName(cnum);
		 
		 
		 
		 String target="";
		 try {
			 if(cread>lread)
			 {
				 Amount = calculateBill(lread, cread);
				 	BillDetails bill = new  BillDetails(cno,  lread,
						 unitConsumed,  Amount,  date);
					request.setAttribute("bill",bill);
					target="success";
					
					String cname=eser.getName(cno);
					HttpSession session = request.getSession(true);
					request.setAttribute("cname", cname);
				
					//calling insert function from service
					eser.registerDetails(bill);		
				
				
			
			
			 }
			 else
			 {
				 throw new BillException("Current reading cannot be less than Last reading");	
				 
			 }
			 }

		 catch(Exception e){
			System.out.println("checking otherwisse");
			 request.setAttribute("message", e.getMessage());
				target="error";
		 }
		
		
		RequestDispatcher disp = request.getRequestDispatcher(target);
			disp.forward(request, response);
		
		
			return;
	}

}
