package com.cg.controller;

import java.io.IOException;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dto.Registration;
import com.cg.exception.RegisterException;
import com.cg.service.RegisterService;
import com.cg.service.RegisterServiceImpl;

/**
 * Servlet implementation class RegisterUserServlet
 */
@WebServlet("/register")
public class RegisterUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterUserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RegisterService rser= new RegisterServiceImpl();
		String fname= request.getParameter("fname");
		String lname= request.getParameter("lname");
		String password= request.getParameter("password");
		String gender= request.getParameter("gender");
		String[] skills=request.getParameterValues("skills");
		String skillset=String.join(",", skills);
		String city=request.getParameter("city");
		
		Registration reg= new Registration(fname,lname,password,gender,skillset,city);
		String target="";
		try {
			rser.registerUser(reg);
			request.setAttribute("REG", reg);
			target="success";
			response.sendRedirect("http://talent.capgemini.com");
		} catch (RegisterException e) {
			// TODO Auto-generated catch block
			request.setAttribute("message", e.getMessage());
			target="error";
			
		}
		RequestDispatcher disp = request.getRequestDispatcher(target);
		disp.forward(request, response);
		
	}

}
