package com.cg.dao;

import com.cg.dto.Registration;
import com.cg.exception.RegisterException;

public interface RegisterDao {

	int insertUser(Registration reg) throws RegisterException;

}
