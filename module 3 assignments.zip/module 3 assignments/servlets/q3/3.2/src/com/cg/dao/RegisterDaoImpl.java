package com.cg.dao;

import java.sql.Array;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cg.dto.Registration;
import com.cg.exception.RegisterException;

public class RegisterDaoImpl implements RegisterDao {
Connection conn;
	@Override
	public int insertUser(Registration reg) throws RegisterException {
		int ct=0;
		//CREATE TABLE RegisteredUsers ( firstname VARCHAR (20), lastname VARCHAR (30), password VARCHAR (12) UNIQUE, gender VARCHAR(2), skillset VARCHAR (40), city VARCHAR (12));
		try {
			
		
			String sql ="INSERT into RegisteredUsers(firstname,lastname,password,gender,skillset,city) VALUES(?,?,?,?,?,?)";
			conn= DBUtil.getConnection();
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setString(1,reg.getFname());
			pst.setString(2,reg.getLname());
			pst.setString(3,reg.getPassword());
			pst.setString(4,reg.getGender());
			pst.setString(5,reg.getSkills());
			pst.setString(6, reg.getCity());
			ct=pst.executeUpdate();
		}
		
		
		catch (SQLException e) {
			throw new RegisterException("Problem in inserting records"+e.getMessage());
		}
		return ct;
	}

}
