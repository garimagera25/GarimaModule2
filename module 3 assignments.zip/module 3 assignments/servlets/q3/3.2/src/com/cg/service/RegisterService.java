package com.cg.service;

import com.cg.dto.Registration;
import com.cg.exception.RegisterException;

public interface RegisterService {

	int registerUser(Registration reg) throws RegisterException;

}
