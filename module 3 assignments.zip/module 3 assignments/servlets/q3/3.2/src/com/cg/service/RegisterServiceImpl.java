package com.cg.service;

import com.cg.dao.RegisterDao;
import com.cg.dao.RegisterDaoImpl;
import com.cg.dto.Registration;
import com.cg.exception.RegisterException;

public class RegisterServiceImpl implements RegisterService {
	RegisterDao   rdao =new RegisterDaoImpl();
	@Override
	public int registerUser(Registration reg) throws RegisterException {
		return rdao.insertUser(reg);
	}

}
