package com.cg.eb.service;

import java.util.List;

import com.cg.eb.dao.EBillDao;
import com.cg.eb.dao.EBillDaoImpl;
import com.cg.eb.dto.EBillDetails;
import com.cg.eb.dto.EConsumer;
import com.cg.eb.exception.EBillException;

public class EBillServiceImpl implements EBillService {
	EBillDao edao = new EBillDaoImpl();
	@Override
	public List<EConsumer> getAllConsumers() throws EBillException {
		
		return edao.getAllConsumers();
	}
	@Override
	public List<EBillDetails> getBillDetails(int cno)
			throws EBillException {
			return edao.getBillDetails(cno);
	}
	@Override
	public EConsumer getConsumerDetails(int cno) throws EBillException {
		// TODO Auto-generated method stub
		return edao.getConsumerDetails(cno);
	}
	@Override
	public String getName(int cno) throws EBillException{
		return edao.getName(cno);
	}
	@Override
	public int registerDetails(EBillDetails bill) throws EBillException {
		return edao.insertDetails(bill);
	}

}
