package com.cg.eb.dto;

public class EConsumer {
	private int consumerNo;
	private String name;
	private String address;
	
	
	
	public EConsumer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getConsumerNo() {
		return consumerNo;
	}
	public void setConsumerNo(int consumerNo) {
		this.consumerNo = consumerNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
}
