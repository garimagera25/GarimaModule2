package com.cg.eb.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;


import com.cg.eb.dto.EBillDetails;
import com.cg.eb.dto.EConsumer;
import com.cg.eb.exception.EBillException;
import com.cg.eb.dao.DBUtil;


public class EBillDaoImpl implements EBillDao {
	Connection conn;
	
	//CREATE TABLE Consumers( consumer_num NUMBER(6) PRIMARY KEY, consumer_name VARCHAR2(20) NOT NULL, address VARCHAR2(30) );
	
	@Override
	public List<EConsumer> getAllConsumers() throws EBillException {
		
		String sql ="SELECT consumer_num,consumer_name,address FROM Consumers";
		List <EConsumer> clist=new ArrayList<EConsumer>();	
		System.out.println("connection est");
		
		try {
			conn=DBUtil.getConnection();
			
			PreparedStatement pst=conn.prepareStatement(sql);
			ResultSet rst=pst.executeQuery();
			
			while(rst.next()){
				EConsumer ec= new EConsumer();
				ec.setConsumerNo(rst.getInt("consumer_num"));
				ec.setName(rst.getString("consumer_name"));
				ec.setAddress(rst.getString("address"));
				
				clist.add(ec);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new EBillException("Problem in fetching details");
			
		}
		return clist;
		
	}
//CREATE TABLE BillDetails( bill_num NUMBER(6) PRIMARY KEY, consumer_num NUMBER(6)
	//REFERENCES Consumers(consumer_num), cur_reading NUMBER(5,2), 
	//unitConsumed NUMBER(5,2), netAmount NUMBER(5,2), bill_date DATE DEFAULT SYSDATE);
	@Override
	public List<EBillDetails> getBillDetails(int cno) throws EBillException {
		// TODO Auto-generated method stub
		String sql="SELECT * FROM BillDetails where consumer_num=?";
		List <EBillDetails> elist=new ArrayList<EBillDetails>();
		EBillDetails ebilldetails=null;
		conn =DBUtil.getConnection();
		try {
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1, cno);
			ResultSet rst = pst.executeQuery();
			
			while(rst.next())
			{
				ebilldetails=new EBillDetails();
				//mobile.setMobileid(rst.getInt("mobileid"));
				ebilldetails.setBillNum(rst.getInt("bill_num"));
				ebilldetails.setConsumerNum(rst.getInt("consumer_num"));
				ebilldetails.setCusReading(rst.getDouble("cur_reading"));
				ebilldetails.setUnitConsumed(rst.getDouble("unitConsumed"));
				ebilldetails.setNetAmount(rst.getDouble("netAmount"));
				ebilldetails.setBillDate(rst.getDate("bill_date").toLocalDate());
				
				
//				Instant instant =Instant.ofEpochMilli(rst.getDate(6).getTime());
//				LocalDateTime localDateTime = LocalDateTime.ofInstant(instant, ZoneId.systemDefault());
//				LocalDate localDate=localDateTime.toLocalDate();
//				
//				ebilldetails.setBillDate(localDate);
				
				elist.add(ebilldetails);
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new EBillException("problem in bill details");
		}
		return elist;
	}
	@Override
	public EConsumer getConsumerDetails(int cno) throws EBillException {
		System.out.println("in dao");
		String sql = "SELECT * from Consumers where consumer_num=?";
		EConsumer econsumer=null;
		conn =DBUtil.getConnection();
		try {
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1, cno);
			ResultSet rst = pst.executeQuery();
			
			if(rst.next())
			{
				System.out.println("execute");
				econsumer = new EConsumer();
				econsumer.setConsumerNo(rst.getInt(1));
				econsumer.setName(rst.getString(2));
				econsumer.setAddress(rst.getString(3));
				System.out.println(econsumer);
			}
			else
			{
				throw new EBillException("Consumer id does not exist");
			}
			
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new EBillException("problem in bill details");
		}
		return econsumer;
	}
	@Override
	public String getName(int cno) throws EBillException {
		String qry= "SELECT consumer_name FROM Consumers WHERE consumer_num=?";
		EConsumer con= new  EConsumer();//creating object of consumer
		
		
		try {
			conn =DBUtil.getConnection();
			PreparedStatement pst = conn.prepareStatement(qry);
			pst.setInt(1, cno);
			ResultSet rst = pst.executeQuery();
			if(rst.next())
			{
				con.setName(rst.getString(1));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new EBillException("error occured in name");
		}
		
		return con.getName();
	}
	@Override
	public int insertDetails(EBillDetails bill) throws EBillException {
		int r=0;
		//CREATE TABLE BillDetails( bill_num NUMBER(6) PRIMARY KEY, consumer_num NUMBER(6) REFERENCES Consumers(consumer_num), 
//		cur_reading NUMBER(5,2), unitConsumed NUMBER(5,2), netAmount NUMBER(5,2), bill_date DATE DEFAULT SYSDATE); 
//		CREATE SEQUENCE seq_bill_num START WITH 100;
		
		String insQry=
				"INSERT INTO BillDetails (bill_num, consumer_num,cur_reading ,unitConsumed,netAmount,bill_date) values (seq_bill_num.nextval,?,?,?,?,?) ";
		int billNum=0;
		
				try {
					conn= DBUtil.getConnection();
					PreparedStatement ps = conn.prepareStatement(insQry);
					
				
			ps.setInt(1, bill.getConsumerNum());
			ps.setDouble(2, bill.getCusReading());
			ps.setDouble(3,bill.getUnitConsumed());
			ps.setDouble(4, bill.getNetAmount());
			ps.setDate(5, Date.valueOf(bill.getBillDate()));
				
					 r= ps.executeUpdate();//when there is integrity constraint this will throw error thats why control to catch
					
					if(r==1){
							Statement st= conn.createStatement();
							ResultSet rs= st.executeQuery("select seq_bill_num.currval from dual");
							if(rs.next())
								billNum=rs.getInt(1);
							else 
							
								throw new EBillException("Consumer Number does not exist");
					}
					
					
				} catch (SQLException e) {
					
//					throw new BillException(e.getMessage());
					throw new EBillException("Consumer Num" +bill.getConsumerNum()+ "does not exist");
					
				}
				return billNum;
				}
	
}
