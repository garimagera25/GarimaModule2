package com.cg.eb.dto;

import java.time.LocalDate;

public class EBillDetails {
	private int billNum;
	private int consumerNum;
	private double cusReading;
	private double unitConsumed;
	private double netAmount;
	private LocalDate billDate;
	
	
	public EBillDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getBillNum() {
		return billNum;
	}
	public void setBillNum(int billNum) {
		this.billNum = billNum;
	}
	public int getConsumerNum() {
		return consumerNum;
	}
	public EBillDetails( int consumerNum, double cusReading,
			double unitConsumed, double netAmount, LocalDate billDate) {
		super();
		this.billNum = billNum;
		this.consumerNum = consumerNum;
		this.cusReading = cusReading;
		this.unitConsumed = unitConsumed;
		this.netAmount = netAmount;
		this.billDate = billDate;
	}
	public void setConsumerNum(int consumerNum) {
		this.consumerNum = consumerNum;
	}
	public double getCusReading() {
		return cusReading;
	}
	public void setCusReading(double cusReading) {
		this.cusReading = cusReading;
	}
	public double getUnitConsumed() {
		return unitConsumed;
	}
	public void setUnitConsumed(double unitConsumed) {
		this.unitConsumed = unitConsumed;
	}
	public double getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(double netAmount) {
		this.netAmount = netAmount;
	}
	public LocalDate getBillDate() {
		return billDate;
	}
	public void setBillDate(LocalDate billDate) {
		this.billDate = billDate;
	}	
}
