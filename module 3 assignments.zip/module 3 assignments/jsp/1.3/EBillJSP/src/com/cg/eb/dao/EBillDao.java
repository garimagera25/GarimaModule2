package com.cg.eb.dao;

import java.util.List;

import com.cg.eb.dto.EBillDetails;
import com.cg.eb.dto.EConsumer;
import com.cg.eb.exception.EBillException;

public interface EBillDao {

	List<EConsumer> getAllConsumers() throws EBillException;

	List<EBillDetails> getBillDetails(int cno) throws EBillException;
	
	EConsumer getConsumerDetails(int cno) throws EBillException;

	String getName(int cno) throws EBillException;

	int insertDetails(EBillDetails bill) throws EBillException;
}
