package com.cg.spring.spel;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class Client {
public static void main(String[] args) {
	ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
	City city = (City) context.getBean("city");
	System.out.println("City Name at 2nd :"+ city.getName());
	System.out.println("State at3rd  :"+city.getState());
	System.out.println("Population at 0: "+city.getPopulation());
	
	System.out.println("reading jdbc property file  ");
	DatabbaseConnection connection = (DatabbaseConnection) context.getBean("dbconnection");
	System.out.println(connection.getUrl());
	System.out.println(connection.getUsername());
	System.out.println(connection.getPassword());
	
	

}
}
