package com.cg.spring.dao;

import java.util.List;

import com.cg.spring.entities.BookingDetails;
import com.cg.spring.entities.HotelDetails;

public interface HotelDao {
	List<HotelDetails> retrieveAllHotels();
	HotelDetails displayHotel(String hotelName);
	HotelDetails displayHotelInt(int hotelId);
	BookingDetails addBooking(BookingDetails bookingdetails);
	HotelDetails getHotelDetails(int hotelId);
}
