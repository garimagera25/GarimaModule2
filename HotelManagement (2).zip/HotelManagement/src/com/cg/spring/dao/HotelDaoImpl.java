package com.cg.spring.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.spring.entities.BookingDetails;
import com.cg.spring.entities.HotelDetails;
@Repository
public class HotelDaoImpl implements HotelDao {
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public List<HotelDetails> retrieveAllHotels() {
		TypedQuery<HotelDetails> query= entityManager.createQuery("from HotelDetails",HotelDetails.class);
		List<HotelDetails> hlist = query.getResultList();
		
		return hlist;
	}

	@Override
	public HotelDetails displayHotel(String hotelName) {
		HotelDetails hoteldetails = entityManager.find(HotelDetails.class, hotelName);
		
		return hoteldetails;	
	}
	public HotelDetails displayHotelInt(int hotelId) {
		HotelDetails hoteldetails = entityManager.find(HotelDetails.class, hotelId);
		
		return hoteldetails;	
	}

	@Override
	public BookingDetails addBooking(BookingDetails bookingdetails) {
		entityManager.persist(bookingdetails);
		entityManager.flush();
		return bookingdetails;
	}

	@Override
	public HotelDetails getHotelDetails(int hotelId) {
		HotelDetails hoteldetails =entityManager.find(HotelDetails.class,hotelId);
		return hoteldetails;
	}
}
