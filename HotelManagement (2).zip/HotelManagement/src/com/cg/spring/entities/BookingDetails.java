package com.cg.spring.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;
//create table bookingdetails(id number primary key, customername varchar2(30), hotelid number , todate Date, fromdate Date, noofrooms number);
@Entity
@Table(name="bookingdetails")
@SequenceGenerator(name="booking_id_seq",initialValue=1,allocationSize=100, sequenceName="booking1_id_seq")
public class BookingDetails {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="booking_id_seq")
	@Column(name="id")
private int bookingId;
	
	@NotEmpty(message="customername can not be blank")
	@Column(name="customername")
	
private String customerName;
	
	
	
	@Column(name="hotelid")
	@NotNull
private int hotelId;
	
	
	@Column(name="todate")
private Date toDate;
	@Column(name="fromdate")
private Date fromDate;
	
	@NotNull @Min(1)
	@Column(name="noofrooms")
private int rooms;
public int getBookingId() {
	return bookingId;
}
public void setBookingId(int bookingId) {
	this.bookingId = bookingId;
}
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public int getHotelId() {
	return hotelId;
}
public void setHotelId(int hotelId) {
	this.hotelId = hotelId;
}
public Date getToDate() {
	return toDate;
}
public void setToDate(Date toDate) {
	this.toDate = toDate;
}
public Date getFromDate() {
	return fromDate;
}
public void setFromDate(Date fromDate) {
	this.fromDate = fromDate;
}
public int getRooms() {
	return rooms;
}
public void setRooms(int rooms) {
	this.rooms = rooms;
}
@Override
public String toString() {
	return "BookingDetails [bookingId=" + bookingId + ", customerName="
			+ customerName + ", hotelId=" + hotelId + ", toDate=" + toDate
			+ ", fromDate=" + fromDate + ", rooms=" + rooms + "]";
}	

}
