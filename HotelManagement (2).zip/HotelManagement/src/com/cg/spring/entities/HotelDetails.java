package com.cg.spring.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
//create table hoteldetails (id number primary key,  name varchar2(30), rating  varchar2(10), rate number(8,2), availablerooms number);
import javax.persistence.Table;

@Entity
@Table(name="hoteldetails")
public class HotelDetails {
	@Id
	@Column(name="id")
	private int hotelId;
	@Column(name="name")
	private String hotelName;
	@Column(name="rating")
	private String rating;
	@Column(name="rate")
	private double rate;
	@Column(name="availablerooms")
	private int rooms;
	public int getHotelId() {
		return hotelId;
	}
	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public double getRate() {
		return rate;
	}
	public void setRate(double rate) {
		this.rate = rate;
	}
	public int getRooms() {
		return rooms;
	}
	public void setRooms(int rooms) {
		this.rooms = rooms;
	}
	@Override
	public String toString() {
		return "HotelDetails [hotelId=" + hotelId + ", hotelName=" + hotelName
				+ ", rating=" + rating + ", rate=" + rate + ", rooms=" + rooms
				+ "]";
	}

}
