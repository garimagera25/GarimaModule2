package com.cg.spring.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.dao.HotelDao;
import com.cg.spring.entities.BookingDetails;
import com.cg.spring.entities.HotelDetails;
@Transactional
@Service
public class HotelServiceImpl implements HotelService {
	@Autowired
	HotelDao hdao;
	@Override
	public List<HotelDetails> retrieveAllHotels() {
	return hdao.retrieveAllHotels();
	}
	@Override
	public HotelDetails displayHotel(String hotelName) {
		// TODO Auto-generated method stub
		return hdao.displayHotel(hotelName);
	}
	@Override
	public HotelDetails displayHotelInt(int hotelId) {
		// TODO Auto-generated method stub
		return hdao.displayHotelInt(hotelId);
	}
	@Override
	public BookingDetails addBooking(BookingDetails bookingdetails) {
		// TODO Auto-generated method stub
		return hdao.addBooking(bookingdetails);
	}
	@Override
	public HotelDetails getHotelDetails(int hotelId) {
		// TODO Auto-generated method stub
		return hdao.getHotelDetails(hotelId);
	}

	
}
