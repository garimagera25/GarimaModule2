package com.cg.spring.services;

import java.util.List;

import com.cg.spring.entities.BookingDetails;
import com.cg.spring.entities.HotelDetails;

public interface HotelService {

	List<HotelDetails> retrieveAllHotels();

	HotelDetails displayHotel(String hotelName);

	HotelDetails displayHotelInt(int hotelId);

	BookingDetails addBooking(BookingDetails bookingdetails);

	HotelDetails getHotelDetails(int hotelId);



}
