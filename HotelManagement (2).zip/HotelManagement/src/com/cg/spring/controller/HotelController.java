package com.cg.spring.controller;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.ui.Model;

import com.cg.spring.entities.BookingDetails;
import com.cg.spring.entities.HotelDetails;
import com.cg.spring.services.HotelService;

@Controller

public class HotelController {

 
 
	@Autowired
	HotelService Hservice;
	
	
	@RequestMapping("/toHotelDetailPage")
	public String showHotelDetails(Model model)
	{
		//HotelDetails hoteldetails= new HotelDetails();
		
		List<HotelDetails> hlist = Hservice.retrieveAllHotels();
		model.addAttribute("hlist", hlist);
		//model.addAttribute("hoteldetails",hoteldetails);
		
		return "HotelDetails";
	}

	
	
	@RequestMapping("hotelid")
	//,@ModelAttribute("hoteldetails")
	public String OrderPage1(Model model, HotelDetails hotel) {
		HotelDetails hoteldetails1 = Hservice.displayHotelInt(hotel.getHotelId());
		
		model.addAttribute("hoteldetails", hoteldetails1);
		
		BookingDetails bookingdetails12= new BookingDetails();
		model.addAttribute("bookingdetails",bookingdetails12);
		
		return "HotelBookingPage";
	}
	@RequestMapping("/addBooking")
	public String AddTrainee(Model model, @Valid @ModelAttribute("bookingdetails") BookingDetails bookingdetails ,BindingResult result,@RequestParam("hotelId")int hotelId)
	{
		if(result.hasErrors())
		{
			return "HotelBookingPage";
		}
		else
			{
			BookingDetails booking = Hservice.addBooking(bookingdetails);
			
			HotelDetails hoteldetails2 = Hservice.getHotelDetails(hotelId);
			model.addAttribute("hoteldetails",hoteldetails2);
			model.addAttribute("booking",booking);
			model.addAttribute("SuccessMsg","added");
			return "BookingConfirmation";
			}
	}

}
