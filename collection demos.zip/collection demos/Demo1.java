import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.TreeSet;


public class Demo1 {
	public static void main(String[] args) {
	
		Person p1= new Person("Neha", 4, "AWA123");
		Person p2= new Person("Manisha", 34, "TGS332");
		Person p3= new Person("Sanvi", 5, "TCD452");
		Person p4= new Person("Priya", 32, "UYR462");
		Person  p5= new Person("Rahul", 32,	"NBC342");
		Person p6= new Person("Vihan", 6, "TVWS241");
		
		Person arr[]= new Person[6];
		arr[0]= p1;
		arr[1]= p2;
		arr[2]= p3;
		arr[3]= p4;
		arr[4]= p5;
		arr[5]= p6;
		
		
		Arrays.sort(arr, new AgeCompImpl());
		for(Person person : arr ){
			System.out.println(person);
		}
	}

}
