import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;


public class Demo2 {

	public static void main(String[] args) {
		Hashtable<Integer, Double> map= new Hashtable<Integer, Double>();
		
		map.put(1, 67.86);
		map.put(2, 58.75);
		map.put(3, 60.00);
		map.put(4, 89.00);
		map.put(5, 78.64);
		map.put(3, 67.65);
		map.put(null,null);
		
		int size= map.size();
		System.out.println(size );
		Set<Entry<Integer, Double>> set= map.entrySet();
		
		Iterator<Entry<Integer,Double>> itr= set.iterator();
		while(itr.hasNext()){
			Entry<Integer,Double> ele= itr.next();
			int rollno= ele.getKey();
			double percent=ele.getValue();		
			System.out.println(rollno + "-> "+ percent );
		}
		Set<Integer> keys= map.keySet();
		
		System.out.println(keys);
		Collection<Double> values= map.values();
		
		System.out.println(values);
	}
}
