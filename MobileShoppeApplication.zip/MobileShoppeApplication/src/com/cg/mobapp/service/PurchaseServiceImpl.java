package com.cg.mobapp.service;

import com.cg.mobapp.dao.PurchaseDao;
import com.cg.mobapp.dao.PurchaseDaoImpl;
import com.cg.mobapp.dto.PurchaseDetails;
import com.cg.mobapp.exception.MobileException;

public class PurchaseServiceImpl implements PurchaseService{

	PurchaseDao dao;
	public PurchaseServiceImpl() {
		dao= new PurchaseDaoImpl();
	
	}
	@Override
	public int addPurchaseDetails(PurchaseDetails purchase)
			throws MobileException {
		return dao.addPurchaseDetails(purchase);
	}

}
