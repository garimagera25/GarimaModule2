package com.cg.mobapp.pl;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import com.cg.mobapp.dto.Mobile;
import com.cg.mobapp.dto.PurchaseDetails;
import com.cg.mobapp.exception.MobileException;
import com.cg.mobapp.service.MobileService;
import com.cg.mobapp.service.MobileServiceImpl;
import com.cg.mobapp.service.PurchaseService;
import com.cg.mobapp.service.PurchaseServiceImpl;
import com.cg.mobapp.service.ValidationService;
import com.cg.mobapp.service.ValidationServiceImpl;

public class Client {
	
	public static void main(String[] args) {
		
		
		Mobile mobile= new Mobile();
		MobileService service= new MobileServiceImpl();
		PurchaseDetails purchase= new PurchaseDetails();
		PurchaseService pservice= new PurchaseServiceImpl();
		ValidationService validation=new ValidationServiceImpl();
		Scanner sc= new Scanner(System.in);
		int option=0;
		do{
		System.out.println("\n\n1. Add Mobile Details ...");
		System.out.println("2. Display Mobile List ...");
		System.out.println("3. Display Mobile  ...");
		System.out.println("4. Update Mobile Quantity ");
		System.out.println("5. Delete mobile ");
		System.out.println("6. Add Purchase Details ");
		System.out.println("7. Exit");
		System.out.println("Enter Choice .");
		 option= sc.nextInt();
		switch(option){
		case 1 :
		
		System.out.println("Enter Mobile name : ");
		String name =sc.next();
		System.out.println("Enter Price : ");
		double price= sc.nextDouble();
		System.out.println("Enter quantity : ");
		int quantity= sc.nextInt();
		
			mobile.setMobileName(name);
			mobile.setPrice(price);
			mobile.setQuantity(quantity);
		
		try {
			int mobileid= service.addMobile(mobile);
			System.out.println("Mobile added : "+ mobileid );
		} catch (MobileException e) {
			System.out.println(e.getMessage());
		}	
		break;
		case 2 :
			
		try {
			List<Mobile> mobiles= service.getMobileList();
			if(mobiles.size()>0){
			for(Mobile mob :mobiles ){
				System.out.print(mob.getMobileId()+" "+ mob.getMobileName() );
				System.out.println("  "+ mob.getPrice()+ " "+mob.getQuantity());
			}
			}
			else
				System.out.println("No mobile records available");
		} catch (MobileException e) {
			System.out.println(e.getMessage());
		}
		
		break;
		//display mobile details for specific mobile id
		case 3:
		System.out.println("Enter mobile no :  ");
		int mobileid= sc.nextInt();
		try {
			mobile =service.getMobileDetails(mobileid);
			
			System.out.println(mobile.getMobileId()+" "+ mobile.getMobileName()+" "+ mobile.getPrice() );
		
		} catch (MobileException e) {
			System.out.println("catching exception");
			System.out.println(e.getMessage());
		}
		break;
		case 4:
			System.out.println("Enter Quantity ");
				int quan= sc.nextInt();
				System.out.println("enter Mobile id ");
				int mobid= sc.nextInt();
				mobile.setMobileId(mobid);
				mobile.setQuantity(quan);
				
			try {
				int rev= service.updateMobile(mobile);
				if(rev==1)
					System.out.println("quantity updated successfully ");
				else
					System.out.println("Mobile record not available");
			} catch (MobileException e) {
				System.out.println(e.getMessage());
			}				
			break;
		case 5 :
			System.out.println("Enter mobile id ");
			mobileid= sc.nextInt();
			try {
				int rv= service.deleteMobile(mobileid);
				if(rv==1)
					System.out.println("mobile details deleted .");
				else
					System.out.println("Mobile does not exist");
			} catch (MobileException e) {
				System.out.println(e.getMessage());
			}
			
			break;
		case 6:
			do{
			System.out.println("Enter Customer Name : ");
			name=sc.next();
			boolean res=validation.validateCustomerName(name);
			if(res==true)
			{
				purchase.setCustName(name);
				break;
			}
			else
				System.out.println("Name should contain only alphabets");
			}while(true);
			do{
			System.out.println("Enter Mail id : ");
			String mailid= sc.next();
			boolean res= validation.validateMailId(mailid);
			if(res==true)
				{
					purchase.setMailid(mailid);
					break;
				}
				else
					System.out.println("Mail id as: abcd@capgemini.com ");
			}while(true);
			do{
				System.out.println("Enter mobile No :");
				String mobno= sc.next();
				boolean res=validation.validateMobileNo(mobno);
				if(res)
				{
					purchase.setMobileNo(mobno);
					break;
				}
				else
					System.out.println("Mobile no shoule be 10 digit.");
			}while(true);
				
				
			do{
			LocalDate pd;
			try {
				System.out.println("Enter Date of purchase (dd/MM/yyyy) : ");
				String date= sc.next();
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
				pd = LocalDate.parse(date, formatter);
				purchase.setPurchaseDate(pd);
				break;
			} catch (Exception e) {
				System.out.println("Invalid date entered..");
			}
			}while(true);
			do{
				System.out.println("Enter Mobile id to purchase : ");
				String mid= sc.next();
				if(validation.validateMobileId(mid)){
					int id= Integer.parseInt(mid);
					purchase.setMobileid(id);
					break;
				}
				else
					System.out.println("mobile id should be 4 digit number ");
			}while(true);
			
			
			
			try {
				int purchaseid=pservice.addPurchaseDetails(purchase);
				System.out.println("purchase details inserted : " + purchaseid);
			} catch (MobileException e) {
				System.out.println(e.getMessage());
			}

			
			break;
			
		case 7:
			break;
			default :System.out.println("please enter correct option ");
		}// end of switch 
		}while(option!=6); // end of do while 
		}// end of main method
	
}// end of class
