package com.cg.mobapp.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.mobapp.dto.PurchaseDetails;
import com.cg.mobapp.exception.MobileException;
import com.cg.mobapp.util.DatabaseConnection;

public class PurchaseDaoImpl implements PurchaseDao{

	Connection connection ;
	public PurchaseDaoImpl() {
		connection= DatabaseConnection.getConnection();
	
	}
	
	@Override
	public int addPurchaseDetails(PurchaseDetails purchase)
			throws MobileException {
		
		String insQry= "insert into PurchaseDetails (purchaseId, cname,mailid,phoneno,purchasedate,mobileid) "
		+" values (purchase_id_seq.nextval,?,?,?,?,?)"; 
		int purchaseid=0;
		try {
			PreparedStatement ps= connection.prepareStatement(insQry);
			ps.setString(1,purchase.getCustName());
			ps.setString(2, purchase.getMailid());
			ps.setString(3, purchase.getMobileNo());
			Date date= Date.valueOf(purchase.getPurchaseDate());
			ps.setDate(4,date);
			ps.setInt(5, purchase.getMobileid());
		
			int r= ps.executeUpdate();
			if(r==1){
					Statement st= connection.createStatement();
					ResultSet rs= st.executeQuery("select purchase_id_seq.currval from dual");
					if(rs.next())
						purchaseid= rs.getInt(1);
			}
		} catch (SQLException e) {
			if(e.getErrorCode()==2291)
				throw new MobileException("Mobile id does not exist ");
			else
			throw new MobileException(e.getMessage());
		}
		return purchaseid;
	}

}
