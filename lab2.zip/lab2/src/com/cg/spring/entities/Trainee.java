package com.cg.spring.entities;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;



import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class Trainee {
	
	//@Column(name="trainee_name")
//	@Min(message="Trainee id should be positive" ,value=0)
	
	//@NotNull(message="Id cannot be null")
	//@Pattern(regexp="[0-9]{4}",message="Trainee id only 4 digits")
	@Id @NotNull @Min(1) @Max(110)
	private int traineeId;
	@NotEmpty(message="traineeName can not be blank")
	private String traineeName;
//	@NotEmpty(message="traineeDomain can not be blank")
//	@Size(max=20,min=5,message="traineeDomain should be between 5 and 20")
	private String traineeDomain;
	@NotEmpty(message="traineeLocation can not be blank")
	private String traineeLocation;
	
	public Trainee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Trainee(int traineeId, String traineeName, String traineeDomain,
			String traineeLocation) {
		super();
		this.traineeId = traineeId;
		this.traineeName = traineeName;
		this.traineeDomain = traineeDomain;
		this.traineeLocation = traineeLocation;
	}

	public int getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}
	public String getTraineeName() {
		return traineeName;
	}
	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}
	public String getTraineeDomain() {
		return traineeDomain;
	}
	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}
	public String getTraineeLocation() {
		return traineeLocation;
	}
	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}
	@Override
	public String toString() {
		return "Trainee [traineeId=" + traineeId + ", traineeName="
				+ traineeName + ", traineeDomain=" + traineeDomain
				+ ", traineeLocation=" + traineeLocation + "]";
	}
}
