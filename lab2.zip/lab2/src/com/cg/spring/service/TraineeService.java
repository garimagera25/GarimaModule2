package com.cg.spring.service;

import java.util.List;

import com.cg.spring.entities.Trainee;

public interface TraineeService {

	public Trainee addTrainee(Trainee trainee);

	public List<Trainee> GetAllTrainee();

	public Trainee removeTrainee(int traineeid);

	public Trainee getThisTraineeDetails(int traineeid);

	public Trainee updateTrainee(Trainee trainee);

	

}
