package com.cg.spring.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.dao.TraineeDao;
import com.cg.spring.entities.Trainee;
@Transactional
@Service
public class TraineeServiceImpl implements TraineeService {
	@Autowired
	TraineeDao tdao;
	
	public TraineeDao getTdao() {
		return tdao;
	}
	public void setTdao(TraineeDao tdao) {
		this.tdao = tdao;
	}
	@Override
	public Trainee addTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		return tdao.addTrainee(trainee);
	}
	@Override
	public List<Trainee> GetAllTrainee() {
		return tdao.GetAllTrainee();
	}
	@Override
	public Trainee removeTrainee(int traineeid) {
		return tdao.removeTrainee(traineeid);
	}
	@Override
	public Trainee getThisTraineeDetails(int traineeid) {
		return tdao.getThisTraineeDetails(traineeid);
	}
	@Override
	public Trainee updateTrainee(Trainee trainee) {
		return tdao.updateTrainee(trainee);
	}

}
