package com.cg.spring.controller;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.spring.entities.Trainee;
import com.cg.spring.service.TraineeService;

@Controller
public class LabController {
	@Autowired
	TraineeService service;
	
@RequestMapping("/toOperationPage")
public String OperationList(Model model,@RequestParam("userName")String uname,@RequestParam("password")String password)
{
	if(uname.equals("admin")&&password.equals("admin123"))
	{
		return "Operation";
	}
	else
		model.addAttribute("errorMessage","Invalid user");
		return "Error";
	
}
/************************************add operation****************************/
@RequestMapping("/toAddTraineePage")
public String AddTraineePage(Model model)
{
	
	Trainee trainee= new Trainee();
	model.addAttribute("trainee",trainee);
	return "AddTrainee";
	}
@RequestMapping("/toAddTrainee")
	public String AddTrainee(Model model, @Valid @ModelAttribute("trainee") Trainee trainee,BindingResult result)
	{
		if(result.hasErrors())
		{
//			model.addAttribute("trainee",trainee);
			return "AddTrainee";
		}
		else
			{
			
			
			trainee = service.addTrainee(trainee);
			model.addAttribute("SuccessMsg","added");
			return "Success";
			}
	}

/*************************************************delete operation*************************/
@RequestMapping("/toDeleteTraineePage")
public String DeleteTraineePage(Model model)
{
	
	Trainee trainee= new Trainee();
	model.addAttribute("trainee",trainee);
	return "DeleteTrainee";
	
	}

@RequestMapping("/toDeleteTrainee")
//,@RequestParam("traineeId") int traineeid
public String DeleteTrainee(Model model,@ModelAttribute("trainee") Trainee trainee )
{
	
	Trainee thisTrainee= service.getThisTraineeDetails(trainee.getTraineeId());
	
	if(thisTrainee!=null)
	{
		System.out.println(thisTrainee +"is not null");
		model.addAttribute("thisTrainee",thisTrainee);
		return "DeleteTrainee";
	}
	else{
		System.out.println(thisTrainee+"is null");
		model.addAttribute("errorMessage" ,"Id does not exist");
		return "Error";
	}
	}
@RequestMapping("toDeleteThisTrainee")
public String DeleteThisTrainee(Model model,@RequestParam("traineeId") int id)
{
		
	service.removeTrainee(id);
	model.addAttribute("SuccessMsg","deleted");
	return "Success";
	}


/*************************************retrieve****************************/
@RequestMapping("/toRetrieveTraineePage")
public String RetrieveTraineePage(Model model)
{
	Trainee trainee= new Trainee();
	model.addAttribute("trainee",trainee);
	return "Retrieve";
	
	}

@RequestMapping("/toRetriveTraineeDetails")
public String RetrieveTraineeDetails(Model model,@ModelAttribute("trainee") Trainee trainee)
{
Trainee thisTrainee= service.getThisTraineeDetails(trainee.getTraineeId());
	
	if(thisTrainee!=null)
	{
		
		model.addAttribute("thisTrainee",thisTrainee);
		return "Retrieve";
	}
	else{
		
		model.addAttribute("errorMessage" ,"Id does not exist");
		return "Error";
	}
	}

/**********************retrieve all****************************/
@RequestMapping("/toShowTraineeListPage")
public String GetAllTrainee(Model model)
{
	List<Trainee> tlist  = service.GetAllTrainee();
	model.addAttribute("tlist",tlist);
	return "TraineeList";
	}

/********************************MODIFY OPERATION********************/
@RequestMapping("/toModifyTraineePage")
public String ModifyTraineePage(Model model)
{
	Trainee trainee= new Trainee();
	model.addAttribute("trainee",trainee);
	return "ModifyTrainee";
	
	}

@RequestMapping("/toModifyTraineeDetail")
public String modifyTraineeDetails(Model model,@ModelAttribute("trainee") Trainee trainee)
{
	
Trainee thisTrainee= service.getThisTraineeDetails(trainee.getTraineeId());
	
	if(thisTrainee!=null)
	{
		System.out.println(thisTrainee +"is not null");
		model.addAttribute("thisTrainee",thisTrainee);
		return "ModifyTrainee";
	}
	else{
		System.out.println(thisTrainee+"is null");
		model.addAttribute("errorMessage" ,"Id does not exist");
		return "Error";
	}
	}
@RequestMapping("/updateTrainee")
public String updateBookRecord(Model model,@ModelAttribute("trainee") Trainee trainee)
{
	service.updateTrainee(trainee);
	model.addAttribute("trainee",trainee);
	model.addAttribute("successMsg Updated Successfully");
	
	return "Success";
}


}
