package com.cg.demotwojpa.service;

import java.util.List;

import com.cg.demotwojpa.dto.Project;

public interface ProjectService {
	public int addProject(Project proj);
	public void removeProject(int projId);
	public Project findProject(int projId);
	public Project updateProject(int projid,String string, String string2); //task to do
	
	public List<Project> showAllProjects();
	
	public void updateproject(Project pro);//class demo update
}
