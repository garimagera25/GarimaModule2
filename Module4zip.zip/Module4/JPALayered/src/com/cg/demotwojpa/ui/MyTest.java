package com.cg.demotwojpa.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.demotwojpa.dto.Project;
import com.cg.demotwojpa.service.ProjectService;
import com.cg.demotwojpa.service.ProjectServiceImpl;

public class MyTest {
	public static void main(String[] args) {
		ProjectService projectservice = new ProjectServiceImpl();
		
		System.out.println("1.insert");
		System.out.println("2.delete");
		System.out.println("3.update");
		System.out.println("4.Find");
		System.out.println("5.show all projects");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your Choice");
		int choice = sc.nextInt();
		
		
		Project p = new Project();
		switch(choice)
		{
		case 1:
//			p.setProjectId(1004);
			System.out.println("Enter project Name");
			String pname=sc.next();
			
			p.setProjectName(pname);
			System.out.println("Enter Department Name");
			String dname=sc.next();
			p.setProjectDepartment(dname);
			projectservice.addProject(p);
			System.out.println("Project created with id "+p.getProjectId());
			break;
		case 2:
			System.out.println("Enter Project id to delete :");
			int rid=sc.nextInt();
			projectservice.removeProject(rid);
			break;
		case 3:
			System.out.println("Enter your id");
			int pid = sc.nextInt();
			projectservice.updateProject(pid,"bank","FS");
			break;
		case 4:
			projectservice.findProject(1001);
			break;
		case 5:
			
			List<Project> allData=projectservice.showAllProjects();
			for(Project project:allData)
			{
			System.out.println("ID is"+project.getProjectId());
			System.out.println("Name is"+project.getProjectName());
			System.out.println("Department is"+project.getProjectDepartment());
			}
		}//end of switch
		
	}
}
