package com.cg.demotwojpa.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class ProjectUtil {
	static EntityManagerFactory entityfactory;
	static EntityManager entitymanager=null;
	static
	{
		entityfactory = Persistence.createEntityManagerFactory("JPALayered");
	}
	public static EntityManager getEntityManager()
	{
//		if(entitymanager==null && !entitymanager.isOpen())
//		{
			entitymanager=entityfactory.createEntityManager();
//		}
		return entitymanager;
	}
}
