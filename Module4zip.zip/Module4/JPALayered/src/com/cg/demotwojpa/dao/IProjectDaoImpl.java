package com.cg.demotwojpa.dao;

import java.util.List;

import javax.persistence.EntityManager;
 


import javax.persistence.Query;

import com.cg.demotwojpa.dto.Project;

public class IProjectDaoImpl implements IProjectDao {
	EntityManager em;
	
	public IProjectDaoImpl() {
		em = ProjectUtil.getEntityManager();
	}

	@Override
	public int addProject(Project proj) {
		em.getTransaction().begin();
		em.persist(proj);
		em.getTransaction().commit();
		return proj.getProjectId();
	
	}

	@Override
	public void removeProject(int projId) {
		em.getTransaction().begin();
		Project pj=em.find(Project.class, projId);
		em.remove(pj);
		em.getTransaction().commit();
		
		
		
		
	}

	@Override
	public Project findProject(int projId) {
		em.getTransaction().begin();
		Project efind=em.find(Project.class, projId);
		
		Project project = new Project();
		System.out.println("project name is"+efind.getProjectName());
		System.out.println("project department is"+efind.getProjectDepartment());
		return project;
	}

	@Override
	public Project updateProject(int pid,String pname, String dname) {
		em.getTransaction().begin();
		Project eupdate = em.find(Project.class, pid);
		eupdate.setProjectName(pname);
		eupdate.setProjectDepartment(dname);	
		em.merge(eupdate);
		em.getTransaction().commit();
		
		Project project = new Project();
		System.out.println("project name is"+eupdate.getProjectName());
		System.out.println("project department is"+eupdate.getProjectDepartment());
		return project;
	}

	@Override
	public List<Project> showAllProjects() {
	Query queryOne = em.createQuery("FROM Project");//class name
	List<Project> mylist = queryOne.getResultList();
		return mylist;
	}

	@Override
	public void updateproject(Project pro) {
		// TODO Auto-generated method stub
		
	}

}
