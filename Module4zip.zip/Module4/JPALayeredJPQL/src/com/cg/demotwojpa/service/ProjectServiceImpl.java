package com.cg.demotwojpa.service;

import java.util.List;

import com.cg.demotwojpa.dao.IProjectDao;
import com.cg.demotwojpa.dao.IProjectDaoImpl;
import com.cg.demotwojpa.dto.Project;

public class ProjectServiceImpl implements ProjectService {
	IProjectDao projectdao = new IProjectDaoImpl();
	@Override
	public int addProject(Project proj) {
		// TODO Auto-generated method stub
		return projectdao.addProject(proj);
	}

	@Override
	public void removeProject(int projId) {
		projectdao.removeProject(projId);
		// TODO Auto-generated method stub
		
	}

	@Override
	public Project findProject(int projId) {
		return projectdao.findProject(projId);
	}

	
	@Override
	public List<Project> showAllProjects() {
		return projectdao.showAllProjects();
	}

	@Override
	public void updateproject(Project pro) {
		projectdao.updateproject(pro);
		
	}

}
