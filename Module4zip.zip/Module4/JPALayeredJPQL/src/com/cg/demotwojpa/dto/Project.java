package com.cg.demotwojpa.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
//CREATE TABLE projectdb(proj_id NUMBER(6) PRIMARY KEY,
//proj_name VARCHAR2(30),proj_dep VARCHAR2(30)
//);
@Entity
@Table(name="projectdb")
@NamedQueries(
	//value={
				@NamedQuery(name="getALLData",query="FROM Project")
		//}
			)
public class Project {
	@Id
	/********************auto*************************/
//	@GeneratedValue(strategy=GenerationType.AUTO)
	//it will start with 1 if seq is not created
	//create sequence proj_id_auto
	/**************sequence*********************/
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="pro")
	@SequenceGenerator(name="pro",sequenceName="proj_id_auto")
	@Column(name="proj_id")
	private int projectId;
	@Column(name="proj_name")
	private String projectName;
	/****************transient will ignore the column********************/
	//@Transient
	@Column(name="proj_dep")
	private String projectDepartment;
	
	public int getProjectId() {
		return projectId;
	}
	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	
	
	
	public String getProjectDepartment() {
		return projectDepartment;
	}
	public void setProjectDepartment(String projectDepartment) {
		this.projectDepartment = projectDepartment;
	}
	@Override
	public String toString() {
		return "Project [projectId=" + projectId + ", projectDepartment="
				+ projectDepartment + ", projectName=" + projectName + "]";
	}
	
}
