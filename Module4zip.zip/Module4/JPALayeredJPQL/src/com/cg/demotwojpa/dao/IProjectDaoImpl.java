package com.cg.demotwojpa.dao;

import java.util.List;

import javax.persistence.EntityManager;
 


import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.demotwojpa.dto.Project;

public class IProjectDaoImpl implements IProjectDao {
	EntityManager em;
	
	public IProjectDaoImpl() {
		em = ProjectUtil.getEntityManager();
	}

	@Override
	public int addProject(Project proj) {
		em.getTransaction().begin();
		em.persist(proj);
		em.getTransaction().commit();
		return proj.getProjectId();
	
	}

	@Override
	public void removeProject(int projId) {
//		em.getTransaction().begin();
//		Project pj=em.find(Project.class, projId);
//		em.remove(pj);
//		em.getTransaction().commit();
//		
		/*****************jsquery************/
		em.getTransaction().begin();
		Query queryRemove = em.createQuery("DELETE FROM Project where projectId=:pid");
		queryRemove.setParameter("pid",projId );
		queryRemove.executeUpdate();
		em.getTransaction().commit();
		
		
	}

	@Override
	public Project findProject(int projId) {
		em.getTransaction().begin();
		Project efind=em.find(Project.class, projId);
		
		Project project = new Project();
		System.out.println("project name is"+efind.getProjectName());
		System.out.println("project department is"+efind.getProjectDepartment());
		return project;
	}

	

	@Override
	public List<Project> showAllProjects() {
		/*******jpql***********/
		//	Query queryOne = em.createQuery("FROM Project");//class name
		//	List<Project> mylist = queryOne.getResultList();
		//		return mylist;
		/****************typed query**********/
		TypedQuery<Project> queryOne = em.createQuery("From Project",Project.class);
		List<Project> mylist = queryOne.getResultList();
		System.out.println(mylist);
		return mylist;
		/*************namedquery*****************/
//		Query queryone=em.createNamedQuery("getALLData");
//		List<Project> myList=queryone.getResultList();
//		return myList;
	}

	@Override
	public void updateproject(Project pro) {
		em.getTransaction().begin();
		Query queryupdate = em.createQuery("UPDATE Project SET projectName=:pname,projectDepartment=:pdep where projectId=:pid");
		queryupdate.setParameter("pid", pro.getProjectId());
		queryupdate.setParameter("pname", pro.getProjectName());
		queryupdate.setParameter("pdep", pro.getProjectDepartment());
		queryupdate.executeUpdate();
		em.getTransaction().commit();
	}

}
