package com.cg.demoone.jpa.dto;

import javax.persistence.Entity;
import javax.persistence.Id;

//POJO
@Entity
public class Employee {
	@Id
	private int empId;
	private String empName;
	private double empsalary;
	private String empDepartment;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getEmpsalary() {
		return empsalary;
	}
	public void setEmpsalary(double empsalary) {
		this.empsalary = empsalary;
	}
	public String getEmpDepartment() {
		return empDepartment;
	}
	public void setEmpDepartment(String empDepartment) {
		this.empDepartment = empDepartment;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName
				+ ", empsalary=" + empsalary + ", empDepartment="
				+ empDepartment + "]";
	}
}
