package com.cg.demoone.jpa.ui;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.demoone.jpa.dto.Employee;

public class MyMain {
public static void main(String[] args) {
	
	Employee emp = new Employee();
	emp.setEmpId(1003);
	emp.setEmpName("abcde");
	emp.setEmpDepartment("Java");
	emp.setEmpsalary(1200);
	
	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("DemoOneJPA");
	EntityManager em = entityManagerFactory.createEntityManager();
	
			/******************INSERT OPERATION--commit is neccessary*****/
//		em.getTransaction().begin();  //TO START TRANSACTION
//	//DATA TO BE PERSIST is emp
//		em.persist(emp);
//		em.getTransaction().commit();
//		em.close();
//		entityManagerFactory.close();
	
	
		/*****************************SELECT operation -- no commit*************/
//		em.getTransaction().begin();
//		Employee efind=em.find(Employee.class, 1002);
//		em.close();
//		entityManagerFactory.close();
//		System.out.println("Id is"+efind.getEmpId());
//		System.out.println("Name is"+efind.getEmpName());
//		System.out.println("Salary is "+efind.getEmpsalary());
	
		/****************SEarch and remove operation*************/

//		em.getTransaction().begin();
//		Employee eremove=em.find(Employee.class,1001);
//		em.remove(eremove);
//		em.getTransaction().commit();
//		em.close();
//		entityManagerFactory.close();
		/**********************update*************/
		em.getTransaction().begin();
		Employee eupdate = em.find(Employee.class, 1002);
		eupdate.setEmpName("rrrr");
		eupdate.setEmpsalary(2000);
		
		em.merge(eupdate);
		em.getTransaction().commit();
		em.close();
		entityManagerFactory.close();
}
}
