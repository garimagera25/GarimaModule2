package com.cg.webservice.controller;

public class ProductController {

	public ProductController() {
		// TODO Auto-generated constructor stub
	}

}
