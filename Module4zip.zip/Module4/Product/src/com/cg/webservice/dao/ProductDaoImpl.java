package com.cg.webservice.dao;

import java.util.List;

import com.cg.webservice.bean.Product;

public class ProductDaoImpl implements IProductDao {
//create table Product_details(product_id number primary key ,prod_name varchar2(20),price number); 
	@Override
	public float getProductPrice(String productName) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Product> getProductList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Product addProduct(Product product) {
		// TODO Auto-generated method stub
		return null;
	}

}
