package com.cg.webservice.bean;

public class Product {

}
