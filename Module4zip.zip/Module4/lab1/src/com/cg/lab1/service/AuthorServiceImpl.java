package com.cg.lab1.service;

import com.cg.lab1.dao.AuthorDao;
import com.cg.lab1.dao.AuthorDaoImpl;
import com.cg.lab1.dto.Author;

public class AuthorServiceImpl implements AuthorService {
	AuthorDao adao=new AuthorDaoImpl();
	
	@Override
	public int addAuthor(Author Auth) {
		adao.addAuthor(Auth);
		return 0;
	}
	@Override
	public void removeAuthor(int AuthId) {
		adao.removeAuthor(AuthId);
		
	}
	@Override
	public Author findAuthor(int AuthId) {
		return adao.findAuthor(AuthId);
	}
	@Override
	public Author updateAuthor(int Authid, String fname) {
		return adao.updateAuthor(Authid, fname);
	}

}
