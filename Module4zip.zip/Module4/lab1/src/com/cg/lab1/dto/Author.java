package com.cg.lab1.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="author")
public class Author {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="pro")
	@SequenceGenerator(name="pro",sequenceName="author_id_auto")
	@Column(name="authorid")
private int authorid;
	@Column(name="fname")
private String fname;
	@Column(name="mname")
private String mname;
	@Column(name="lname")
private String lname;
	@Column(name="phoneno")
private int phoneno;
public int getAuthorid() {
	return authorid;
}
public void setAuthorid(int authorid) {
	this.authorid = authorid;
}
public String getFname() {
	return fname;
}
public void setFname(String fname) {
	this.fname = fname;
}
public String getMname() {
	return mname;
}
public void setMname(String mname) {
	this.mname = mname;
}
public String getLname() {
	return lname;
}
public void setLname(String lname) {
	this.lname = lname;
}
public int getPhoneno() {
	return phoneno;
}
public void setPhoneno(int phoneno) {
	this.phoneno = phoneno;
}
@Override
public String toString() {
	return "Author [authorid=" + authorid + ", fname=" + fname + ", mname="
			+ mname + ", lname=" + lname + ", phoneno=" + phoneno + "]";
}

}
