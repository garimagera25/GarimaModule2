package com.cg.lab1.dao;


import com.cg.lab1.dto.Author;

public interface AuthorDao {

	public int addAuthor(Author Auth);
	public void removeAuthor(int AuthId);
	public Author findAuthor(int AuthId);
	public Author updateAuthor(int Authid,String fname);
}

