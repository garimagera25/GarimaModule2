package com.cg.lab1.dao;

import javax.persistence.EntityManager;



import com.cg.lab1.dto.Author;

public class AuthorDaoImpl implements AuthorDao {

	EntityManager em;
	
	public AuthorDaoImpl() {
		em = AuthorUtil.getEntityManager();
	}
	@Override
	public int addAuthor(Author Auth) {
		em.getTransaction().begin();
		em.persist(Auth);
		em.getTransaction().commit();
		return 0;
	}

	@Override
	public void removeAuthor(int AuthId) {
		em.getTransaction().begin();
		Author eremove=em.find(Author.class,AuthId );
		em.remove(eremove);
		em.getTransaction().commit();
		
	}

	@Override
	public Author findAuthor(int AuthId) {
		em.getTransaction().begin();
		Author eremove=em.find(Author.class,AuthId );
		Author author = new Author();
		em.getTransaction().commit();
		return author;
	}

	@Override
	public Author updateAuthor(int Authid, String fname) {
		em.getTransaction().begin();
		Author eupdate=em.find(Author.class,Authid );
		eupdate.setFname(fname);
		em.merge(eupdate);
		Author author = new Author();
		em.getTransaction().commit();
		System.out.println("Author name is"+eupdate.getFname());

		return author;
	}

}
