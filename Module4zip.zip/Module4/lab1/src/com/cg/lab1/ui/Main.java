package com.cg.lab1.ui;

import java.util.Scanner;

import com.cg.lab1.dto.Author;
import com.cg.lab1.service.AuthorService;
import com.cg.lab1.service.AuthorServiceImpl;

public class Main {
public static void main(String[] args) {
	AuthorService authorservice = new AuthorServiceImpl();
	System.out.println("1.insert");
	System.out.println("2.delete");
	System.out.println("3.update");
	System.out.println("4.Find");
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter your Choice");
	int choice = sc.nextInt();
	
	Author a = new Author();
	
	switch(choice)
	{
	case 1:
//		System.out.println("Enter author id");
//		int authorid = sc.nextInt();
//		a.setAuthorid(authorid);
		
		System.out.println("Enter ur First Name");
		String fname= sc.next();
		a.setFname(fname);
		System.out.println("Enter ur Middle Name");
		String mname= sc.next();
		a.setMname(mname);
		System.out.println("Enter ur Last Name");
		String lname= sc.next();
		a.setLname(lname);
		System.out.println("Enter ur phone no.");
		int phoneno=sc.nextInt();
		a.setPhoneno(phoneno);
		
		authorservice.addAuthor(a);
		System.out.println("Author id generated "+a.getAuthorid());
		break;
		
	case 2:
		authorservice.removeAuthor(1003);
		break;
	case 3:
		System.out.println("Enter your id");
		int pid = sc.nextInt();
		authorservice.updateAuthor(pid,"RAM");
		break;
	case 4:
		authorservice.findAuthor(1001);
		break;
	}//end of switch
}
}
