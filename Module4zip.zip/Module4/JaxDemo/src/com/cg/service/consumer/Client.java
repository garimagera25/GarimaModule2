package com.cg.service.consumer;

//import javax.print.DocFlavor.URL;
import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import com.cg.webservices.calculator.CalculatorServer;




public class Client {
	
	public static void main(String[] args) throws Exception {
		URL url = new URL("http://localhost:9863/cs?wsdl");
		QName qname= new QName("http://service.webservices.cg.com/","CalculatorService");
		Service service = Service.create(url,qname);
		CalculatorServer calcService = service.getPort(CalculatorServer.class);
		int result = calcService.add(45,44);
		System.out.println("Addition "+result);
	}


}
