package com.cg.webservices.service;

import javax.jws.WebService;

@WebService(endpointInterface="com.cg.webservices.calculator.CalculatorServer")
public class Calculator {
public int add(int num1,int num2)
{
	return num1+num2;
	}
public int substract(int num1,int num2)
{
	return num1-num2;
	}
public int findMax(int num1,int num2)
{
	return num1>num2?num1:num2;
	}

}
