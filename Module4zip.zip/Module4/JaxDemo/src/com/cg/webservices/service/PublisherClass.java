package com.cg.webservices.service;

import javax.xml.ws.Endpoint;
import com.cg.webservices.service.Calculator;
public class PublisherClass {
	public static void main(String[] args) {
		System.out.println("Services are published..");
		Endpoint.publish("http://localhost:9863/cs", new Calculator());
		System.out.println("Now waiting for client");
	}
}
