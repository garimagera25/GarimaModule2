package com.cg.demo.dto;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
@Entity
public class Author {
	@Id
	private int authid;
	private String name;
	
	@OneToMany
	List<Book> b;
	
	
	public List<Book> getB() {
		return b;
	}
	public void setB(List<Book> b) {
		this.b = b;
	}
	public int getAuthid() {
		return authid;
	}
	public void setAuthid(int authid) {
		this.authid = authid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Author [authid=" + authid + ", name=" + name + "]";
	}
}
