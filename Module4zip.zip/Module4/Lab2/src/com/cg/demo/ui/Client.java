package com.cg.demo.ui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.demo.dto.Author;
import com.cg.demo.dto.Book;


public class Client {
	
	
	public static void main(String[] args) {
		EntityManagerFactory emFactory=Persistence.createEntityManagerFactory("Lab2");
		EntityManager em =emFactory.createEntityManager();
		
//		em = ProjectUtil.getEntityManager();
		Scanner sc = new Scanner(System.in);
		
		
		System.out.println("1.Show all Books");
		System.out.println("2.List all books with given price range. e.g. between Rs. 500 to 1000");
		System.out.println("Enter your Choice");
		int choice = sc.nextInt();
		
		Book b1 = new Book();
		b1.setIsbn(1001);
		b1.setPrice(700);
		b1.setTitle("ABCD");
		
		Book b2 = new Book();
		b2.setIsbn(1002);
		b2.setPrice(800);
		b2.setTitle("QWERTY");
		
		Author a1 = new Author();
		a1.setAuthid(101);
		a1.setName("plm");
		
		List<Book> lbook=new ArrayList<>();
		
		lbook.add(b1);
		lbook.add(b2);
		
		a1.setB(lbook);
		em.getTransaction().begin();
		em.persist(b1);
		em.persist(b2);
		em.persist(a1);
		em.getTransaction().commit();
		
		
		switch(choice)
		{
		case 1:
			
			em.getTransaction().begin();
			
			Query queryOne = em.createQuery("FROM Book");//class name
			List<Book> booklist = queryOne.getResultList();
			
//		TypedQuery<Book> qry= em.createQuery("From Book", Book.class);
//		List<Book> booklist = qry.getResultList();
		
		
		System.out.println("list of book");
		for (Book book : booklist) {
			//isbn,title,price
			System.out.println("ISBN is"+book.getIsbn());
			System.out.println("Title is"+book.getTitle());
			System.out.println("Price is"+book.getPrice());
		}
		em.getTransaction().commit();
			
			break;
		
		case 2:
			
			em.getTransaction().begin();
			String qry = "from Book b where  b.price Between 500 AND 800";
			
			TypedQuery<Book> query1= em.createQuery(qry, Book.class);
//			Query query1 = em.createQuery("FROM Book WHERE price between =:500 AND =:800");//class name
			List<Book> booklist1 = query1.getResultList();
			for (Book book : booklist1) {
				System.out.println("Title is "+book.getTitle());
			}
			
			break;
		}//end of switch
		em.close();
		emFactory.close();
	}

	
	
}
