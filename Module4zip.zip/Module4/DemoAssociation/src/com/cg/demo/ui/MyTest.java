package com.cg.demo.ui;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.demo.dto.User;
import com.cg.demo.dto.Vech;

public class MyTest {
	public static void main(String[] args) {
		
	
	EntityManagerFactory emFactory=Persistence.createEntityManagerFactory("DemoAssociation");
	EntityManager em =emFactory.createEntityManager();
	
	
	Vech ve = new Vech();
	ve.setVechId(10);
	ve.setVechName("jeep");
	
	Vech veTwo = new Vech();
	veTwo.setVechId(20);
	veTwo.setVechName("i10");
	
	User u= new User();
	u.setUserId(1);
	u.setUserName("A");
	//u.setV(ve);
	List<Vech> my= new ArrayList<>();
	my.add(ve);
	my.add(veTwo);
	u.setV(my);//injecting vech into user
	em.getTransaction().begin();
	em.persist(ve);
	em.persist(veTwo);
	em.persist(u);

	em.getTransaction().commit();
	em.close();
	emFactory.close();
}

}