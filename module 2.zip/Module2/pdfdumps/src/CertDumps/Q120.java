package CertDumps;
class Special extends Exception{
	public Special(String message)
	{
		super(message);
		System.out.println(message);
	}
	
}
public class Q120 {
public static void main(String[] args) {
	try{
		doSome();
	}
	catch(Special e)
	{
		System.out.println(e);
	}
}
static void doSome() throws Special{
	int[] age=new int[4];
	age[4]=17;
	doSomeElse();
}
static void doSomeElse() throws Special{
	throw new Special("throw ");
}

}
