package CertDumps;

public class Q111 {
private static int letter;

public static int getLetter();

public static void setLetter(int letter) {
	Q111.letter = letter;
}
public static void main(String[] args) {
	System.out.println(getLetter());
}
}
