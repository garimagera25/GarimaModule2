package CertDumps;

 class Dog {
 Dog() {
	// TODO Auto-generated constructor stub
	try{
		throw new Exception();
		
	}
	catch(Exception e)
	{
		
	}
}
}
 public class q134{
	 public static void main(String[] args) {
		Dog d1=new Dog();
		Dog d2=new Dog();
		Dog d3=d2;
		//d2=null;
		System.out.println("One"+ d1);
		System.out.println("Two"+ d2);
		System.out.println("Three"+ d2);
	}
 }
