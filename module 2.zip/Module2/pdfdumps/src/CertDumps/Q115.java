package CertDumps;

public class Q115 {
public static void main(String[] args) {
	int i=2;
	do{
		
		System.out.println(i);
		
	}
	while(--i);
}
}
