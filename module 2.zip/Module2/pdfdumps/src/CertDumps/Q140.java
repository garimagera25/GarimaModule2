package CertDumps;
class Alpha{
	public String[] main=new String[2];
	public Alpha(String[] main) {
		for (int i = 0; i < main.length; i++) {
			this.main=main;
		}
		// TODO Auto-generated constructor stub
	
	}
	public void main(){
		System.out.println(main[0]+main[1]);
	}
}
public class Q140 {
public static void main(String[] args) {
	args[0]="1";
	args[1]="2";
	Alpha main=new Alpha(args);
	main.main();
}
}
