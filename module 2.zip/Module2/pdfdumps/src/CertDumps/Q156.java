package CertDumps;

public class Q156 {
	//public class Test {
		public static void main(String[] args) { String day = "1";
		switch (day) {
		case "7": System.out.print("Uranus");
		case "6": System.out.print("Saturn");
		case "1": System.out.print("Mercury");
		case "2": System.out.print("Venus");
		case "3": System.out.print("Earth");
		case "4": System.out.print("Mars");
		case "5": System.out.print("Jupiter");
		}
		}
		}

