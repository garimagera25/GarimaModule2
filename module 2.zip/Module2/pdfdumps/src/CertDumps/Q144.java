package CertDumps;

public class Q144 {
	//class StaticMethods {
		 static void one() {
		 two();
		 Q144.two();
		 three();
		 Q144.four();
		 }
		 static void two() { }
	 void three() {
		one();
		//Lead to pass your exam quickly and easily. First Test, First Pass! - visit - http://www.certleader.com
		Q144.two();
	 four();
	 Q144.four();
		 }
		 void four() {
			 
			 
		 }
		
}
