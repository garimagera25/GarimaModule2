package CertDumps;

public class Q135 {
public static void main(String[] args) {
	int[] x={6,7,8};
	for(int i:x)
	{
		System.out.println(i+"");
		i++;
	}
}
}
