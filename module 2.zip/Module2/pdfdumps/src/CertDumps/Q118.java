package CertDumps;

public class Q118 {
public static int main(String[] args) {
System.out.println("mom");
	return 0;
	
}
}
