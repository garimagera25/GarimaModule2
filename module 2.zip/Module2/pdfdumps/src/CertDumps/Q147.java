package CertDumps;

public abstract class Q147 {
private int wow;
public Q147(int wow)
{
	this.wow=wow;
	}
private void wowza(){}
}
