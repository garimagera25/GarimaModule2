package CertDumps;

public class Q114 {
public static void main(String[] args) {
	int[][] array ={{0,1,2,4},{4,5,6}};
	//int[][] array2d=new int[][2];
//	int[][][] arrray3d={{0,1},{2,4,3},{3,4}};
	int[] array2={0,1};
	int[][][] array3d=new int[2][2][2];
	array3d[0][0]=array2;
	array3d[0][1]=array2;
	array3d[1][0]=array2;
	array3d[1][1]=array2;
}
}
