package CertDumps;

public class Q151 {
public static void doChane(int[] arr)
{
	
	for(int pos=0;pos<arr.length;pos++)
		arr[pos]=arr[pos]+1;
	}
public static void main(String[] args) {
	int[] arr={10,20,30};
	doChane(arr);
for(int x:arr)
	System.out.println(x);
doChane(arr);
System.out.println(arr[0]+""+arr[1]+""+arr[2]);
}
//private static void doChane(int i, int j, int k) {
//	// TODO Auto-generated method stub
//	
//}

}

