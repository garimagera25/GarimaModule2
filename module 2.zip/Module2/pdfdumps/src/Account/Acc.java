package Account;

public class Acc {
int p ;
private int q;
protected int r=5;
public int s;

protected int x = 9; // protected access


public void testIt() {
	System.out.println("x is " + x);
	System.out.println(r);// No problem; Child
	// inherits x
	}
}
