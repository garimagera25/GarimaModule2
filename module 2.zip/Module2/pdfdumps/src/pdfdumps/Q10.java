package pdfdumps;

public class Q10 {
public static void main(String[] args) {
	StringBuilder sb = new StringBuilder(5);
	
	String s = "a";
	if(sb.equals(s))
	{
	System.out.println("match 1");
	}
	else if (sb.toString().equals(s))
	{
		System.out.println("match 2");
	}
	else
	System.out.println("No ,match");
}
}
