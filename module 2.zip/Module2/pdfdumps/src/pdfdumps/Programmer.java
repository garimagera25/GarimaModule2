package pdfdumps;



abstract  class Writer
{
	public static void write()
	{
		System.out.println("writring");
	}
	}
class Author extends Writer
{
	public static void write(int a)
	{
		System.out.println("author");
	}
	}

public class Programmer extends Writer {
	
	public static void write(int a)
	{
		System.out.println("code");
	}
	
public static void main(String[] args) {
	Writer w = new Programmer();
	
	w.write();
}
}
