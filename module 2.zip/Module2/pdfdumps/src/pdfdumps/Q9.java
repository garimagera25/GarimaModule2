package pdfdumps;

import java.util.ArrayList;
import java.util.List;

public class Q9 {
public static void main(String[] args) {
	List<String> items=new ArrayList<>();
	items.add("Pen");
	items.add("Pencil");
	items.add("box");
	for(String i:items)
		
	{
		System.out.println("for");
		
		if(i.indexOf("P")==0)
		{
			System.out.println("if");
			continue;
		}else
		{
			System.out.println(i);
		}
	}
}
}
