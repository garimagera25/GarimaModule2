package pdfdumps;

public class Swichex {
	public static void main(String[] args) {
		int cardVal=8;
		switch(cardVal)
		{
		case 4: case 5: case 6: case 7: case 8:
			System.out.println("Hi");
			break;
		case 9: case 10: case 11:
			System.out.println("double");
			break;
		case 15: case 16:
			System.out.println("Surr");
			break;
			default:
				System.out.println("Stand");
		}
	}

}
