package pdfdumps;

import java.util.ArrayList;
import java.util.List;

public class JavaTest {
	public static void main(String[] args) {
		List<Integer> elements = new ArrayList<>();
		elements.add(10);
		int f= elements.get(0);
		System.out.println(f);
	}
}
