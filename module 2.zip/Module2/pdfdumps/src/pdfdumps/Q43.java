package pdfdumps;

import Account.Acc;

public class Q43 extends Acc {
	Q43 obj = new Q43(); 
	obj.s;
	
	
public void checj()
{
	
	testIt();
	
	
	
	obj.r;
	obj.p;
	
	
	
	}

}
