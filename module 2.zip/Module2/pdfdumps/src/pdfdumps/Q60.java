package pdfdumps;

public abstract class Q60 {
public int calculatePrice(Toy t);                           
}
