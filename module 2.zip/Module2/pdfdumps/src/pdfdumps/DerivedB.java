package pdfdumps;
class Base
{
	public void test()
	{
		System.out.println("base");
	}
	}

class DerivedA extends Base
{
	public void test()
	{
		System.out.println("A");
	}
	}
public class DerivedB extends DerivedA{
	public void test()
	{
		System.out.println("B");
	}
public static void main(String[] args) {
	Base b1= new DerivedB();
	Base b2 = new DerivedA();
	
	DerivedA b3 = new DerivedB();
	
	
	Base b5=new Base();
	b5.test();
	b1=  b2;
	Base b4=  b3;
//	b1.test();
	b4.test();
}
}


