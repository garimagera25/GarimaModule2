package pdfdumps;

public class Type {
	public static void main(String[] args) {
		
		
		
		byte b = 127;
		short s =b;
		int i = b;
		long l = b;
		
		
		long p= 1000;
		byte b1 = (byte)p;
		
		
		
		
		short s1=200;
		int s2=400;
		
		
		long dup = s2;
		long qw= s1;
		
		
		Long s3= (long)s1+s2;
		System.out.println(s3);
//		String s4=(String) (s3*s2);
//		System.out.println(s4);
	}

}
