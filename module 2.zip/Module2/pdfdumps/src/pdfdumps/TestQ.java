package pdfdumps;

class MyString
{
	String msg;
	MyString(String msg)
	{
		this.msg=msg;
	}
	@Override
	public String toString() {
		return msg;
	}
}
public class TestQ {
	public static void main(String[] args) {
		//main(4);
		System.out.println("String main");
	}
	public static void main(Object[] args) {
		System.out.println("object main");
	}
	public static void main(int[] args) {
		System.out.println("int main");	
	}
	
}
