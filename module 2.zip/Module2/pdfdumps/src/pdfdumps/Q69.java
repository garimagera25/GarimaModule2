package pdfdumps;

public class Q69 {
static double area;
int b=2,h=3;
public static void main(String[] args) {
	double p = 0,b = 0,h = 0;
	if(area==0)
	{
		b=3;
		h=4;
		p=0.5;
	}
	area=p*b*h;
	System.out.println("area="+area);
}
}
