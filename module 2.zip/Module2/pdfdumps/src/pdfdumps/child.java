package pdfdumps;
 class Parent{
	Parent()
	{
		this(20);
		System.out.println("i m parent default");
	}
	
	
	Parent(int x)
	{
		//this();
		System.out.println("parent param");
	}
}
public class child extends Parent{
	child()
	{
		
		System.out.println("child default");
	}
	child(int x)
	{
		//super();
		//super(20);
		//this();
		System.out.println("child param");
	}
	
	public static void main(String[] args) {
		Parent p= new child();
		
		
		
		
		//Parent p1= new child(10);
		
		
	}
}
