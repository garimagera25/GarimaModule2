package pdfdumps;



public class PlanetQ59 {
public String name;
public int moons;

public PlanetQ59(String name ,int moons)
{
this.name=name;
this.moons=moons;

}
public static void main(String[] args) {
	PlanetQ59[] planets={
			new PlanetQ59("Mercury", 0),
			new PlanetQ59("Venus", 0),
			new PlanetQ59("Earth", 1),
			new PlanetQ59("Mars", 2),
	};
	System.out.println(planets);
	System.out.println(planets[2]);
	System.out.println(planets[2].moons);
	
}
@Override
public String toString() {
	return "PlanetQ59 [name=" + name + ", moons=" + moons + "]" ;
}
}
