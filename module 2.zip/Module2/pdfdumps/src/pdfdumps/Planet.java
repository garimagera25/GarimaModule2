package pdfdumps;

 abstract class Planet {
	
	
	
	   protected void revolve(){
	}
	
	
	
	
	
	
	  abstract void rotate();

}
class Earth extends Planet{
	protected  void revolve()
	   
	  //public void revolve
	{
		
	}
		 void rotate()
	{
		
	}
	
}