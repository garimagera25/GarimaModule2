package pdfdumps;

public class NEW {
public static void main(String[] args) {
	String sre=" ";
	sre.trim();
	System.out.println(sre.equals("")+""+sre.isEmpty());
   System.out.println(sre.length());
}
}
