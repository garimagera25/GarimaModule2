package pdfdumps;

public class RuntimeException extends Exception{

}
