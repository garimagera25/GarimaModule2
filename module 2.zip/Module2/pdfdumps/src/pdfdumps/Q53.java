package pdfdumps;
class Vehicl{
	int x;
	Vehicl() {
	this(10);//n1
	System.out.println("degault v");
		// TODO Auto-generated constructor stub
	}
	Vehicl(int x)
	 {
		 this.x=x;
		 System.out.println("paramv");
	 }
	 
}
public class Q53 extends Vehicl {
int y;
public Q53() {
	// TODO Auto-generated constructor stub
	this(20);
	//super(20);
	System.out.println("child default");
	
	//n2
	
}
Q53(int y)
{
	System.out.println("child param");
	this.y=y;}
@Override
public String toString() {
	return super.x+""+this.y;
}
public static void main(String[] args) {
	Vehicl y=new Q53();
	System.out.println(y);
	
}


}
