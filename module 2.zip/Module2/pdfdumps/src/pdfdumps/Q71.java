package pdfdumps;
class MyException extends RuntimeException{}

public class Q71 {
public static void main(String[] args) {
	try
	{
		method1();
	}catch(MyException ne)
	{
		System.out.println("A");
	}
}
public static void method1()
{
	try
	{
		throw Math.random()>0.5?new MyException():new RunTimeException();
		}catch(RuntimeException re)
	{
			System.out.println("B");
	}
}
}
