package pdfdumps;

public class Stringqwe {
	
	
	public static void main(String[] args) {
		StringBuilder s1= new StringBuilder("java");
		String s2 ="Love";
		
		
		s1.append(s2);
		System.out.println(s1.substring(2,6));
		System.out.println(s1.substring(4));
		
		
		
		int foundAt = s1.indexOf(s2);
		System.out.println(foundAt);
	}
	
	
	
}
