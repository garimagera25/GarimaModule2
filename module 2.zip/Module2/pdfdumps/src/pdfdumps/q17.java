package pdfdumps;

public class q17 {
	public  int amount;
	public q17(int amount)
	{
		this.amount=amount;
	}
public int getAmount()
{
	return amount;
}
public void changeAmount(int x)
{
	 amount+=x;
}
public static void main(String[] args) {
	q17 q=new q17((int)(Math.random()*1000));
	q.changeAmount(-q.getAmount());
	System.out.println(q.getAmount());
}
}
