package Kathy;

class MyException extends Exception { }
 class Tire {
 void doStuff()  { }
 }
 public class Retread extends Tire {
 public static void main(String[] args)  throws RuntimeException {

	
		new Retread().doStuff();
	
}
 void doStuff() throws RuntimeException {
 // insert code here
	  
 System.out.println(7/0);
 }
 }
`