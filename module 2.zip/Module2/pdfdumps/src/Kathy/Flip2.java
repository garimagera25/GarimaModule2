package Kathy;

public class Flip2 {
public static void main(String[] args) {
String o = "-";
String[] sa = new String[4];
System.out.println("hello");
for(int i = 0; i < args.length; i++)

sa[i] = args[i];

for(String n: sa) {
	System.out.println("sa in 2nd"+n);
switch(n.toLowerCase()) {
case "yellow": o += "y";
case "red": o += "r";
case "green": o += "g";
}
}
System.out.print(o);
}
}