package Kathy;

public class Gotcha {
 public static void main(String[] args) {
 // insert code here
	 new Gotcha().go();}
 void go() {
 go();
 }
 }