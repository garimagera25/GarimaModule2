package com.capgemini.xyz.ui;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import java.util.Scanner;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.exception.LoanAppException;
import com.capgemini.xyz.service.ILoanService;
import com.capgemini.xyz.service.IValidationService;
import com.capgemini.xyz.service.LoanService;
import com.capgemini.xyz.service.ValidationService;






public class ExecuterMain {
public static void main(String[] args) {
	PropertyConfigurator.configure("resources/log4j.properties");
	Logger logger=Logger.getLogger(ExecuterMain.class);
	
	
	Customer customer = new Customer();
	Loan loan = new Loan();
	
	IValidationService validation=new ValidationService();
	ILoanService service= new LoanService();
	
	
System.out.println("XYZ Finance Company welcomes you");
logger.info("XYZ Finance Company welcomes you");
	Scanner sc= new Scanner(System.in);
	int option=0;
	
	do{
		System.out.println("\n\n1. Register customer ...");
		logger.info("\n\n1. Register customer ...");
		System.out.println("2.Exit");
		logger.info("2.Exit");
		System.out.println("Enter Choice .");
		logger.info("Enter choice");
		 option= sc.nextInt();
		switch(option){
		case 1:
			do{
				System.out.println("Enter Customer Name : ");
				logger.info("Enter Customer Name : ");
				String name=sc.next();
				boolean res=validation.validateCustomerName(name);
				if(res==true)
				{
					customer.setCustName(name);
					break;
				}
				else
					System.out.println("Name should contain only alphabets");
				logger.error("Name should contain only alphabets");
				}while(true);
			
			
			do{
				System.out.println("Enter Customer Adress : ");
				logger.info("Enter Customer Adress : ");
				String address=sc.next();
				boolean res=validation.validateCustomerAdress(address);
				if(res==true)
				{
					customer.setAddress(address);
					
					break;
				}
				else
					System.out.println("Adress should be valid");
				logger.error("Adress should be valid");
				}while(true);
			
			do{
				System.out.println("Enter Customer Email : ");
				logger.info("Enter Customer Email : ");
				String email=sc.next();
				boolean res=validation.validateMailId(email);
				if(res==true)
				{
					customer.setEmail(email);
					break;
				}
				else
					System.out.println("email is not valid");
				logger.error("email is not valid");
				}while(true);
			
			
			do{
				System.out.println("Enter mobile No :");
				logger.info("Enter mobile No : ");
				String mobno= sc.next();
				boolean res=validation.validateMobileNo(mobno);
				if(res)
				{
					customer.setMobile(mobno);
					break;
				}
				else
					System.out.println("Mobile no shoule be 10 digit.");
				logger.error("Mobile no shoule be 10 digit.");
			
			}while(true);
		
			
			try {
				
				long custid= service.insertCust(customer);
				
				System.out.println("Customer information saved successfully");
				System.out.println("Customer added : "+ custid );
				logger.info("Customer added : "+ custid);
				
				
				String loanInput;
				System.out.println("Do you wish to apply for loan?");
				logger.info("Do you wish to apply for loan?");
				System.out.println("\n\n1.Type Yes Register for loan ...");
				System.out.println("2.Type No to  Exit");
				 loanInput=sc.next();
				 do{
				 switch(loanInput)
				 {
				 case "Yes":
					 
					 System.out.println("Enter the loan amount");
					 logger.info("Enter the loan amount");
					 double amnt= sc.nextDouble();
					 System.out.println("Enter the yrs");
					 int yrs = sc.nextInt();
					 try{
						 double emiCalculated= service.calculateEMI( amnt, yrs );
						 System.out.println("For loan amout"+amnt+"and"+yrs+"Years duration");
							System.out.println("Your EMI per month will be"+emiCalculated);
							logger.info("Your EMI per month will be"+emiCalculated);
							System.out.println("Do you want to apply for loan now?");
							logger.info("Do you want to apply for loan now?");
							String LoanConfirm;
							System.out.println("\n\n1.Type Yes apply for loan ...");
							System.out.println("2.Type No to  Exit");
							LoanConfirm=sc.next();
							do{
								 switch(LoanConfirm)
								 {
								 case "Yes":
									 loan.setCustId(custid);
									 loan.setLoanAmount(amnt);
									 loan.setDuration(yrs);
									 
									 try {
											long loanid= service.applyLoan(loan);
											System.out.println("Your loan id is: "+ loanid );
										} catch (LoanAppException e) {
											System.out.println(e.getMessage());
											logger.error(e.getMessage());
										}	
								 }//end of loan confirm switch
							}while(LoanConfirm=="No");
					 }
					 catch(LoanAppException e)
					 {
						 System.out.println(e.getMessage());
						 logger.error(e.getMessage());
					 }
					 break;
				 }//end of loan input switch
				 }while(loanInput=="No");
				 System.out.println();
				 
				 
			} catch (LoanAppException e) {
				System.out.println(e.getMessage());
				logger.error(e.getMessage());
			}	
			break;
		
			
			
			
		}//end of  first switch
		
		
		
	}while(option!=2);//end of do statement
}//end of main
}//end of class
