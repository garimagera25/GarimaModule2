package com.capgemini.xyz.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.exception.LoanAppException;
import com.capgemini.xyz.util.DatabaseConnection;



public class LoanDao implements ILoanDao {
	Connection connection;
	public LoanDao() {
		connection= DatabaseConnection.getConnection();
	}
	protected void finalize(){
		try {
			connection.close();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}
	@Override
	public long insertCust(Customer customer) throws LoanAppException {
		String insQry=
				"INSERT INTO customer (Cust_id,Cust_name,Address,Email,MobileNo) values (Cust_seq.nextval,?,?,?,?) ";//it should match columns of table
		/*here*/
		try {
			PreparedStatement ps = connection.prepareStatement(insQry);
			ps.setString(1, customer.getCustName());
			ps.setString(2,customer.getAddress());
			ps.setString(3, customer.getEmail());
			ps.setString(4, customer.getMobile());
			
			
			int r= ps.executeUpdate();
			int custid=0;
			if(r==1){
					Statement st= connection.createStatement();
					ResultSet rs= st.executeQuery("select Cust_seq.currval from dual");
					if(rs.next())
						custid=rs.getInt(1);
			}
		return custid;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new LoanAppException(e.getMessage());
		}
	}
	@Override
	public double calculateEmi(double amnt, int yrs) throws LoanAppException {
		double r=9.5;
		double p=amnt;
		int n=yrs;
		n=n*12;
		double emiCalculated= (p*r*(1+r)*n)/((1+r)*(n-1));
		return emiCalculated ;
		
	}
	@Override
	public long applyLoan(Loan loan) throws LoanAppException {
		String insQry=
				"INSERT INTO Loan (Loan_id ,Loan_amt  ,Cust_id ,Duration) values (Loan_seq.nextval,?,?,?) ";//it should match columns of table
		/*here*/
		try {
			PreparedStatement ps = connection.prepareStatement(insQry);
			ps.setDouble(1, loan.getLoanAmount());
			ps.setLong(2,loan.getCustId());
			ps.setInt(3, loan.getDuration());
			
			
			int r= ps.executeUpdate();
			int loanid=0;
			if(r==1){
					Statement st= connection.createStatement();
					ResultSet rs= st.executeQuery("select Loan_seq.currval from dual");
					if(rs.next())
						loanid=rs.getInt(1);
			}
		return loanid;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new LoanAppException(e.getMessage());
		}
	}

}
