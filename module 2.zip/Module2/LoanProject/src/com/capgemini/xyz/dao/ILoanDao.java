package com.capgemini.xyz.dao;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.exception.LoanAppException;


public interface ILoanDao {
	public long insertCust(Customer customer) throws LoanAppException;

	public double calculateEmi(double amnt, int yrs) throws LoanAppException;

	public long applyLoan(Loan loan) throws LoanAppException;
}
