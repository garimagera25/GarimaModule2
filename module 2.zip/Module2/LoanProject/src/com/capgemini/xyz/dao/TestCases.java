package com.capgemini.xyz.dao;

import org.junit.Test;

import com.capgemini.xyz.exception.LoanAppException;

public class TestCases {
@Test
public void testinputs()
{
	ILoanDao dao= new LoanDao();
	try{
		int list= dao.validateCustomer(1001,'Garima','hinjewadi','1234567890');
		Assert.assertTrue(list!=0);
	}
	catch(LoanAppException e)
	{
	e.printStackTrace();	
	}
	}
	
	}

