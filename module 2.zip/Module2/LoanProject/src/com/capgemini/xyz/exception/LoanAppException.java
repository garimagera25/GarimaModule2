package com.capgemini.xyz.exception;

public class LoanAppException extends Exception {
	public LoanAppException(String msg) {
		super(msg);
}
}