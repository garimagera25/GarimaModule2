package com.capgemini.xyz.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidationService implements IValidationService {

	@Override
	public boolean validateCustomerName(String name) {
		Pattern pattern= Pattern.compile("[A-Z][a-z]{2,19}");
		Matcher matcher= pattern.matcher(name);
		return matcher.matches();
		// TODO Auto-generated method stub
//		return false;
	}

	@Override
	public boolean validateCustomerAdress(String address) {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean validateMailId(String mail) {
		Pattern pattern= Pattern.compile("[A-Za-z0-9]*@capgemini.com");
		Matcher matcher= pattern.matcher(mail);
		return matcher.matches();
	}

	@Override
	public boolean validateMobileNo(String mobno) {
		
		Pattern pattern= Pattern.compile("[0-9]{10}");

		Matcher matcher= pattern.matcher(mobno);
		return matcher.matches();
	}



}
