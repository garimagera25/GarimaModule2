package com.capgemini.xyz.service;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.dao.ILoanDao;
import com.capgemini.xyz.dao.LoanDao;
import com.capgemini.xyz.exception.LoanAppException;



public class LoanService implements ILoanService {
	ILoanDao dao;
	
	public LoanService(){
		dao= new LoanDao(); 
}
	@Override
	public long insertCust(Customer customer) throws LoanAppException {
		long id = dao.insertCust(customer);
		return id;
	}
	@Override
	public double calculateEMI(double amnt, int yrs) throws LoanAppException {
		double emiCalculated= dao.calculateEmi(amnt,yrs);
	return emiCalculated;
	}
	@Override
	public long applyLoan(Loan loan) throws LoanAppException {
		long id = dao.applyLoan(loan);
		return id;
	}

}
