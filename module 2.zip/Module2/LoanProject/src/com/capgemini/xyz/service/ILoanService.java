package com.capgemini.xyz.service;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.exception.LoanAppException;

public interface ILoanService {

	public long insertCust(Customer customer) throws LoanAppException;

	public double calculateEMI(double amnt, int yrs)throws LoanAppException;

	public long applyLoan(Loan loan)throws LoanAppException;

}
