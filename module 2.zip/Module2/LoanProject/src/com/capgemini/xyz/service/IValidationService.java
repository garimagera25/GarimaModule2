package com.capgemini.xyz.service;

public interface IValidationService {
	public boolean validateCustomerName(String name);

	public boolean validateCustomerAdress(String address);

	public boolean validateMailId(String email);

	public boolean validateMobileNo(String mobno);

	
}
