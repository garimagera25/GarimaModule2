package OCASET1;

public class EMyMethods {
	static String name="m1";
	void riverRafting()
	{
		String name="m2";
		if(8>2)
		{
			 name="m3";
			System.out.println(name);
		}
	}
	public static void main(String[] args) {
		EMyMethods m1=new EMyMethods();
		m1.riverRafting();
	}

}
