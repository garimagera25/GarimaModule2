package OCASET1;

import java.util.ArrayList;

public class ArrayL {
public static void main(String[] args) {
ArrayList<String> seasons =  new ArrayList<>();
seasons.add(1,"w");
seasons.add(2,"m");
seasons.add(3,"l");
seasons.add(4,"k");
seasons.remove(2);
for(String s:seasons)
	System.out.println(s+",");

}
}
