package OCASET1;

class Phone{
	void call()
	{
		System.out.println("call-phone");
	}
}
class SmartPhone extends Phone{
	void call()
	{
		System.out.println("call-smart");
	}
}

public class TestPhone {
public static void main(String[] args) {
	Phone phone= new Phone();
	Phone smartPhone = new SmartPhone();

	phone.call();
	smartPhone.call();
}
}
//o/p
//call-phone
//smart