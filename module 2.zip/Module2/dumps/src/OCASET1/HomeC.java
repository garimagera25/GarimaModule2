package OCASET1;

final class HomeC {
String name;
int rooms;
//HomeC(){
//	
//}

//Float HomeC(){}
//protected HomeC(int rooms){}
private HomeC(long name){}



}
