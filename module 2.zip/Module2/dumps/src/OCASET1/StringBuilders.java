package OCASET1;

public class StringBuilders {
public static void main(String[] args) {
	StringBuilder sb1 = new StringBuilder("eLion");
	String ejb = null;
	ejb = sb1.append("X").substring(sb1.indexOf("L"),sb1.indexOf("o"));
	System.out.println(sb1.indexOf("X"));
	System.out.println(sb1.indexOf("L"));
	System.out.println(ejb);
}
}
