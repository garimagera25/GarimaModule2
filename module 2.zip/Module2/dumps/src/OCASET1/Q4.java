package OCASET1;

public class Q4 {
public static void main(String[] args) {
	int a= 10;
	int b= 20;
	boolean c = false;
	
	
if(b>a)
	if(++a == 11)
		if(c==false) 
			System.out.println("condition of c is true"+c);
	
		else System.out.println("condition of c i s false"+c);
	
	else System.out.println("a condition is false"+a);
}
}
