package OCASET1;

public class typecast {
	
	
	public static void main(String[] args) {
		Byte b1 = (byte)100;
		Integer i1= (int)200;
		long l1= (long)300;
		Float f1= (float) b1+(int)11;
		String  s1 = 300;
		if(s1==(b1+i1))
			s1= (String)500;
		else
			f1 = (int)100;
		System.out.println(s1+":"+f1);
	}

}
