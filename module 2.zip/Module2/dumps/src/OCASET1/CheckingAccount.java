package OCASET1;

public class CheckingAccount {
public int amount;
public CheckingAccount(int amount)
{
	this.amount=amount;
	
	}
public int getAmount()
{
	return amount;
	}
public void changeAmount(int x)
{
	amount+=x;
	}
public static void main(String[] args) {
	CheckingAccount c=new CheckingAccount((int)(Math.random()*1000));
	
	System.out.println(c.getAmount());
}
}
