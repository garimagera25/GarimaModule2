package OCASET1;

public class Eif {
public static void main(String[] args) {
 boolean bool = false;
do{
	if(bool == false)
		System.out.println("true");
	else
		System.out.println("false");
}
while(3.3+4.7>8);

}
}
