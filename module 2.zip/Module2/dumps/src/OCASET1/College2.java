package OCASET1;


class Phone1{
	String keyboard ="in-built";
}


class Tablet extends Phone1

{
	boolean playMovie = false;
	//String ab="ab";
	
	}


public class College2 {
public static void main(String[] args) {
	Phone1 phone = new Tablet();
	//Tablet clg=new Tablet();
	
	//Tablet t = new Phone1();
	
	System.out.println(phone.keyboard+":"+phone.playMovie);
}
}
//compilation error