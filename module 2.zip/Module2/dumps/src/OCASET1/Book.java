package OCASET1;

public class Book {
	
	private int pages = 100;
}
class Magazine extends Book
{
	private int interview = 2;
	private int totalpages()
	{
		return super.pages+this.interview*5;
		//return this.pages+this.interview*5;
	//	return super.pages+ interview*5;
	}
	
	
	public static void main(String[] args) {
		System.out.println(new Magazine().totalpages());
	}
	}
