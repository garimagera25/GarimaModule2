package OCASET1;
class Persona{}
class Father extends Persona{
	public void dance() throws ClassCastException{
		System.out.println("dance");
	}
}





public class Home {
public static void main(String[] args) {
	Persona p=new Persona();
	try
	{
		((Father)p).dance();
	}catch(Throwable e)
	{
		System.out.println("in class");
	}catch( Exception e)
	{
		System.out.println("null");
	}
	catch(NullPointerException e)
	{
		System.out.println("exception");
	}
	catch(ClassCastException t)
	{
		System.out.println("throw");
	}
	finally{}
}

}
