package OCASET1;

public class QWtEST {
void readCard(int cardNo) throws Exception
{
	System.out.println("rc");
	}

void checkCard(int cardNo) throws RunTimeException
{
	System.out.println("cc");
	}

public static void main(String[] args) {
	QWtEST ex = new QWtEST();
	int cardNo= 1234;
	ex.checkCard(cardNo);
	ex.readCard(cardNo);
}
}
