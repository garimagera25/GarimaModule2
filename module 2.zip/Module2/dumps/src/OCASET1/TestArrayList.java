package OCASET1;

import java.time.LocalDate;
import java.util.ArrayList;

class Person{
	
	
}
class Emp extends Person{}

public class TestArrayList {
	public static void main(String[] args) {
		Person per=new Person();
		ArrayList<Object> list=new ArrayList<>();
		list.add(new String("1234"));
		list.add("hello");
		list.add(per);
		list.add(1);
		list.add(new Person());
		list.add(new Emp());
		list.add(new String[]{"abcd","xyz"});
		list.add(LocalDate.now().getMonth().plus(1));//line 5 compile error if getmonth is removed
	}

}
