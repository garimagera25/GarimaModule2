package OCASET1;
interface Jump{}

class Animal implements Jump{
	Jump[] eJump3= new Jump[10];
	
	Jump[] eJump2 = new Animal()[12];
	
Jump[] eJump5 = new Jump()[12];
Jump[] ejump1=new Animal[12];

	

}
