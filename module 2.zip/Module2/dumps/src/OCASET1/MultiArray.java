package OCASET1;

public class MultiArray {
String amp[][] = new String [1][2];
String amp2[][] = new String[][]{{},{}};
String amp3[][]= new String[2][2];
String amp4[][]= new String[][]{{null},new String[]{"a","b","c"},{new String()}};

String amp5[][]= new String[2][];
String amp5[][]= new String[][2];
String amp6[][]= new String [][]{"A","B"};
String amp7[][] = new String []{{"A"},{"B"}};

 }
