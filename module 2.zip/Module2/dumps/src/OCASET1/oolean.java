package OCASET1;

public class oolean {
public static void main(String[] args) {
int x=100;
int a=x++;
int b=++x;
int c=x++;
System.out.println(a);//100
System.out.println(b);//102
System.out.println(c);//102

int d=(a<b)?(a<c)?a:(b<c)?b:c:a;



System.out.println(d);
}

}
