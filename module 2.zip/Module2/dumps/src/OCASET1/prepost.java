package OCASET1;

public class prepost {
public static void main(String[] args) {
	int x=5;
	while(isa(x))
	{
		System.out.println(x);
		//System.out.println(--x);
		x--;
//		System.out.println(x);
	}
	
}
public static boolean isa(int x)
{
	return --x >=0 ?true:false;
	
}
}
