package dumps;

public class String1 {
public static void main(String[] args) {
	String str1= "Java";
	String str2= new String ("java");
	String  str3= str2;
	//if(str1==str3)//ne
	//if(str1.equalsIgnoreCase(str2))
	
	if(str1.equals(str3))
	
	{
		System.out.println("equal");
	}
	else
	{
		System.out.println("ne");
	}
	
	
	
}
}
