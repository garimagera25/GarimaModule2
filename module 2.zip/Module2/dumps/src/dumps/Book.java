package dumps;
interface Readable
{
	public void readBook();
	public void setBookMark();
}
 abstract class Book implements Readable{//1
	public void readBook()
	{
		
	}
	//2
	class EBook extends Book{ //3
		public void readBook()
		{
		
		}
/************solution*************/
		@Override
		public void setBookMark() {
			// TODO Auto-generated method stub
			
		}

		

		//4
	}

}
