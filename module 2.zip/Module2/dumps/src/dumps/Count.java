package dumps;

public class Count {
	static int count=0;
	int i=0;
	public void changeCount()
	{
		System.out.println("b"+i);
		while(i<5)
		{
			i++;
			count++;
		
		}
		
		System.out.println(i);
	}
	
	
public static void main(String[] args) {
	Count check1=new Count();
	Count check2=new Count();
	check1.changeCount();
	check2.changeCount();
	System.out.println(check1.count );
	System.out.println(check2.count);
}
}
