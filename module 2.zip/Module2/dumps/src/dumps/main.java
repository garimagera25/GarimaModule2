package dumps;

import java.util.ArrayList;
import java.util.List;

public class main {
public static void main(String[] args) {
	List<String> names= new ArrayList<>();
	names.add("robb");
	names.add("bran");
	names.add("rick");
	names.add("bran");
	if(names.remove("rick"))
	{
		names.remove("bran");
	}
	System.out.println(names);
}
}
