package dumps;

public class Length {
public static void main(String[] args) {
	String[] planets={"Mercury","Venus","Earth","Mars"};
	System.out.println(planets.length);
	System.out.println(planets[1].length());
	
	
String array[] = new String[10];
int array1[] = new int[10];

System.out.println(array1.length);

	int size = array.length;
System.out.println("size"+size);



	System.out.println("hello".length());
}
}
