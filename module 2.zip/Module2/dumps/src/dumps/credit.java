package dumps;

public class credit {
	public static String maskCC(String creditCard)
	{
		String x = "XXXX-XXXX-XXXX-";
		
		//return x+creditCard.substring(15,19);
		
		StringBuilder sb= new StringBuilder(creditCard);
		StringBuilder s = sb.insert(0, x);
	//sb.append(creditCard, 15, 19);
	return s.toString();
	}
	public static void main(String[] args) {
		System.out.println(maskCC("1234-5678-9101-1121"));
	}
}
