package BarkhaDumps;

public class Testxy {
	int x,y;
public Testxy(int x,int y)
{
	initialize(x,y);
	}
public void initialize(int m, int n) {
	// TODO Auto-generated method stub
	
	this.x=x*x;
	this.y= y*y;
	
	
}
public static void main(String[] args) {
	int x = 3;
	int y = 5;
	

	StringBuilder sb =new StringBuilder("HELLO");
sb.delete(0, sb.length());


	Testxy obj = new Testxy(x,y);
	
	
	
	System.out.println(x);
	System.out.println(y);
}

}
