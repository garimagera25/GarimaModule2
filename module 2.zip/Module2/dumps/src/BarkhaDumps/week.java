package BarkhaDumps;

public class week {
	
	
	public static void main(String[] args) {
		 int wd = 0;
		String[] days= {"sun","mon","wed","sat"};
	//	Integer x = new Integer("1");
	//	short x =1;
	//	byte x = 1;
	//	String x="1";
		
		
		for(String x:days)
		{
			switch(x)
			{
//			case 1:
//				break;
			case "sat":
			case "sun":
				wd-=1;
				break;
			case "mon":
				wd++;
			case "wed":
				wd+=2;
				
					
				}	
			
			}
		System.out.println(wd);
	}





}
