package BarkhaDumps;

import java.time.LocalDate;

public class PlusDays {
public static void main(String[] args) {
	LocalDate d= LocalDate.of(2012, 01, 32);
	System.out.println(d.plusDays(10));
	System.out.println(d);
}
}
