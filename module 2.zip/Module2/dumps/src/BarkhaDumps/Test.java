package BarkhaDumps;

import java.util.ArrayList;
import java.util.List;



class Patient{
	String name;
public Patient(String name)
{
	this.name=name;
	}

}

public class Test {
	public static void main(String[] args) {
		List ps = new ArrayList();
		Patient p2 = new Patient("mike");
		ps.add(p2);
		//int f = ps.indexOf(p2);
//		//option 1
//		Patient p = new Patient("mike");
//		int f = ps.index
		
//		Patient p = new Patient ("Mike");
//		int f = ps.indexOf(p);
		int f = ps.indexOf (patient("Mike"));
		//line 14 
		if(f>=0)
		{
			System.out.println("mike found");
			
		}
		
		
	}
}
