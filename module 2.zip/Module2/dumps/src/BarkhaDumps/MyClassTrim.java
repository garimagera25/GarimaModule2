package BarkhaDumps;



public class MyClassTrim {
public static void main(String[] args) {
	String s=" JAVA DUKE ";
	int l=s.trim().length();
	System.out.println(l);
}
}
