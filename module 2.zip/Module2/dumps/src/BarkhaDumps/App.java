package BarkhaDumps;

public class App   {
	 int count;
	 
	public static void dmsg()
	{
		count++;
		System.out.println("hsgfcjh"+count);
	}
	public static void main(String[] args) {
		App.dmsg();
		
	}
}
