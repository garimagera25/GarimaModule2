package BarkhaDumps;
  class C2{
	public void displayc2()
	{
		System.out.println("c2");
	}
	
	
	
}

  

interface I1
{
	public void display();
}
public class InterfaceImplC extends C2 implements I1 {
	
	
	protected static final int i=0;
	private static int ipy;
	
	
	
	
	@Override
	public void display() {
		System.out.println("c1");
		
	}
public static void main(String[] args) {
	C2 obj= new  InterfaceImplC();
	I1 obj2 = new InterfaceImplC();
	C2 s =  obj2;
	
}
}
