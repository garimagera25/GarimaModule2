package BarkhaDumps;



public class Test1 {
public static int stvar=100;
public int var=200;


@Override
public String toString() {
	return  var+ ""+stvar;
}


public static void main(String[] args) {
	Test1 t1=new Test1();
	t1.var=300;
	System.out.println(t1);
	Test1 t2=new Test1();
	t2.stvar=300;
	System.out.println(t2);
}
}
