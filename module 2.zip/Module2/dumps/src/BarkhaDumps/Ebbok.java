package BarkhaDumps;
interface D
{
	public void download();
	}
interface R extends D
{
	public void readbook();
	}
abstract class Book implements R
{
	public void readbook()
	{
		System.out.println("read book");
	}
}
public class Ebbok extends Book {//line 3
	
	public void readbook()
	{
		System.out.println("read Ebook");
	}

//	@Override
//	public void download() {
//		// TODO Auto-generated method stub
//		
//	}
}
