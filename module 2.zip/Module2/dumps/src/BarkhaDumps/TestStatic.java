package BarkhaDumps;

public class TestStatic {
public static void main(String[] args) {
	int num[]={12,23,24,56,77};
	int m=findMax(num);
}

 public int findMax(int[] num) {
	// TODO Auto-generated method stub
	return 0;
}

}
