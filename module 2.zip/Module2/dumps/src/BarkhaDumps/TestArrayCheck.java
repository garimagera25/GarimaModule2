package BarkhaDumps;
class Student{
	String name;
	public Student(String name) {
		// TODO Auto-generated constructor stub
		this.name=name;
	}
}
public class TestArrayCheck {
public static void main(String[] args) {
	Student[] students=new Student[3];
	students[1]=new Student("dfcds");
	students[2]=new Student("fgd");
	
	

	
	
	for(Student s:students)
	{
		System.out.println(s.name);
	}
	
}
}
