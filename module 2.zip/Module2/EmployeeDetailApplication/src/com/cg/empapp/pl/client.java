package com.cg.empapp.pl;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import com.cg.empapp.dto.Dept;
import com.cg.empapp.dto.EmployeeDetails;
import com.cg.empapp.exception.EmployeeException;
import com.cg.empapp.service.ValidationService;
import com.cg.empapp.service.ValidationServiceImpl;
import com.cg.empapp.exception.EmployeeException;
import com.cg.empapp.service.EmployeeDetailsService;
import com.cg.empapp.service.EmployeeDetailsServiceImpl;







public class client {
	public static void main(String[] args) {
		EmployeeDetails employee = new EmployeeDetails();
		Dept dept = new Dept();
		ValidationService validation=new ValidationServiceImpl();
		EmployeeDetailsService service= new EmployeeDetailsServiceImpl();
		

		Scanner sc= new Scanner(System.in);
		int option=0;
		do{
			System.out.println("\n\n1. Add Employee Details ...");
			System.out.println("2.Enter dept id Display All Employee details in list ...");
			System.out.println("3. Enter Employee id to get details of respctive ...");
			System.out.println("4. Update Employee salary ");
//			System.out.println("5. Enter employee id to Delete Employee from records ");
			System.out.println("7. Exit");
			System.out.println("Enter Choice .");
			 option= sc.nextInt();
			switch(option){
			case 1:
				do{
					System.out.println("Enter Employee First Name : ");
					String fname=sc.next();
					boolean res=validation.validateEmployeeName(fname);
					if(res==true)
					{
						employee.setFirstName(fname);
						break;
					}
					else
						System.out.println("Name should contain only alphabets");
					}while(true);
				do{
					System.out.println("Enter Employee Last Name : ");
					String lname=sc.next();
					boolean res=validation.validateEmployeeName(lname);
					if(res==true)
					{
						employee.setLastName(lname);
						break;
					}
					else
						System.out.println("Name should contain only alphabets");
					}while(true);
				do{
					System.out.println("Gender : ");
					String gender=sc.next();
					boolean res=validation.validateGender(gender);
					if(res==true)
					{
						employee.setGender(gender);
						break;
					}
					else
						System.out.println("gender is not valid");
					}while(true);
				do{
					System.out.println("Enter Employee Email : ");
					String email=sc.next();
					boolean res=validation.validateMailId(email);
					if(res==true)
					{
						employee.setEmail(email);
						break;
					}
					else
						System.out.println("email is not valid");
					}while(true);
				do{
					System.out.println("Enter mobile No :");
					String mobno= sc.next();
					boolean res=validation.validateMobileNo(mobno);
					if(res)
					{
						employee.setMobileNo(mobno);
						break;
					}
					else
						System.out.println("Mobile no shoule be 10 digit.");
				}while(true);
				
				do{
					LocalDate jd;
					try {
						System.out.println("Enter Date of join (dd/MM/yyyy) : ");
						String date= sc.next();
						DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
						jd = LocalDate.parse(date, formatter);
						employee.setJod(jd);
						break;
					} catch (Exception e) {
						System.out.println("Invalid date entered..");
					}
					}while(true);
				do{
					System.out.println("Enter salary :");
					int salary= sc.nextInt();
					boolean res=validation.validateSalary(salary);
					if(res)
					{
						employee.setSalary(salary);
						break;
					}
					else
						System.out.println("salary shoule be positive.");
				}while(true);
				
				System.out.println("Enter department no");
				int deptNo=sc.nextInt();
				employee.setDeptNo(deptNo);
				
				
				try {
					int empid= service.addEmployee(employee);
					System.out.println("Employee added : "+ empid );
				} catch (EmployeeException e) {
					System.out.println(e.getMessage());
				}	
				break;
				
			case 2:
				System.out.println("Enter dept no. ");
				int deptno=sc.nextInt();
				try {
					List<EmployeeDetails> employees= service.getEmployeeList(deptno);
					if(employees.size()>0){
					for(EmployeeDetails empd :employees ){
						System.out.println(empd.getFirstName()+" "+ empd.getLastName()+" "+ empd.getGender()+" "+
								empd.getEmail()+" "+empd.getDeptNo()+" "+empd.getGender()+" "+
								empd.getMobileNo()+" "+empd.getSalary());
					}
					}
					else
						System.out.println("No Employee records available");
				} catch (EmployeeException e) {
					System.out.println(e.getMessage());
				}
				
				break;
			case 3:
				System.out.println("Enter employee id  :  ");
				int empid= sc.nextInt();
				try {
					employee =service.getemployeeDetails(empid);
					
					System.out.println(employee.getFirstName()+" "+ employee.getLastName()+" "+ employee.getGender()+" "+
					                   employee.getEmail()+" "+employee.getDeptNo()+" "+employee.getGender()+" "+
					                   employee.getMobileNo()+" "+employee.getSalary());
				
				} catch (EmployeeException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 4:
				System.out.println("Enter salary ");
				int sal= sc.nextInt();
				System.out.println("enter employee id ");
				int empid1= sc.nextInt();
				employee.setEmpId(empid1);
				employee.setSalary(sal);
				
			try {
				int rev= service.updateEmployee(employee);
				if(rev==1)
					System.out.println("quantity updated successfully ");
				else
					System.out.println("employee record not available");
			} catch (EmployeeException e) {
				System.out.println(e.getMessage());
			}				
			break;
				
		}

//		
			
			}
		while(option!=7);
		
	}

}
