package com.cg.empapp.dto;
import java.sql.Date;
import java.time.LocalDate;


public class EmployeeDetails {
private String firstName;
private String lastName;
private String gender;
private String email;
private String mobileNo;
private LocalDate jod;
private double salary;
private int deptNo;
private int empId;

public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getGender() {
	return gender;
}
public void setGender(String gender2) {
	this.gender = gender2;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getMobileNo() {
	return mobileNo;
}
public void setMobileNo(String mobno) {
	this.mobileNo = mobno;
}
public LocalDate getJod() {
	return jod;
}
public void setJod(LocalDate jd) {
	this.jod = jd;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}
public int getDeptNo() {
	return deptNo;
}
public void setDeptNo(int deptNo) {
	this.deptNo = deptNo;
}
public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
}
