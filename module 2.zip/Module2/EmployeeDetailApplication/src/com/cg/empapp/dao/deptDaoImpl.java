package com.cg.empapp.dao;

public class deptDaoImpl {

}
