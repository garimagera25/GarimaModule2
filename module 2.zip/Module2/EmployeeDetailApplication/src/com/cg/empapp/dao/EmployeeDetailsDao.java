package com.cg.empapp.dao;

import java.util.List;

import com.cg.empapp.dto.EmployeeDetails;
import com.cg.empapp.exception.EmployeeException;

public interface EmployeeDetailsDao {
	public int addEmployee(EmployeeDetails employee)throws EmployeeException;
	public EmployeeDetails getemployeeDetails(int id) throws EmployeeException;
	
	public int deleteemployee(int id) throws EmployeeException;
//	List<EmployeeDetails> getEmployeeList() throws EmployeeException;
	List<EmployeeDetails> getEmployeeList(int deptno) throws EmployeeException;
	public int updateEmployee(EmployeeDetails emp) throws EmployeeException;
	

}
