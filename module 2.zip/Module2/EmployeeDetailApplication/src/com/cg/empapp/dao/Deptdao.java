package com.cg.empapp.dao;



public interface Deptdao {
	
}
