package com.cg.empapp.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.empapp.dto.EmployeeDetails;
import com.cg.empapp.exception.EmployeeException;
import com.cg.empapp.util.DatabaseConnection;






public class EmployeeDetailsDaoImpl implements EmployeeDetailsDao {
	Connection connection;
	public EmployeeDetailsDaoImpl() {
		connection= DatabaseConnection.getConnection();
	}
	protected void finalize(){
		try {
			connection.close();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}
	@Override
	public int addEmployee(EmployeeDetails employee) throws EmployeeException {
		
		String insQry=
				"INSERT INTO EMPLOYEE (EMPLOYEE_ID,fname, lname,gender,email,MOBILE_NO,HIREDATE,salary,dept_no) values (EMPLOYEE2_ID_seq.nextval,?,?,?,?,?,?,?,?) ";//it should match columns of table
		/*here*/
		try {
			PreparedStatement ps = connection.prepareStatement(insQry);
			
			ps.setString(1, employee.getFirstName());
			ps.setString(2,employee.getLastName());
			ps.setString(3, employee.getGender());
			ps.setString(4, employee.getEmail());
			ps.setString(5, employee.getMobileNo());
			Date date= Date.valueOf(employee.getJod());
			ps.setDate(6,date);
			ps.setDouble(7,employee.getSalary());
			ps.setInt(8,employee.getDeptNo());
			
			int r= ps.executeUpdate();
			int empid=0;
			if(r==1){
					Statement st= connection.createStatement();
					ResultSet rs= st.executeQuery("select EMPLOYEE2_ID_seq.currval from dual");
					if(rs.next())
						empid=rs.getInt(1);
			}
		return empid;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		
		
	}
	@Override
	public EmployeeDetails getemployeeDetails(int id) throws EmployeeException {
		EmployeeDetails employee= new EmployeeDetails();
		String selQry= "select EMPLOYEE_ID,fname, lname,gender,email,MOBILE_NO,salary,dept_no from employee  where EMPLOYEE_ID=?";
		try {
			PreparedStatement ps= connection.prepareStatement(selQry);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			if(rs.next()){
					employee.setEmpId(rs.getInt(1));
					employee.setFirstName(rs.getString(2));
					employee.setLastName(rs.getString(3));
					employee.setGender(rs.getString(4));
					employee.setMobileNo(rs.getString(5));
					employee.setSalary(rs.getInt(6));
//					employee.setJod(rs.getDate(7));
					employee.setDeptNo(rs.getInt(7));
					
			}
			else 
			throw new EmployeeException("Employee id does not exist");
			
		} catch (SQLException e) {
			throw new EmployeeException(e.getMessage());
		}
		return employee;	
		// TODO Auto-generated method stub
	
	}
	

	
	
	@Override
	public List<EmployeeDetails> getEmployeeList(int deptno) throws EmployeeException {
	
		String selQry= "select EMPLOYEE_ID,fname, lname,gender,email,MOBILE_NO,salary,dept_no from employee where dept_no=? ";
		List<EmployeeDetails> employeelist= new ArrayList<EmployeeDetails>();
		try {
			PreparedStatement ps= connection.prepareStatement(selQry);
			ps.setInt(1, deptno);
			ResultSet rs= ps.executeQuery();
			
			while( rs.next()){
				EmployeeDetails empd= new EmployeeDetails ();
				empd.setEmpId(rs.getInt(1));
				empd.setFirstName(rs.getString(2));
				empd.setLastName(rs.getString(3));
				empd.setGender(rs.getString(4));
				empd.setEmail(rs.getString(5));
				empd.setMobileNo(rs.getString(6));
				empd.setSalary(rs.getInt(7));
//				empd.setJod(rs.getDate(7));
				empd.setDeptNo(rs.getInt(8));
				employeelist.add(empd);
			}			
		} catch (SQLException e) {
			throw new EmployeeException(e.getMessage());
		}		
		return employeelist;
	}

	
	@Override
	public int deleteemployee(int id) throws EmployeeException {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public int updateEmployee(EmployeeDetails emp) throws EmployeeException {
		String updateQry= "update employee set salary=? where EMPLOYEE_ID=?";
		try {
			PreparedStatement ps= connection.prepareStatement(updateQry);
			ps.setDouble(1, emp.getSalary());
			ps.setInt(2, emp.getEmpId());
			int rs= ps.executeUpdate();
			return rs;
		} catch (SQLException e) {
			throw new EmployeeException(e.getMessage());
		}
	}
	
	
}
