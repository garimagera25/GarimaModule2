
package com.cg.empapp.service;

import java.util.List;

import com.cg.empapp.dto.EmployeeDetails;
import com.cg.empapp.exception.EmployeeException;


public interface EmployeeDetailsService {

	int addEmployee(EmployeeDetails employee) throws EmployeeException;

	EmployeeDetails getemployeeDetails(int empid) throws EmployeeException;

	List<EmployeeDetails> getEmployeeList(int deptno) throws EmployeeException;

	int updateEmployee(EmployeeDetails employee)throws EmployeeException;

//	List<EmployeeDetails> getEmployeeList() throws EmployeeException;



	

}
