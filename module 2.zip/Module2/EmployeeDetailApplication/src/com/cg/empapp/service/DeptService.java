package com.cg.empapp.service;

public class DeptService {

}
