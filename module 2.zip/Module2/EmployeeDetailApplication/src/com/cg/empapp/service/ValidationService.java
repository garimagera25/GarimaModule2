package com.cg.empapp.service;

public interface ValidationService {
	public boolean validateEmployeeName(String name);

	boolean validateMailId(String mailid);

	public boolean validateGender(String gender);

	boolean validateMobileNo(String mobno);

	public boolean validateSalary(int salary);

	
}
