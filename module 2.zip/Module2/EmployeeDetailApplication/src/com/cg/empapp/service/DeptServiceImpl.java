package com.cg.empapp.service;

public class DeptServiceImpl {

}
