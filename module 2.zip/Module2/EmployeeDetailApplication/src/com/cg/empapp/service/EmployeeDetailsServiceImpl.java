package com.cg.empapp.service;

import java.util.List;

import com.cg.empapp.dto.EmployeeDetails;
import com.cg.empapp.dao.EmployeeDetailsDao;
import com.cg.empapp.dao.EmployeeDetailsDaoImpl;
import com.cg.empapp.exception.EmployeeException;
import com.cg.empapp.dto.EmployeeDetails;


public class EmployeeDetailsServiceImpl implements EmployeeDetailsService {
	EmployeeDetailsDao dao;
	
	
	
	public EmployeeDetailsServiceImpl(){
			dao= new EmployeeDetailsDaoImpl(); 
	}
	@Override
	public int addEmployee(EmployeeDetails employee)  throws EmployeeException{
		int id = dao.addEmployee(employee);
		return id;
	}
	@Override
	public EmployeeDetails getemployeeDetails(int empid)
			throws EmployeeException {
		EmployeeDetails employee=dao.getemployeeDetails(empid);
		// TODO Auto-generated method stub
		return employee;
//		return null;
	}
//	@Override
//	public List<EmployeeDetails> getEmployeeList()
//			throws EmployeeException {	
//		return getEmployeeList();
//		// TODO Auto-generated method stub
////		return null;
//	}
	@Override
	public List<EmployeeDetails> getEmployeeList(int deptno) throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.getEmployeeList(deptno);
	}
@Override
public int updateEmployee(EmployeeDetails emp) throws EmployeeException {
	return dao.updateEmployee(emp);
}
	
	
}
