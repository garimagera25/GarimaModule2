

public class author {
String ISBN;
author(String val)
{
	ISBN = val;
	}
}

class TestEquals{
public static void main(String[] args) {
	author b1 = new author("1234-4657");
	author b2 = new author("1234-4657");
	System.out.println(b1.equals(b2)+":");
	System.out.println(b1==b2);
}
}
