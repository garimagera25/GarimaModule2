package com.cg.mobapp.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.mobapp.dao.MobileDao;
import com.cg.mobapp.dao.MobileDaoImpl;
import com.cg.mobapp.dto.Mobile;
import com.cg.mobapp.exception.MobileException;
import com.sun.xml.internal.ws.api.server.Module;

public class MobileServiceImpl implements MobileService {
MobileDao dao; //from this service we are calling dao methods so we need to make objects of dao
public MobileServiceImpl()
{
	dao=new MobileDaoImpl();
	}

@Override
public int addMobile(Mobile mobile) throws MobileException {
	
	
	int id= dao.addMobile(mobile);
	return id;
	
	// TODO Auto-generated method stub
//	return 0;
}

@Override
public Mobile getMobileDetails(int id) throws MobileException {
	return dao.getMobileDetails(id);
	// TODO Auto-generated method stub
//	return null;
}

@Override
public int updateMobile(Mobile mob) throws MobileException {
	// TODO Auto-generated method stub
	return 0;
}

@Override
public int deleteMobile(int id) throws MobileException {
	// TODO Auto-generated method stub
	return 0;
}

@Override
public List<Mobile> getMobile() throws MobileException {
	return dao.getMobile();
	// TODO Auto-generated method stub
//	return null;
}


}
