package com.cg.mobapp.dto;

public class Customer {

}
