package com.cg.mobapp.dto;

import java.time.LocalDate;

public class PurchaseDetails {
private int purchaseId;
private String custName;
private String maildid;
private LocalDate purchaseDate;


}
