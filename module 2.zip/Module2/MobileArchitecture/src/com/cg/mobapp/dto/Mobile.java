package com.cg.mobapp.dto;

public class Mobile {
private double price;
private int quantity;
private int MobileID;
private String MobileName;
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
public int getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity = quantity;
}
public int getMobileID() {
	return MobileID;
}
public void setMobileID(int mobileID) {
	MobileID = mobileID;
}

public void setMobileName(String mobileName) {
	MobileName = mobileName;
}
public String getMobileName() {
	// TODO Auto-generated method stub
	return MobileName;
//	return null;
}

}
