package com.cg.mobapp.pl;

import java.util.List;
import java.util.Scanner;

import com.cg.mobapp.dto.Mobile;
import com.cg.mobapp.exception.MobileException;
import com.cg.mobapp.service.MobileService;
import com.cg.mobapp.service.MobileServiceImpl;
//import com.sun.xml.internal.bind.v2.schemagen.xmlschema.List;
public class Client {
public static void main(String[] args) {
	Mobile mobile = new Mobile();
	MobileService service = new MobileServiceImpl();
	Scanner sc= new Scanner(System.in);
	System.out.println("eneter mobile name:");
	String name= sc.next();
	System.out.println("eneter price");
	double price= sc.nextDouble();
	System.out.println("enter quantity");
	int quantity=sc.nextInt();
	
	
	mobile.setMobileName(name);
	mobile.setPrice(price);
	mobile.setQuantity(quantity);
	try{
		int mobileid = service.addMobile(mobile);
		System.out.println("Mobile added:"+mobileid);
		
	}
	catch(MobileException e)
	{
		System.out.println(e.getMessage());
	}
	
	
	
	try{
		List<Mobile> mobiles = service.getMobile();
		if(mobiles.size()>0){
			for(Mobile mob: mobiles)
			{
				System.out.println(mob.getMobileName()+" "+ mob.getPrice()+" "+ mob.getMobileID()+" "+mob.getQuantity());}
			}
	else
		System.out.println("no records");
}
	catch(MobileException e)
	{
		System.out.println(e.getMessage());
	}
	
	
	//display mobile details for specific mobile id
	System.out.println("eneter mobile id");
	int mobileid=sc.nextInt();
	try{
	 mobile = service.getMobileDetails(mobileid);
	System.out.println(mobile.getMobileName()+" "+ mobile.getPrice()+" "+ mobile.getMobileID()+" "+mobile.getQuantity());
	}
	catch(MobileException e)
	{
		System.out.println(e.getMessage());
	}
	
}
}

