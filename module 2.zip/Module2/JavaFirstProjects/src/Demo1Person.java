
public class Demo1Person implements Comparable<Demo1Person> {
private String name;
private int age;
private String aadharNo;
public Demo1Person(String name,int age,String ano)
{
	this.aadharNo=ano;
	this.age=age;
	this.name=name;
	}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public String getAadharNo() {
	return aadharNo;
}
public void setAadharNo(String aadharNo) {
	this.aadharNo = aadharNo;
}

//to string is necessary for getting output in form otherwise it will result in object  
@Override
public String toString()
{
	return name+" "+age+aadharNo;
	}
@Override
public int compareTo(Demo1Person Demo1Person)
{
	return this.name.compareTo(Demo1Person.getName());
	}
}
