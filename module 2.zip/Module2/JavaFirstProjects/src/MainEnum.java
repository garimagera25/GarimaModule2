

public class MainEnum {
	public static void main(String[] args) {
		Months mon = Months.FEB;
		mon.display();
	}
}
