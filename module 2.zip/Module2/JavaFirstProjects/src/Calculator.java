/*******basic example 
public class Calculator<T> {
	private T num1;
	private T num2;
	public void add(T num1,T num2)
	{
//		System.out.println(num1-num2);
	}
public static void main(String[] args) {
	Calculator<Double> cal = new Calculator();
	cal.add(34.55,63.86);	
}
}

****/
import java.util.ArrayList;
public class Calculator{
	public static void printMaxNumber(ArrayList<?super Integer>List)
	{
		
	}
	public static void main(String[] args) {
		ArrayList<Integer> list1=new ArrayList<>();
		ArrayList<Object> list2=new ArrayList<>();
		ArrayList<Double> list3=new ArrayList<>();
		
		ArrayList<String> list4= new ArrayList();
		ArrayList<Number> list5= new ArrayList();
		printMaxNumber(list1);//inetger is not super class of number
		printMaxNumber(list2);//object is superclass of number
//		printMaxNumber(list3);
//		printMaxNumber(list4);
		printMaxNumber(list5); //number is super class of integer
	}
}
