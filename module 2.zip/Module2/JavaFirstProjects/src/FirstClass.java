import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.Scanner;
import java.time.DayOfWeek;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class FirstClass {
	public static void main(String[] args) {
		System.out.println(args[0]);
		System.out.println(args[1]);
		System.out.println("Hello");
		
		int num = 0;
		
		
		
		System.out.println(num);
		
		
		
		int a = Integer.parseInt(args[0]);
		int b= Integer.parseInt(args[1]);
		System.out.println(a+b);
		
		
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter First Name");
		String name = sc.next();
		System.out.println("Enter account no");
		int accno = sc.nextInt();
		System.out.println("Enter balance");
		double balance = sc.nextDouble();
		System.out.println(name+" "+accno+" "+balance);
//		sc.close(); CLOSE AFTER TAKING ALL THE INPUTS
		
		
		long old = System.currentTimeMillis();
		for(long i = 1;i<=9999900;i++);
		{
			long New= System.currentTimeMillis();
			System.out.println("for loop "+(New-old));
		}
		
		
		///****************************************************strings*********************/
		String str="java";
		int len = str.length();
		System.out.println(len);
		
		
//		/*************date and time********************************/
		LocalDate date=LocalDate.now();
		System.out.println("Today is :"+date);
		
		LocalDate date2 = LocalDate.of(2000,4,25);
		System.out.println(date2);
		
		Month mon= date.getMonth();
		String nameM = mon.name();
		System.out.println("Month name:"+nameM);
		int yr= date.getYear();
		System.out.println("year is"+yr);
		int day = date.getDayOfMonth();
		System.out.println("no of day are:"+day);
		
		
		DayOfWeek dayOfWeek = date.getDayOfWeek();
		String dayname = dayOfWeek.name();
//		dayOfWeek.getvalue();
		System.out.println("day name"+dayname);
		
		
		LocalDate dt1 = date.plusDays(30);
		System.out.println("date after 3 days:"+dt1);
		
		LocalDate dt = date.withYear(2016);
		System.out.println(dt);
		 
		LocalDate dt11 = LocalDate.of(2000,4,25);
		LocalDate dt2=LocalDate.now();
		boolean res=dt11.isAfter(dt2);
		
		System.out.println(res);
		
		Period period = Period.between(dt11, dt2);
		System.out.println("period"+period);
		
		Period period1 = Period.of(3,2,10);
		Duration duration = Duration.ofHours(4);
		
		LocalDateTime time1 = LocalDateTime.of(2010,03,1,10,20,00,00);
		LocalDateTime time2 = LocalDateTime.of(2010,03,4,10,20,00,00);
		Duration duration1 = Duration.between(time1, time2);
		System.out.println("duartion is"+duration1);
		
		LocalDate currentDate=LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy ,MMMM dd -E");
		//E is for day
		String formattedDate=formatter.format(currentDate);
		System.out.println(formattedDate);
		
//		Scanner sc = new Scanner(System.in); WE DO NOT INITIALIZE IT AGAIN
		System.out.println("Enter Date (dd/mm/yyyy):");
		//dd/Mon/yyyy is for 25/Dec/1995
		//dd/mm/yyyy is for 25/12/1995
		String dtt = sc.next();
		DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate date3 = LocalDate.parse(dtt,formatter1);
		System.out.println(date3);
		sc.close();
	}
	
	

}
