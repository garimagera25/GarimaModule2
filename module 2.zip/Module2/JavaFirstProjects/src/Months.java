
public enum Months {
	JAN(31,"January"),FEB(28,"Febraury"),MAR(31,"March"),APR(30,"April"),MAY(31,"May"),JUN(30,"June"),
	JUL(31,"July"),AUG(31,"August"),SEP(30,"September"),OCT(31,"October"),NOV(30,"November"),DEC(31,"December");
	
	int days;
	String name;
	Months(int days,String name)
	{
		this.days=days;
		this.name=name;
	}
	
	public void display()
	{
		System.out.println(days);
		System.out.println(name);
	}
}
