package com.cg.jdbc.demo;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.DriverManager;
import java.sql.SQLException;

//import com.sun.corba.se.pept.transport.Connection;
import java.sql.Connection;
import java.util.Properties;
public class DatabaseConnection {
public static Connection getconnection(){
	Connection con=null;
//	String url="jdbc:oracle:thin:@localhost:1521:xe";
//	String user="System";
//	String password="corp123";
	String url;
	String user;
	String password;
	String driver;
	try{
		/*for reading property*/
		InputStream file= new FileInputStream("./resources/jdbc.properties");
		Properties prop =new Properties();
		prop.load(file);
		url=prop.getProperty("url");
		user=prop.getProperty("username");
		password=prop.getProperty("password");
		driver= prop.getProperty("driver");
		Class.forName(driver);	
	Class.forName("oracle.jdbc.driver.OracleDriver");
	con= DriverManager.getConnection(url,user,password);
	System.out.println("database connected..");
	file.close();
	}
	catch(ClassNotFoundException e)
	{
		System.out.println("driver class not loaded");
	}
	catch(SQLException e)
	{
		System.out.println("error while connecting");
	}
	catch(IOException e)
	{
		System.out.println("file not open");
	}
	return con;	
}
public static void main(String[] args) {
	getconnection();
}

}