package com.cg.jdbc.demo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class UpdateDemo {
public static void main(String[] args) {
	Connection con=DatabaseConnection.getconnection();
	String updateQuery="UPDATE employee_masters set salary=salary+? where dept_id=?";
						
				PreparedStatement ps;
	try{
		ps= con.prepareStatement(updateQuery);
		ps.setDouble(1,500);
		ps.setInt(2,1);
	
		int r = ps.executeUpdate();
		System.out.println(r+"rows updated");
	}
	catch(SQLException e)
	{
		e.printStackTrace();
	}
}
}
