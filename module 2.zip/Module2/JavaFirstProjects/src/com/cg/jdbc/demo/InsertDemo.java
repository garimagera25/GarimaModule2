//to be written in command prompt
//create or replace procedure getEmpDetails(empid number,ename out  varchar,sal out number)
//as
//begin
//select empname,salary into ename,sal
//from employee_masters
//where empid=empid;
//end;
//
//
//
//create sequence emp_id_seq start with 1000;



package com.cg.jdbc.demo;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

public class InsertDemo {
public static void main(String[] args) {
	Connection con = DatabaseConnection.getconnection();
//	String insQuery= "insert into employee_masters"
//	+"(empid,empname,salary,joindate,dept_id)"
//			+"values(?,?,?,?,?)";
//	
	String insQuery= "insert into employee_masters"
			+"(empid,empname,salary,joindate,dept_id)"
					+"values(emp_id_seq.nextval,?,?,sysdate,?)";
	/***********for delete***************/
//	String delQuery="DELETE FROM employee_masters WHERE dept_id=?";
//	PreparedStatement ps1;
//	try{
//		ps1=con.prepareStatement(delQuery);
//		ps1.setInt(1,1);
//		
//		int ro=ps1.executeUpdate();
//		System.out.println(ro+"rows deleted..");
//		
		
		/************here******************/
		/***************************************************insert ***********************************/
		try{
	PreparedStatement ps = con.prepareStatement(insQuery);
//		ps.setInt(1, 101);
		ps.setString(1,"cdhc");
		ps.setDouble(2,34000);
		ps.setInt(3,1);
		int r=ps.executeUpdate();
//		LocalDate jd=LocalDate.of(2016, 12, 24);
//		ps.setDate(4,Date.valueOf(jd));
		
		/***for current date**********/
		
		String autoql="select emp_id_seq.currval from dual";
		Statement stmt=con.createStatement();
		ResultSet rs=stmt.executeQuery(autoql);
		int empid=0;
		if(rs.next())
			empid=rs.getInt(1);
		System.out.println("employee record inserted with empid"+empid);
		
		
		/*****till here**********/
		
		System.out.println("ecxecuted");
		
		System.out.println(r+"rows inserted..");
	}
	catch(SQLException e)
	{
		e.printStackTrace();
	}
}
}
