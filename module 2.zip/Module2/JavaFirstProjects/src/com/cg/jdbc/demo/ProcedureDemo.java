package com.cg.jdbc.demo;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

public class ProcedureDemo {
public static void main(String[] args) {
	Connection con=DatabaseConnection.getconnection();
	String procCall ="{call getEmpDetails(?,?,?)}";
	try{
		CallableStatement cs=con.prepareCall(procCall);
		cs.setInt(1,129);
		cs.registerOutParameter(2, Types.VARCHAR);
		cs.registerOutParameter(3, Types.DOUBLE);
		cs.execute();
		String name= cs.getString(2);
		double salary = cs.getDouble(3);
		System.out.println(name+" "+salary);
	}
	catch(SQLException e)
	{
		e.printStackTrace();
	}
}
}
