package com.cg.jdbc.demo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SelectDemo {
public static void main(String[] args) {
	Connection conn=DatabaseConnection.getconnection();
	String selQuery = "select dept_id,deptname from department_masters";
	//static query--same no. of records
	try{
	Statement stmt= conn.createStatement();
	ResultSet rs=stmt.executeQuery(selQuery);
	while(rs.next())
	{
		int dept_id=rs.getInt(1);
		String deptname=rs.getString(2);
		//1 and 2 on base of selquery
	System.out.println(dept_id+" "+deptname);
	}
	rs.close();
	conn.close();
	}
	
	catch(SQLException e)
	{
		e.printStackTrace();
	}
}
}
