package com.cg.regex;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexDemo {
public static void main(String[] args)
{
	String str="11:32:43:74";
	String nums[]=str.split(":");
	
	for(int i=0;i<nums.length;i++)
	System.out.println(nums[i]);
	
	String str1="Hello ,How are you?";
	str1=str1.replaceAll("are", "about");
	System.out.println(str1);
	
	String str2="Hello ,How are you , How is the day?";
	str2=str2.replaceAll("[A-Z]", "regex"); //uppercase is replaced by regex
	System.out.println(str2);
	/****************************pattern*************************/
	Pattern pattern = Pattern.compile("^[A-Z][a-z]*$"); //^ should start with uppercase $ should end with lowercase * means 0 or more + mens 1 or more
//	for mobile no.                     "^[0-9]{10}$"  ????but accept mobile no. as string

	Scanner sc= new Scanner(System.in);
	System.out.println("enetr your name:");
	String strm = sc.next();
	Matcher matcher = pattern.matcher(strm);
	boolean res = matcher.matches();
	
	if(res)
	System.out.println("name is valid");
	else
		System.out.println("invalid name");
	
			}
}
