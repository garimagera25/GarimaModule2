package com.cg.banking.app;
public class DemoClass
{
private int accountNo;
private String accountHolderName;
private double balance;
private static double interestRate;
private String accountType;
	static
	{
		//static constructor
		interestRate=6.0;
	}
	public DemoClass()
	{
		//default constructor
	}
	public DemoClass(int accno ,String name ,double balance)
	{
		//parameterised constructor
		accountNo = accno;
		accountHolderName = name;
		this.balance = balance;
	}
	public DemoClass(int accno ,String name,double balance,double rate ,String type)
	{
		this(accno,name,balance);
		interestRate=rate;
		this.accountType =type;
	}
	
	//function to change interest
	public static void changeInterestRate(double rate)
	{
		interestRate=rate;
	}
	//getter and setter
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public double getInterestRate() {
		return interestRate;
	}
	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public void withdraw(double amount)
	{
		if(balance<amount)
		{
			System.out.println("Insuuficient balance");
		}
		else
		{
			balance=balance-amount;
			System.out.println(amount+"Rs debited from ur account");
		}
	}
	void deposit(double amount)
	{
		balance = balance+amount;
		System.out.println(amount+"Rs credited to ur account");
	}
	public void printAccountDetails()
	{
		System.out.println("accNo:"+accountNo);
		System.out.println("Account Holder Name:"+accountHolderName);
		System.out.println("Balance:"+balance);
		
	}
	
	public String toString()
	{
		return accountNo+ ":" +accountHolderName ;
	}
}