
package com.cg.inheriatnce;
public class Shape {
	String name;
	Shape()
	{
		System.out.println("default cons shape");
	}
	public void draw()
	{
		System.out.println("we can draw");
	}
	/*********************************************************final keyword********************************************************/
	//in any of child class no one should override this draw method
//	public final void draw()
//public final class shape	---------------------means no one can inherit this class
	
	
}

/******************abstract method********************/
// only declaration no definition 
//public abstract class Shape
//{
//	....
//	public abstract void draw();
//	}
//but in child classes it is mandatory to have definition
//constructor,static methods cannot be abstract because constructor are class specific and static are not dependent on objects