package com.cg.inheriatnce;

public class Circle extends Shape {
	double radius;
	double area;
	public double getRadius() {
		return radius;
	}
	public void setRadius(double radius) {
		this.radius = radius;
	}
	public double getArea() {
		return area;
	}
	public void setArea(double area) {
		this.area = area;
	}
	
	//constructor for circle class 
	//first default constructor of shape-PARENT will be called then circle-CHILD
	Circle()
	{
		super.name="Circle"; //to access member of super class
		
		System.out.println("default cons circle");
	}
	//it will implicitly call default constructor of superclass
	Circle(double radius)
	{
		super(); //to use any constructor   here function draw will be called from super
		this.radius=radius;
	}

	public void calcArea()
	{
		area=Math.PI*radius*radius;
		
		System.out.println("area of circle:"+area);
		super.draw(); //for calling member function of super class
	}
//	no need to define again but if we do then it will execute rather than shape.java
//	public void draw()
//	{
//		System.out.println("draw the circle");
//	}
}
