package com.cg.inheriatnce;

public class MainCircle {
	public static void main(String[] args) {
//		Circle Circle = new Circle();
//		Circle.setRadius(5);
//		Circle.calcArea();
//		Circle.draw();
//		
		/************************case 2*********************/
		//since circle class is inheritance shape class
		//so we can create object of shape using circle
		//to create object of child class that is CIRCLE
		Shape shape = new Circle(); 
		System.out.println("here");
		shape.draw();
//		o/p 
//		we can draw 
//		we can draw
		
		/******case 2a*******/
		//THIS IS ERROR AS setradius is funcn in circle not shape
//		shape.setRadius(5);
		//solution is type casting
		((Circle) shape).setRadius(6);
		((Circle) shape).calcArea();
		
	
//		/************************************************polymorphism rectangle.java******************/
//		Shape shape=new Rectangle(5,3);
//		shape.draw();
//		//o/p
//		default cons shape
//		in rectangle class
	
	
	
	}
	

	
}
