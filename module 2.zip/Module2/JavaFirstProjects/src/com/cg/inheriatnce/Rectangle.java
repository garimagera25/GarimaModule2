package com.cg.inheriatnce;

public class Rectangle extends Shape{
int length,breadth;
int area;
Rectangle(int l ,int b)
{
	length=l;
	breadth=b;
	}
//anyone can change signature of draw method
//public void draw(int centerx,int centery)
//so write its as @override *only applicable to func which are in superclass
@Override
public void draw()
{
System.out.println("in rectangle class");	
}


public void calcArea()
{
	area= length*breadth;
	System.out.println("areaof rectangle"+area);
	}

}
