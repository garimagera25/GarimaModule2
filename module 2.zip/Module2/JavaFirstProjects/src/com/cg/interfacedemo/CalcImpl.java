package com.cg.interfacedemo;
public class CalcImpl implements Calculator {
	@Override
	public int add(int a, int b)
	{
		return a+b;
	}
	public int substract(int a,int b)
	{
		return a-b;
	}
	
	
}
