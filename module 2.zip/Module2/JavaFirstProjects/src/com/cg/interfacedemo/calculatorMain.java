package com.cg.interfacedemo;

public class calculatorMain {
public static void main(String[] args) {
	Calculator calc = new CalcImpl();
	
	int num = calc.add(45,573);
	System.out.println("addition"+num);
	int res = calc.substract(45,7);
	System.out.println("substarction"+res);
	
//	int maxnum=calc.getMax(45,24);
//	System.out.println("max:"+maxnum);
}
}
