package com.cg.interfacedemo;

public class AdvanceCalImp {

}
