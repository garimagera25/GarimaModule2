package com.cg.Arrays;

public class VarArgsDemo {
public static void add(int ...arr)
{
	int sum=0;
	for(int num:arr)
		{
		sum=sum+num;
		}
	System.out.println(sum);

}
public static void main(String[] args) {
	add(45,38);
	add(23,45,67);
}
}
