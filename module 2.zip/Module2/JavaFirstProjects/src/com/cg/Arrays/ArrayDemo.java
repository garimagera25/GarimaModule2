package com.cg.Arrays;
public class ArrayDemo {
public static void main(String[] args)
{
//	String sarr[]={"hello","java","arrays","module2"};
//	/********for each which go only in forward direction******************/
//	for(String str :sarr)
//	{
//		System.out.println(str);
//	}
	
	
	
	PersonDArray[] persons= new PersonDArray[5];
	persons[0]=new PersonDArray("Neha",23);
	persons[1]=new PersonDArray("Ankita",25);
	persons[2]=new PersonDArray("Vishal",30);
	persons[3]=new PersonDArray("Shital",35);
	persons[4]=new PersonDArray("Shalu",35);
	for(PersonDArray persons1:persons)
	{
		System.out.println(persons1.getName()+" "+persons1.getAge());
	}
			}
}
