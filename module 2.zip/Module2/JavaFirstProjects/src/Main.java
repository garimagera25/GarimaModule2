import com.cg.banking.app.DemoClass;
public class Main {
		public static void main(String args[] )
		{
//			DemoClass acc1 = new DemoClass();
//			acc1.setAccountNo(34621);
//			acc1.setAccountHolderName("Pravin");
//			acc1.setAccountType("Saving");
//			acc1.setBalance(25000);
//			acc1.setInterestRate(6.5);
//			acc1.printAccountDetails();
//			acc1.withdraw(25000);
			DemoClass acc1= new DemoClass(34621,"garima",2500,6.5,"saving");
			
			acc1.printAccountDetails();
			DemoClass.changeInterestRate(6.2);
			// to string is used
//			System.out.println(acc1.toString());
			
			
			
		}
		  
		
		
}
