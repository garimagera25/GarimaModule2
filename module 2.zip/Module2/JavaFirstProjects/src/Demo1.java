import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;
import java.util.Vector;
public class Demo1 {
public static void main(String[] args) {
	int num=465;  
//	num is primitive
	/**********************************prior to java5***********************/
	Integer intObj = new Integer(num); //primitive to object 
	Integer obj2= Integer.valueOf(num);  //primitive to object
	
	/********************Explicitly done by compiler*************************/
	Integer obj3=num; //valid from jdk 1.5 and up //boxing
	int num2=obj3; //unboxing object to primitive
	System.out.println(num2);
	
	
	ArrayList list= new ArrayList();
	
	list.add(546);
	list.add(83);
	/*****************collections classes donot work with primitive*****************/

	/***************generics*******************/
	ArrayList<Integer> list1 = new ArrayList<>();
//	or
//	Vector<Integer> list1 = new Vector<>();
	list1.add(57);
	list1.add(53);
	list1.add(27);
	list1.add(13);
	//list1.addAll(list2);
//	list1.add(4,56);
	int size=list1.size();
	System.out.println("Total elements in list +"+size);
	System.out.println("List elements are:");
	//simple for eachloop
	for(int i =0;i<size;i++)
	{
		int ele = list1.get(i);
		System.out.println(ele);
	}
	//for each
	for(int ele:list1)
	{
		System.out.println(ele);
	}
	
	//using iterator
	Iterator<Integer> itr = list1.iterator();
	System.out.println("using iterator...");
	while(itr.hasNext())
	{
		int ele=itr.next();
		System.out.println(ele);
		if(ele%10==0)
		{
			itr.remove();
		}
		
		}
	System.out.println("after changes");
	for(int ele1:list1){
	System.out.println(ele1);
	}
	/***********capcity*******/
	Vector<Integer> list3 = new Vector<>(5);
	int capacity = list3.capacity();
	System.out.println("capacity before"+capacity);
	int sizem=list3.size();
	list3.add(57);
	list3.add(53);
	list3.add(27);
	list3.add(57);
	list3.add(53);
	list3.add(27);
	capacity= list3.capacity();
	System.out.println("after adding one elememt capacity is getting double"+capacity);
	sizem=list3.size();
	System.out.println("size of list"+sizem);
	
	
	list.clear();
	
	
	
	/*****************************************************************************************************hash sets*************************************************************/
	
	HashSet<String> set= new HashSet<>();
	/******************************to get o/p sorted use treeset in place of hash****************/
//	TreeSet<String> setTree = new TreeSet<>();
	set.add("hello");
	set.add("collections");
	/*DUPLICACY************/
	boolean res =set.add("SERVLET");  
	System.out.println("one time addded"+res);
	res =set.add("SERVLET");
	System.out.println(" same item addded"+res);
//	set.add(3,"JSP"); //INDEX IS NOT ACCESIBLE 

	int sizeq=set.size();
	System.out.println("total elements in HASHset"+sizeq);
//	for(int i =0;i<sizeq;i++)//data is not stored sequentially
	
	for(String ele:set)
		System.out.println(ele);
/*******************************************************************************************************************************************************************************************
 ******************************************************************************************************** storing object in treeset***********************************************************************************/
	TreeSet<Demo1Person> setPerson = new TreeSet<>();
	Demo1Person p1 = new Demo1Person("mona",4,"jnvv354");
	Demo1Person p2 = new Demo1Person("monu",3,"jnvv356");
	setPerson.add(p1);
	setPerson.add(p2);
	for(Demo1Person per:setPerson)
	{
		System.out.println(per);
	}
//	o/p 
//	classcastexception
//	so we need to add comparable implements to class demoperson1 in demo1person.java
}

}
