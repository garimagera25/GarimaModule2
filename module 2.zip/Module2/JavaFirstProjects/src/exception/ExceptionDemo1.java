package exception;

import java.util.Scanner;

public class ExceptionDemo1 {
public static void divide(int num1,int num2)
{
	/***************************************try with resources*********************/
//	try(Scanner sc=new Scanner(System.in);
//			now no need to close sc.close();
	try{
	if(num2==0)
	{
		throw new ArithmeticException("division by 0 Error");
	}
	
	
//	double res = num1/num2; airthmetic exception
	
	double res1 =(double)num1/num2; //**********************no exception********************************/
	
	
	System.out.println(res1);
//	o/p
//	infinity
//	

			}
	catch(ArithmeticException e)
	{
	System.out.println(e.getMessage());	
//	 DISPLAY ERROR MESSAGE Or GET VALUE FROM USER
	
	}
//	catch(SQLException| FileNotFoundException e)
//	{
//		
//	}
	finally
	{
		System.out.println("inside finally block...");
	}
}

public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter 2 numbers");
	int num1=sc.nextInt();
	int num2 = sc.nextInt();
	divide(num1,num2);
	sc.close();
	
	
}
}	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

