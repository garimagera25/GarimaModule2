package exception;

import java.util.Scanner;



public class DEMO {
	public static void validateAge(int age)
	{
		try{
		if(age<18)
			throw new AgeException(age);
		System.out.println("You are valid for registration");
	}
		catch(AgeException e)
		{
			e.printError();
			}
		}
	///public static void validateAge (int age)throws AgeException
	
	
	// public static void main(String[] args) throws AgeException //now it will go to jvm
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter age:");
	int age=sc.nextInt();
	validateAge(age);
}
}
