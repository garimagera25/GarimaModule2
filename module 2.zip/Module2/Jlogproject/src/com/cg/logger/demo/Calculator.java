package com.cg.logger.demo;

import org.apache.log4j.Logger;

public class Calculator {

private static Logger logger= Logger.getLogger("Calculator");
public int add(int num1,int num2)
{
	logger.info("IN ADD METHOD");
	return num1+num2;
	}
public double substract(int num1,int num2)
{
	logger.info("in substarct");
	return num1-num2;
}
public double divide(int num1,int num2)
{
	logger.info("in divide");
	try{
		if(num2==0)
			throw new ArithmeticException();
		return (double)num1/num2;
	}
	catch(ArithmeticException e)
	{
		logger.error("num 2 is 0");
	}
	return 0;
}

}
