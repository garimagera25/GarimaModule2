package com.cg.logger.demo;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.logger.demo.Calculator;
public class LoggerDemo {
public static void main(String[] args) {
	PropertyConfigurator.configure("resources/log4j.properties");
	Logger logger=Logger.getLogger(LoggerDemo.class);
	Calculator cal=new Calculator();
	System.out.println("please see the basic.log file in resources");
	int addres= cal.add(3,6);
	cal.divide(10,2);
	cal.substract(10, 5);
	
	
	logger.info("addition result is"+addres);
	
	logger.debug("this is debug level message");
	logger.warn("warn message");
	logger.error("error msg");
	logger.fatal("fatak msg");
	
}
}
