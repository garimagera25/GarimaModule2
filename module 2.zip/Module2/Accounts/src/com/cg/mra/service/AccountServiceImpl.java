package com.cg.mra.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.AccountException;
import com.cg.mra.util.DatabaseConnection;

public class AccountServiceImpl implements AccountService {
	AccountDao dao;
	
	public AccountServiceImpl(){
		dao= new AccountDaoImpl(); 
}
	
	@Override
	public Account getBalanceDetails(String accId) throws AccountException {
		
		Account acc=dao.getBalanceDetails(accId);
		// TODO Auto-generated method stub
		return acc;
		// TODO Auto-generated method stub
		
	}

	@Override
	public int rechargeAmount(String accid1, double ramt) throws AccountException {
		return dao.rechargeAmount(accid1,ramt);
		
	}

	
	
	
	

}
