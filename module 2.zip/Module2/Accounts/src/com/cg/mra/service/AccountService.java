package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.AccountException;

public interface AccountService {

	Account getBalanceDetails(String accId) throws AccountException;

	int rechargeAmount(String accid1, double ramt)throws AccountException ;



}
