package com.cg.mra.service;

public interface ValidationService {

}
