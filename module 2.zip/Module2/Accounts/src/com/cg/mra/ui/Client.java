package com.cg.mra.ui;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import java.util.Scanner;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.AccountException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;
import com.cg.mra.service.ValidationService;
import com.cg.mra.service.ValidationServiceImpl;

public class Client {
public static void main(String[] args) {
	PropertyConfigurator.configure("resources/log4j.properties");
	Logger logger=Logger.getLogger(Client.class);
	Account acc = new Account();//making obj for dto
	AccountService service= new AccountServiceImpl();//making obj for service
	ValidationService validation=new ValidationServiceImpl();//making object for validation
	

	Scanner sc= new Scanner(System.in);
	int option=0;
	do{
		System.out.println("\n\n1. Enter account id account enquiry balance ...");
		System.out.println("2. Enter accountid and Recharge amount to recharge...");
		System.out.println("3.Exit");
		
		
		System.out.println("Enter Choice .");
		 option= sc.nextInt();
		switch(option){
		
		case 1:
//			do{
				System.out.println("Enter Account Id: ");
				String accId=sc.next();
				try {
					acc =service.getBalanceDetails(accId);
					
					System.out.println("For eneterd id "+acc.getAccountID()+"present balance is"+acc.getAccountBalance());
				logger.info("Your account id"+acc.getAccountID()+"present balance is"+acc.getAccountBalance());
				} catch (AccountException e) {
					System.out.println(e.getMessage());
					logger.error(e.getMessage());
				}
				break;
//				}while(true);
			
		case 2:
			System.out.println("Enter recharge amount ");
			logger.info("Enter recharge amount");
			double ramt= sc.nextDouble();
			System.out.println("enter account id ");
			String accid1= sc.next();
			acc.setAccountID(accid1);
//			acc.setAccountBalance(ramt);
			
		try {
			int rev= service.rechargeAmount(accid1,ramt);
			if(rev==1)
			{
				System.out.println("recharge updated successfully ");
				logger.info("recharge updated successfully ");
			}
				else
				{
					System.out.println("failed");
					logger.info("failed");
				}
		} catch (AccountException e) {
			System.out.println(e.getMessage());
			logger.info(e.getMessage());
		}				
		break;
			
		default:
			System.out.println("Wrong choice");
			logger.info("wrong choice");
		}//end of switch
	}//end of do
	while(option!=3);
	sc.close();
	}//end of main
}
