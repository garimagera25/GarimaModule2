package com.cg.mra.dao;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.AccountException;



public interface AccountDao {
		Account getBalanceDetails(String accId) throws AccountException;

		int rechargeAmount(String accid1, double ramt) throws AccountException ;
}
