package com.cg.mra.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.AccountException;
import com.cg.mra.util.DatabaseConnection;

public class AccountDaoImpl implements AccountDao {

	Connection connection;
	public AccountDaoImpl() {
		connection= DatabaseConnection.getConnection();
	}
	protected void finalize(){
		try {
			connection.close();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}
	@Override
	public Account getBalanceDetails(String accId) throws AccountException {
		Account acc= new Account();
		String selQry= "select ACCOUNT_ID,ACC_BALANCE from account  where ACCOUNT_ID=?";
		try {
			PreparedStatement ps= connection.prepareStatement(selQry);
			ps.setString(1, accId);
			ResultSet rs = ps.executeQuery();
			if(rs.next()){
				acc.setAccountID(rs.getString(1));
				acc.setAccountBalance(rs.getDouble(2));
					
					
			}
			else 
			throw new AccountException("Account id does not exist");
			
		} catch (SQLException e) {
			throw new AccountException(e.getMessage());
		}
		return acc;	
	}
	@Override
	public int rechargeAmount(String accid1, double ramt) throws AccountException {
		// TODO Auto-generated method stub
		String a=accid1;
		double r =ramt;
		String updateQry="update account set ACC_BALANCE=?+ACC_BALANCE where ACCOUNT_ID=?";
		try{
			PreparedStatement ps= connection.prepareStatement(updateQry);
			ps.setDouble(1,r);
			ps.setString(2,a);
			int rs=ps.executeUpdate();
			return rs;
		} catch (SQLException e) {
			throw new AccountException(e.getMessage());
		}
		
	}
	
}
