package com.cg.mra.beans;

public class Account {
private String accountID;
private String accountType;
private String customerName;

public Account()
{
//	this.accountID=accountID;
//	this.accountType=accountType;
//	this.customerName=customerName;
	
	}
public String getAccountID() {
	return accountID;
}
public void setAccountID(String accountID) {
	this.accountID = accountID;
}
public String getAccountType() {
	return accountType;
}
public void setAccountType(String accountType) {
	this.accountType = accountType;
}
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public double getAccountBalance() {
	return accountBalance;
}
public void setAccountBalance(double accountBalance) {
	this.accountBalance = accountBalance;
}
private double accountBalance;
}
