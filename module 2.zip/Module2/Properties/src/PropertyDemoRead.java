import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;


public class PropertyDemoRead {
public static void main(String[] args) {
	try{
	InputStream file = new FileInputStream("./PropertyDemo1/PropertiesDemo.properties");
	Properties prop= new Properties();
	prop.load(file);
	
	String user=prop.getProperty("username");
	String pwd=prop.getProperty("password");
	String empid=prop.getProperty("empid");
	String db=prop.getProperty("db");
	
	System.out.println("user:"+user);
	System.out.println("pwd:"+pwd);
	System.out.println("empid:"+empid);
	System.out.println("db:"+db);
	}
	catch(FileNotFoundException e){
		System.out.println("File not found");
	}
	catch(IOException e)
	{
		e.printStackTrace();
	}
}
}
