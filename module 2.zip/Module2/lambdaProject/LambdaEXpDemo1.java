package fileIo;

import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class LambdaEXpDemo1 {


public static void main(String[] args) {
	
	Person1 p1= new Person1();
	Consumer<String> con=p1::setName;
	con.accept("smith");
	
//	Consumer<String> con=System.out::println;
	Consumer<Integer> con1=p1::setAge;
	
	con1.accept(23);
	
Supplier<String> sup1 =()->p1.getName();
Supplier<	Integer> sup2 =()->p1.getAge();

System.out.println(sup1.get()+" "+sup2.get());
			
}
}
