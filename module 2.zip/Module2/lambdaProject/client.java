package fileIo;
public class client {
 public static void main(String[] args) {
	 System.out.println("uncomment whole for lamda and make interface");
	 //	Calculator calc=(x,y) -> {return x+y;};/**************lamda expression   only in java8 *********************/
//	int add = cal.calculate(4,8);
//	System.out.println(add);
}
}
