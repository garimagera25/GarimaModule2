package fileIo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileReadDemo {
	public static void main(String[] args) {
		FileInputStream fis;
		int ch =0;
		try{
			fis=new FileInputStream("Demo.txt");
			while(ch!=-1) //-1 is end of file
			{
				ch=fis.read();
				System.out.println((char)ch);
			}
			fis.close();
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
			}
		catch(IOException e)
		{
			e.printStackTrace();
			}
		}
		}


