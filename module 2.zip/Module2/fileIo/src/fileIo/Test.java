package fileIo;
@FunctionalInterface
public interface Test {
public boolean test(int num);
}

//create interface + method
