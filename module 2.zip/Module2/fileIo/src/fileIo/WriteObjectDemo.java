package fileIo;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class WriteObjectDemo {
public static void main(String[] args) throws IOException {
	Person p1= new Person("smth","male",43);
	Person p2= new Person("smtwh","male",42);
	Person p3= new Person("smuth","male",41);
	Person p4= new Person("smoth","male",40);
	try{
	FileOutputStream fos = new FileOutputStream("PersonDetails.dat");
	//only in object there is writeObject method 
	ObjectOutputStream oos = new ObjectOutputStream(fos);
	oos.writeObject(p1);
	oos.writeObject(p2);
	oos.writeObject(p3);
	System.out.println("person objects written into file");
	oos.close();
	}
	catch(FileNotFoundException e)
	{
		
	}
}
}
