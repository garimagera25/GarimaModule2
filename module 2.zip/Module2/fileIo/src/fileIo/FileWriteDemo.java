package fileIo;

import java.io.FileOutputStream;
import java.io.IOException;

public class FileWriteDemo {
public static void main(String[] args) {
	try{
		FileOutputStream fos=new FileOutputStream("Demo.txt");
		System.out.println("Enter Data to write into file,#to terminate");
		char ch =0;
		while(ch!='#')
		{
			ch=(char)System.in.read();
			fos.write(ch);
		}
		fos.close();
		System.out.println("data written to file");
	}
	catch(IOException e)
	{
		e.printStackTrace();
	}
}
}
