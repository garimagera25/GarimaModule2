package fileIo;
import java.io.IOException;
public class ConsoleReadDemo {
public static void main(String[] args) {
	StringBuffer sb = new StringBuffer();
	System.out.println("Enter a line of text:");
	char ch=0;
	
	while(ch!='\n')
	{
		try{
			ch = (char)System.in.read();
			sb.append(ch);
		}
		catch(IOException e)
		{
			System.out.println(e.getMessage());
		}
	}
	System.out.println(sb);
}
	

}
