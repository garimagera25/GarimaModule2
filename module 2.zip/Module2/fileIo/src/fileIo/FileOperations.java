package fileIo;

import java.io.File;
import java.io.IOException;
import java.sql.Date;

public class FileOperations {
public static void main(String[] args) throws IOException {
	File file = new File("Demo.txt");
//	/*For creating file*****/
//	boolean res = file.createNewFile();
//	if(res)
//	{
//		System.out.println("file created");
//	}
	/*till here******/
	System.out.println("Is it a file ?"+file.isFile());
	System.out.println("Is it A directory?"+file.isDirectory());
	
	System.out.println("Path:"+file.getAbsolutePath());
	Date date = new Date(file.lastModified());
	System.out.println("Last Modified Date"+date);
	boolean res1 = file.setReadOnly();
	
	if(res1)
		System.out.println("now the file is read only ...");
//	file.setReadOnly();
}
}
