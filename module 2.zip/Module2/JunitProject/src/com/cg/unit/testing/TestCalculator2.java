package com.cg.unit.testing;

import jdk.nashorn.internal.ir.annotations.Ignore;
import junit.framework.Assert;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestCalculator2 {
	
	static	Calculator calc;

	@BeforeClass
	public static void createObject()
	{
		calc= new Calculator();
		System.out.println("here");
	}
	@AfterClass
	public static void cleanup()
	{
		System.out.println("code over");
	}
	@Test
	public void testAdd()
	{
//		Calculator calc= new Calculator();
		int res= calc.add(3, 8);
		
		Assert.assertEquals(11, res);
	}
	@Ignore
	@Test
	public void testSubstract()
	{
//		Calculator calc= new Calculator();
		int sub= calc.substract(13, 8);
		Assert.assertEquals(5, sub);
		System.out.println("here");
	}
	@Test
	public void testGetMax()
	{
//		Calculator calc = new Calculator();
		int max=calc.maxNum(12,15);
		Assert.assertEquals(15, max);
	}
}
