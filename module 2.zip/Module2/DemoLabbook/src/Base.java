class Base{
Base(int var)
{
    System.out.println("Base");
}
}
class Test2 extends Base{
public static void main(String argv[]){
        Test2 obj = new Test2();
}
}