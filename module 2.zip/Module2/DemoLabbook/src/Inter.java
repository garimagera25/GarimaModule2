
public interface Inter {
static 	int i=0;

}
