package demos;

import java.util.stream.Stream;

public class StreamDemo {

 public static void main(String[] args) {
 Stream<String>str = Stream.of("Hello","Hi","Welcome","hello","love");
  str.filter((ref)->ref.contains("l")).distinct().forEach((strr)->System.out.println(strr));
 }}