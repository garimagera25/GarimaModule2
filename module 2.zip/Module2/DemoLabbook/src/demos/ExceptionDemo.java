package demos;
public class ExceptionDemo {

public static void main(String[] args) {
  int i = 0;
  try
        {
            i = Integer.parseInt("abc");   
        }
      catch(Exception ex)
        {
            System.out.println("Exception");
        }
     finally
   {
   System.out.println("i = "+i);
  }}}