import java.util.stream.Stream;


public class BasicStreamDemo {
public static void main(String[] args) {
	Stream<Integer> stream = Stream.of(34,74,63,843,73,435,62,254,34);
	//consumer functional interface method
	                                                     /**************TO DISPLAY NO**************/
//	stream.forEach((num) -> System.out.println(num));
	                                  /******FOR PRINTING EVEN OR ODD*******/
//	stream.map((num)->{if(num%2==0) return "Even";
//	else
//	return "ODD";}
//	).forEach((str)->System.out.println(str));
	
	
	                                    /**************filter on even example****************/
	/*we are passing something to filter which will act as parameter in test cases*/
//	stream.filter((num)->num%2==0).forEach(System.out::println);
//	OR
//	stream.filter((num)->num%2==0).forEach((num)->System.out.println(num));
                                    /**********distinct example**************/
//	
//	Stream<Integer> uniqueEles=stream.distinct();
//	uniqueEles.forEach(System.out::println);
                                        /*************limit and skip***********/
	//stream.limit(4).forEach(System.out::println);
	//stream.skip(5).forEach(System.out::println);
	                          /*****************to count even nos in list*****************/
//	
//	Long evenNumbers=stream.map((num)->{if(num%2==0) return "Even"; //with count long is used
//	else
//		return "odd";}).filter((str)->str.equalsIgnoreCase("Even")).count();
//		System.out.println(evenNumbers);
	/*************to find sum of all nos      REDUCE************************/
	
//	int result= stream.reduce((num1,num2)->num1+num2).get();
//	System.out.println(result);
	
	/*************to find MAX of all nos      REDUCE************************/
	int result1= stream.reduce((num1,num2)->{if(num1>num2) return num1;
	else return num2;}
			).get();

	System.out.println(result1);
	
}
}

