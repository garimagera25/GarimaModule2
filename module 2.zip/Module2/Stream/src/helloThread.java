//all the thread ae parallely running 
public class helloThread extends Thread {
	public helloThread(String name)
	{
		super(name);
	}
@Override
public void run()
{
	System.out.println("in run method :"+this.getName());
	for(int i =1 ;i<=5;i++)
	{
	try{
		Thread.sleep(2000);
	System.out.println(this.getName()+":"+i);
	}
	catch(InterruptedException e)
	{
		e.printStackTrace();
	}
	}
System.out.println(this.getName()+"will die now");
}
public static void main(String[] args) {
	helloThread th1 = new helloThread("Tom");
	helloThread th2 = new helloThread("Jerry");
	th2.setPriority(10);
	th1.start();
	th2.start();
	for(int i =1 ;i<=5;i++)
	{
	try{th2.join();
		Thread.sleep(2000);
	System.out.println("in  main thread"+":"+i);
	}
	catch(InterruptedException e)
	{
		e.printStackTrace();
	}
	}
	System.out.println("is tom alive:"+th1.isAlive());
	System.out.println("is jerry alive:"+th2.isAlive());
}
}
