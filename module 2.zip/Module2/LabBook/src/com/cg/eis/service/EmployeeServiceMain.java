package com.cg.eis.service;
//using interface
public class EmployeeServiceMain {
public static void main(String[] args) {
	EmployeeService sc=new ServiceClass(); ////////**interface obj= new class*******/
	sc.details();
	
}
}
