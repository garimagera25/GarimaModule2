package com.cg.eis.service;
//declaration of interface
public interface EmployeeService {
void details();
void InsuranceScheme();
}

//implementation of interface done by class
class ServiceClass implements EmployeeService
{
	public void details()
	{
		System.out.println("implementation and printing details");
	}

	@Override
	public void InsuranceScheme() {
		// TODO Auto-generated method stub
		
	}
	}
///Using interface: in employeeservicemain file
//using interface
