package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;

public class EmployeeInterfaceMain {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter First Name");
	String name = sc.next();
	System.out.println("Enter ID");
	int id = sc.nextInt();
	System.out.println("Enter Salary");
	Double salary = sc.nextDouble();
	System.out.println("Enter Designation");
	String designation = sc.next();
	
	
	
	
	Employee emp= new Employee(id,name,salary,designation);
	emp.InsuranceScheme();
	emp.details();
}
}
