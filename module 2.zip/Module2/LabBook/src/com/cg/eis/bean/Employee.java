package com.cg.eis.bean;

import com.cg.eis.service.EmployeeService;

public class Employee implements EmployeeService  {
	int id;
	private String name;
	private Double salary;
	private String designation;
	private String insuranceScheme;
	public Employee(int id,String name,Double salary,String designation)
	{
		this.id=id;
		this.name=name;
		this.salary=salary;
		this.designation=designation;
//		this.insuranceScheme=insuranceScheme;
	}
	
	
	
 public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getInsuranceScheme() {
		return insuranceScheme;
	}
	public void setInsuranceScheme(String insuranceScheme) {
		this.insuranceScheme = insuranceScheme;
	}
	public void InsuranceScheme()
	{
		
		if(salary >5000 && salary< 20000 && designation=="System Associate"  )
		{
			insuranceScheme="schemeC";
			
		}
		else if(salary >20000 && salary< 40000 && designation=="Programmer" )
		{
			insuranceScheme="schemeB";
		}
		else if (salary>=40000)
		{
			insuranceScheme="schemeA";
		}
		else
			
		System.out.println("scheme");
		
		System.out.println(insuranceScheme);
	}


	@Override
	public void details() {
		System.out.println("Details of user");
		System.out.println("FirstName:"+name);
		System.out.println("ID:"+id);
		System.out.println("Salary:"+salary);
		System.out.println("Designation:"+designation);
		System.out.println("insuranceScheme"+insuranceScheme);
		
	}

	

}
