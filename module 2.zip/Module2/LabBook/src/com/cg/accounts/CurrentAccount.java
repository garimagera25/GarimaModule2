package com.cg.accounts;

public class  CurrentAccount extends Accounts {
	private final double overDraftLimit=3000;
	@Override
	public void withdraw(double amount)
	{	
		System.out.println(amount);
		System.out.println(overDraftLimit);
		if(amount<overDraftLimit )
		{
			System.out.println("overDraftLimit is app");
			
			super.withdraw(amount);
			 
		}
		else
			System.out.println("overDraftLimit is reached");
		}
}
