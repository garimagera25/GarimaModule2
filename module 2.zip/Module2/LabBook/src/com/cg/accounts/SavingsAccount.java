package com.cg.accounts;

public class SavingsAccount extends Accounts{
private final double minimumBalance=100;
@Override
public void withdraw(double amount)
{	
	System.out.println(amount);
	System.out.println(minimumBalance);
	if(amount>minimumBalance )
	{
		System.out.println("minimumbalance is app");
		
		super.withdraw(amount);
		 
	}
	else
		System.out.println("min balance is less");
	}
}
