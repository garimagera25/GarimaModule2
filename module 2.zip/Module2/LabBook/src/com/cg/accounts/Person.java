package com.cg.accounts;

import com.cg.theperson.FullNameException;

public class Person {
	String name;
	int age;

	public Person(String name,	int age)
	{
		this.name=name;
		this.age=age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public void AgeException()
	{
		System.out.println("exception");
		try{
			if(age<15)
				throw new AgeException(age);
			System.out.println("you are valid to register");
		}
		catch(AgeException e)
		{
			e.printError();
			}
		}
	public String toString()
	{
		return name+" of age "+age;
	}

	
}
