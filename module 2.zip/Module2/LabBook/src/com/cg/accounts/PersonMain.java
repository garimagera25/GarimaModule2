package com.cg.accounts;

import java.util.Scanner;

public class PersonMain {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter amount");
		double amount = sc.nextDouble();
		sc.close();
Person p1=new Person("Smith",5);
Person p2=new Person("Kathy",34);

//Accounts acc1= new Accounts("bshvdahfhvfdha",2000);
//p1.setAccName("smith");
Accounts acc1=new Accounts();
acc1.setBalance(2000);
acc1.setAccHolder(p1);

acc1.deposit(amount);

Accounts acc2= new Accounts();
acc2.setBalance(3000);
acc2.setAccHolder(p2);


Accounts SavingsAccount=new SavingsAccount();

SavingsAccount.setAccHolder(p1);
SavingsAccount.setBalance(3000);

//SavingsAccount.withdraw(amount);
//SavingsAccount.printAccountsDeatils();
//acc2.withdraw(amount);



Accounts CurrentAccount=new CurrentAccount();

CurrentAccount.setAccHolder(p1);
CurrentAccount.setBalance(3000);

//CurrentAccount.withdraw(amount);
//CurrentAccount.printAccountsDeatils();

acc2.printAccountsDeatils();
acc1.printAccountsDeatils();
}

	
	
}