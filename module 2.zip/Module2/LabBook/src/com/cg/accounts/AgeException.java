package com.cg.accounts;

public class AgeException extends Exception {
	private int age;
	public AgeException(int age)
	{
//		this.firstName=firstName;
		this.age=age;
		
		}
	public void printError()
	{
		System.out.println("Age is invalid");
		}
}
