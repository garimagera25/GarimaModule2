package com.cg.accounts;

public class Accounts {
long  accName;
double balance;
Person accHolder;
private int accNo;

public int getAccNo() {
	return accNo;
}

public void setAccNo(int accNo) {
	this.accNo = accNo;
}

public static int getCount() {
	return count;
}

public static void setCount(int count) {
	Accounts.count = count;
}
private static int count=1000;

public Accounts( )
{
	count++;
	accNo=count;

	}

public long getAccName() {
	return accName;
}
//public Accounts(long name,int balance)
//{
//	this.accName=name;
//	this.balance=balance;
//	}
public void setAccName(long accName) {
	this.accName = accName;
}
public double getBalance() {
	return balance;
}
public void setBalance(double balance) {
	this.balance = balance;
}
public Person getAccHolder() {
	return accHolder;
}
public void setAccHolder(Person accHolder) {
	this.accHolder = accHolder;
}
public void deposit(double amount)
{
balance=balance+amount;
System.out.println("after credit"+balance);



	}
public void withdraw(double amount)
{
	System.out.println("amount passed"+amount);
//	 setBalance(getBalance() - amount);
	System.out.println("balance is"+balance);
	balance=balance-amount;
	System.out.println("after debit"+balance);

	
	}
public String toString()
{
	return accNo+ ":" +balance+":"+accHolder ;
}
public void printAccountsDeatils() 
{
	
	System.out.println("accNo:"+accNo);
//	System.out.println("Account Holder Name:"+accName);
	System.out.println("Balance:"+balance);
	System.out.println("Account Holder Name:"+accHolder);
	}

}



