package com.cg.arrays;

import java.util.*;
public class Details {
public static void main(String[] args) {
	ArrayList<Product> arraylist = new ArrayList<Product>();
	Product p1= new Product("Neha");
	Product p2= new Product("Abc");
	Product p3= new Product("da");
	Product p4= new Product("keha");
	arraylist.add(p1);
	arraylist.add(p2);
	arraylist.add(p3);
	arraylist.add(p4);
	
	
	/*********product type is object*************and u are enetring string**********/
//	arraylist.add("defg");
//	arraylist.add("rnjk");
//	arraylist.add("njch");
	
	System.out.println("products name sorted");
	Collections.sort(arraylist,Product.proNameComparator);
	for(Product str: arraylist){
		System.out.println(str);
	}
}

}
