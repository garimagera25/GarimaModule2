package com.cg.arrays;

import java.util.Comparator;

public class Product {
private String ProductName;


public Product(String ProductName)
{
	this.ProductName=ProductName;
}
public String getProductName() {
	return ProductName;
}
public void setProductName(String productName) {
	ProductName = productName;
}
public static Comparator<Product> proNameComparator = new Comparator<Product>()
{
public int compare(Product p1,Product p2){
String ProductName1= p1.getProductName().toUpperCase();
String ProductNam2= p2.getProductName().toUpperCase();
return ProductName1.compareTo(ProductNam2);
}
};
public String toString()
{
	return ProductName ;
}
}