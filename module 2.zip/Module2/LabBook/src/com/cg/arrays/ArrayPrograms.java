package com.cg.arrays;

import java.util.Arrays;

public class ArrayPrograms {
	public static void main(String[] args)
	{
		String products[]={"cookies","shampoo","mobile","pen",};
		Arrays.sort(products);
		System.out.println("after sorting result is:");
		for(String product:products)
			System.out.println(product);
	}
}
