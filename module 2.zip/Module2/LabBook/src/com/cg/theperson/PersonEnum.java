package com.cg.theperson;
public enum PersonEnum {
	M("MALE"),
	F("FEMALE");
	String gender;
	PersonEnum(String gen)
	{
		this.gender=gen;
	}
}