package com.cg.theperson;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
//import exception.FullNameException;
public class Person {
	
private String firstName;
private String lastName;
private String gender;
private int phoneNo;
private String UserDOB;
private String fullName;
private int dob;

public Person()
{
	//default constructor
}
public Person(String fname,String lname, String gender )
{
	 firstName=fname;
	 lastName=lname;
	this.gender = gender;
			
	}
public Person(String fname,String lname, String gender,int phoneNo)
{
	this(fname,lname,gender);
	this.phoneNo=phoneNo;
	}
public Person(String fname,String lname, String gender,int phoneNo,String fullName)
{
	this(fname,lname,gender,phoneNo);
	this.fullName=fullName;
	}
//public int calculateAge(String UserDOB)
//{
//	System.out.println("hello");
//	
//	
//DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("dd/MM/yyyy");
//LocalDate birthdate = LocalDate.parse(UserDOB,formatter1);
//System.out.println(birthdate);
//////System.out.println(date3);
//LocalDate dateNow=LocalDate.now();
//Period period = Period.between(birthdate, dateNow);
//
//System.out.println("age: " + period.getYears()+"years");  // prints "age: 26"
//
//int dob =period.getYears();
//return dob;
//	}

public String fullName(String firstName,String lastName )
{
	
	System.out.println("hello");
	System.out.println(firstName);
	String fullName=firstName.concat(lastName);
//	System.out.println(fullName);
	validateFullName(fullName);
	return fullName;
	}
/****************************6.1 exception handling*********************************/
public void validateFullName(String fullName)
{
	System.out.println("exception");
	try{
		if(fullName==null)
			throw new FullNameException(fullName);
		System.out.println("Name fields cannot be blank");
	}
	catch(FullNameException e)
	{
		e.printError();
		}
	}



public void printAccountDetails()
{
	String nameFull = fullName(firstName,lastName);
	
//	calculateAge(UserDOB);
	System.out.println("firstName:"+firstName);
	System.out.println("lastName:"+lastName);
	System.out.println("gender:"+gender);
	System.out.println("phoneno."+phoneNo);
	
	System.out.println("Full Name"+nameFull);
//	System.out.println("Age"+dob+"years");
//	System.out.println("Full Name"+fullName);
	
}


public String getFirstName() {
	return firstName;
}

public void setFirstName(String firstName) {
	this.firstName = firstName;
}

public String getLastName() {
	return lastName;
}

public void setLastName(String lastName) {
	this.lastName = lastName;
}

public String getGender() {
	return gender;
}

public void setGender(String gender) {
	this.gender = gender;
}


}
