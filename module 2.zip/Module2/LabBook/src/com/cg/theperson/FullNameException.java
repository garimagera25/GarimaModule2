package com.cg.theperson;

public class FullNameException extends Exception{
//	private String firstName;
//	private String lastName;
	private String fullName;
	public FullNameException(String fullName)
	{
//		this.firstName=firstName;
		this.fullName=fullName;
		
		}
	public void printError()
	{
		System.out.println("Name fields canot be empty");
		}
}
