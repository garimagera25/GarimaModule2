package com.cg.theperson;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
public class PersonMain {
public static void main(String args[])
{
	
	Person p1= new Person();
//	p1.setFirstName("Pravin");
//	p1.setLastName("Pravin");
//	p1.setGender('M');
	
Scanner sc = new Scanner(System.in);
System.out.println("Enter your PhoneNo.");
int phoneNo = sc.nextInt();
System.out.println("Enter your FirstName");
String fname = "";
//String fname = sc.next();
System.out.println("Enter your LastName");
//String lname = sc.next();
String lname = "";
System.out.println("Enter your Gender");
String gender = sc.next();

System.out.println("Enter Date (dd/mm/yyyy):");
String UserDOB = sc.next();

Person p2= new Person(fname,lname,gender,phoneNo);
switch(gender)
{
case "M": 
	p1.setGender(gender);
//	p2.printAccountDetails();
break;
case "m": 
	p1.setGender(gender);
//	p2.printAccountDetails();
break;
case "f": 
	p1.setGender(gender);
//	p2.printAccountDetails();
break;
case "F":
	p1.setGender(gender);
//	p2.printAccountDetails();
break;
default: 
	System.out.println("invalid input");
	break;
}


p2.printAccountDetails();


//p2.fullName();
/*************age display******************/
DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("dd/MM/yyyy");
LocalDate birthdate = LocalDate.parse(UserDOB,formatter1);
//System.out.println(birthdate);
//System.out.println(date3);
LocalDate dateNow=LocalDate.now();
Period period = Period.between(birthdate, dateNow);

System.out.println("age: " + period.getYears()+"years");  // prints "age: 26"
/************till here***********/
sc.close();



	
	
	
	
	}

}
