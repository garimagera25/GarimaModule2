import java.util.Scanner;
public class PositiveString {
	public static void main(String[] args) {
		PositiveString p1= new PositiveString();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your String");
		String EnteredString = sc.next();
//		System.out.println(EnteredString.length());
//		p1.ToCheckPositive();
		int isNotPositiveString=0;
		for(int i=0;i<EnteredString.length()-1;i++)
		{
			char character1 = EnteredString.charAt(i);
			// This gives the character 'a'
			int ascii1 = (int) character1;
			char character2 = EnteredString.charAt(i+1);
			// This gives the character 'a'
			int ascii2 = (int) character2;
			
			if(ascii2<ascii1)
			{
				isNotPositiveString=1;
			}
		}
		if(isNotPositiveString==1)
		{
			System.out.println("String is negative");
		}
		else
			System.out.println("String is positive");
//		System.out.println("you are here");
	}
//	public void ToCheckPositive()
//	{
//		
//	}
}
