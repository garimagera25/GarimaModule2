import java.util.Scanner;
public class StringOperationMain {
public static void main(String[] args) {
	StringOperations s1= new StringOperations();
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter your String");
	String UserString = sc.next();
	System.out.println("Enter your UserChoice.");
	int UserChoice = sc.nextInt();
	
	switch(UserChoice)
	{
	case 1:
//		UserString=UserString+UserString;
//		System.out.println(UserString);
		String UserStringConcat=UserString.concat(UserString);
		System.out.println(UserStringConcat);

		break;	
	case 2:
		s1.ReplaceOdd(UserString);
		break;
	case 3:
		s1.RemoveDuplicate(UserString);
		break;
	case 4:
		s1.UpperCase(UserString);
		break;
	default:
		System.out.println("invalid input");
	}
	
}
}
