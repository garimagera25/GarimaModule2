import java.time.Duration;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import java.time.LocalTime;
import java.time.ZoneId;
public class DateOperations {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter Date (dd/mm/yyyy):");
	String UserDate = sc.next();
	DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	LocalDate date3 = LocalDate.parse(UserDate,formatter1);
//	System.out.println(date3);
	
	LocalDate date=LocalDate.now();
	System.out.println("Today is :"+date);
	
	Period period = Period.between(date3, date);
	System.out.println("period"+period);
	
	
	/**********enter two diff dates***********/
	System.out.println("Enter Date (dd/mm/yyyy):");
	String UserDate1 = sc.next();
	DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	LocalDate uDate1 = LocalDate.parse(UserDate1,formatter2);
	
	System.out.println("Enter Date (dd/mm/yyyy):");
	String UserDate2 = sc.next();
	DateTimeFormatter formatter3 = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	LocalDate uDate2 = LocalDate.parse(UserDate2,formatter3);
	
	Period period1 = Period.between(uDate1, uDate2);
	System.out.println("period"+period1);
	
	
	/*****************************purchase amount***************************/
//	System.out.println("Enter Date (dd/mm/yyyy):");
//	String purchaseDate = sc.next();
//	DateTimeFormatter formatter4 = DateTimeFormatter.ofPattern("dd/MM/yyyy");
//	LocalDate pDATE = LocalDate.parse(purchaseDate,formatter4);
	
	
	
	/******************zone id*********************/
	System.out.println("enter zone");
	String ZoneEntered= sc.next();
//	 ZoneId zone1 = ZoneId.of("Europe/Berlin");
//	 LocalTime now1 = LocalTime.now(zone1);
//	  System.out.println(now1);
	  
	  ZoneId zone1 = ZoneId.of(ZoneEntered);
//	    ZoneId zone2 = ZoneId.of("Brazil/East");

	    LocalTime now1 = LocalTime.now(zone1);
//	    LocalTime now2 = LocalTime.now(zone2);

	    System.out.println(now1);
//	    System.out.println(now2);

//	    System.out.println(now1.isBefore(now2));  // false
	  
	  
}
}
