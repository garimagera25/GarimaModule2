package com.cg.mobapp.dao;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.mobapp.dto.Mobile;
import com.cg.mobapp.exception.MobileException;
import com.cg.mobapp.util.DatabaseConnection;
import com.sun.xml.internal.ws.api.server.Module;

public class MobileDaoImpl implements MobileDao {
Connection connection;
	public MobileDaoImpl()
{
	connection=DatabaseConnection.getconnection();
	}
protected void finalize()
{
	try{
		connection.close();
	}
	catch(SQLException e)
	{
		e.printStackTrace();
	}
	}

	@Override
	public int addMobile(Mobile mobile) throws MobileException {
	       
		//insert code here
		//create sequence mob_id_Seq start with1004;
		
		String insQry="INSERT INTO mobiles(mobileid,name,price,quantity) "
				+ "values (mob_id_seq.nextval,?,?,?)";
		
		try{
			PreparedStatement ps = connection.prepareStatement(insQry);
			ps.setString(1,mobile.getMobileName());//mobile object contains all values
			ps.setDouble(2,mobile.getPrice());
			ps.setInt(3, mobile.getQuantity());
			 
			int r = ps.executeUpdate();
			 int mobileid=0;
			if(r==1)
			{
				Statement st=connection.createStatement();
				ResultSet rs= st.executeQuery("select mob_id_seq.currval from dual");
				if(rs.next())
					mobileid=rs.getInt(1);
			}
			return mobileid;
			
		}
		catch(SQLException e)
		{
			throw new MobileException(e.getMessage());
		}
		
		
		// TODO Auto-generated method stub
///		return 0;
	}
	
	
	
	
	
	
	
	
	
	
	@Override
	public Mobile getMobileDetails(int id) throws MobileException {
		Mobile mobile = new Mobile();
		String selQry="select mobileid,name,price,quantity from mobiles where mobileid=?";
		try{
			PreparedStatement ps=connection.prepareStatement(selQry);
			ps.setInt(1,id);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				mobile.setMobileID(rs.getInt(1));
				mobile.setMobileName(rs.getString(2));
				mobile.setPrice(rs.getDouble(3));
				mobile.setQuantity(rs.getInt(4));
			}
			else 
				throw new MobileException("Mobile id does not exist");
		}
		catch(SQLException e){
			throw new MobileException(e.getMessage());
		}
		// TODO Auto-generated method stub
		return mobile;
	}
	@Override
	public int updateMobile(Mobile mob) throws MobileException {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public int deleteMobile(int id) throws MobileException {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public List<Mobile> getMobile() throws MobileException {
		String selQry="select mobileid,Name,price,quantity from mobiles";
		List<Mobile> mobilelist = new ArrayList<Mobile>();
		
		try{
			PreparedStatement ps=connection.prepareStatement(selQry);
			ResultSet rs=ps.executeQuery();
			
			while(rs.next())
			{
				Mobile mob=new Mobile();
				mob.setMobileID(rs.getInt(1));
				mob.setMobileName(rs.getString(2));
				mob.setPrice(rs.getDouble(3));
				mob.setQuantity(rs.getInt(4));
				mobilelist.add(mob);
			}
		}
		catch(SQLException e){
			throw new MobileException(e.getMessage());
		}
		
		return mobilelist;
		
		// TODO Auto-generated method stub
//		return null;
	}

	

	
	

}
