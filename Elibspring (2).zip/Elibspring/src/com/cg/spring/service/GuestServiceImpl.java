
package com.cg.spring.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.dao.IElibDao;
import com.cg.spring.entities.DocumentDetails;
import com.cg.spring.entities.User;

@Transactional
@Service
public class GuestServiceImpl implements IGuestService {
	@Autowired
	IElibDao dao;
	@Override
	public String displayName(String uname) {
		return dao.displayName(uname);
	}
	@Override
	public void updateGuestUserType(String id) {
		dao.updateGuestUserType(id);
		
	}
	@Override
	public DocumentDetails searchDocumentById(int id) {
		// TODO Auto-generated method stub
		return dao.searchDocumentById(id);
	}
	
	

}
