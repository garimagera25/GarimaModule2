package com.cg.spring.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.dao.IElibDao;
import com.cg.spring.entities.DocumentDetails;

@Transactional
@Service
public class EBillServiceImpl implements IEbillService{
	@Autowired
	IElibDao dao;
	@Override
	public String getUserType(String uname, String password) {
		// TODO Auto-generated method stub
		return dao.getUserType(uname, password);
	}
	@Override
	public DocumentDetails searchDocumentById(int id) {
		return dao.searchDocumentById(id);
	}

}
