package com.cg.spring.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.dao.IElibDao;
import com.cg.spring.entities.Disciplines;
import com.cg.spring.entities.DocumentDetails;
import com.cg.spring.entities.DocumentTypeDetails;

@Transactional
@Service
public class AdminServiceImpl implements IAdminService {
	@Autowired
	IElibDao dao;
	@Override
	public List<DocumentDetails> retrieveAllDocuments() {
		// TODO Auto-generated method stub
		return dao.retrieveAllDocuments();
	}
	@Override
	public DocumentDetails updateDoc(DocumentDetails docDetail) {
		return dao.updateDoc(docDetail);
		
	}
	@Override
	public DocumentDetails addDocumentDetails(DocumentDetails doc) {
		// TODO Auto-generated method stub
		return dao.addDocumentDetails(doc);
	}
	@Override
	public List<Disciplines> retrieveAllDisciplinesId() {
		// TODO Auto-generated method stub
		return dao.retrieveAllDisciplinesId();
	}
	@Override
	public List<DocumentTypeDetails> retrieveAllDocTypeId() {
		// TODO Auto-generated method stub
		return dao.retrieveAllDocTypeId();
	}

}
