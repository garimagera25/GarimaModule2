package com.cg.spring.service;

import com.cg.spring.entities.DocumentDetails;

public interface IEbillService {

	String getUserType(String uname, String password);

	DocumentDetails searchDocumentById(int id);

	

}
