package com.cg.spring.service;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

@Transactional
@Service
public class SubscriberServiceImpl implements ISubscriberService {

}
