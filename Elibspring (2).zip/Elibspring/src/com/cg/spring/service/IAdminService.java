package com.cg.spring.service;

import java.util.List;

import com.cg.spring.entities.Disciplines;
import com.cg.spring.entities.DocumentDetails;
import com.cg.spring.entities.DocumentTypeDetails;

public interface IAdminService {

	List<DocumentDetails> retrieveAllDocuments();

	DocumentDetails updateDoc(DocumentDetails docDetail);
	public DocumentDetails addDocumentDetails(DocumentDetails doc);
	List<Disciplines> retrieveAllDisciplinesId();
	List<DocumentTypeDetails> retrieveAllDocTypeId();

}
