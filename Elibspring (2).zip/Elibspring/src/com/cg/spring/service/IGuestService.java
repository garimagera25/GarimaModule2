package com.cg.spring.service;

import com.cg.spring.entities.DocumentDetails;
import com.cg.spring.entities.User;

public interface IGuestService {
	String displayName(String uname);
	void updateGuestUserType(String id);
	//void updateGuestUserType(User user);
	DocumentDetails  searchDocumentById(int id);
}
