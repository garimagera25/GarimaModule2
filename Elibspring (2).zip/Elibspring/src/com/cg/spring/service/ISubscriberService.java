package com.cg.spring.service;

public interface ISubscriberService {

}
