package com.cg.spring.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Min;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;
@Entity
@SequenceGenerator(name="document_id_seq", initialValue=1,allocationSize=2,sequenceName="documentid_seq")
@Table(name="Document_Details")
public class DocumentDetails {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="document_id_seq")
	@Column(name="Document_ID")
private int documentId;
	@NotEmpty(message="Document Name can not be blank")
	@Column(name="Document_Name")
private String documentName;
	@NotEmpty(message="Document Description can not be blank")
	@Column(name="Document_Description")
private String documentDescription;
	@Column(name="Document_Type_ID")
	private int documentTypeId;	
	@Column(name="Discipline_ID")
	private int disciplineId;
	@Column(name="Title")
	@NotEmpty(message="Title can not be blank")
private String title;
	@Column(name="Author")
	@NotEmpty(message="Author Name can not be blank")
private String author;
	@DateTimeFormat(pattern="dd/MM/yyyy")
	@Column(name="Upload_Date")
private Date uploadDate;
	@Min(0)
	@Column(name="Price")
private double price;

public DocumentDetails() {
	super();
	// TODO Auto-generated constructor stub
}
public int getDocumentId() {
	return documentId;
}
public void setDocumentId(int documentId) {
	this.documentId = documentId;
}
public String getDocumentName() {
	return documentName;
}
public void setDocumentName(String documentName) {
	this.documentName = documentName;
}
public String getDocumentDescription() {
	return documentDescription;
}
public void setDocumentDescription(String documentDescription) {
	this.documentDescription = documentDescription;
}


public int getDocumentTypeId() {
	return documentTypeId;
}

public void setDocumentTypeId(int documentTypeId) {
	this.documentTypeId = documentTypeId;
}

public int getDisciplineId() {
	return disciplineId;
}
public void setDisciplineId(int disciplineId) {
	this.disciplineId = disciplineId;
}



public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public String getAuthor() {
	return author;
}
public void setAuthor(String author) {
	this.author = author;
}

public Date getUploadDate() {
	return uploadDate;
}
public void setUploadDate(Date uploadDate) {
	this.uploadDate = uploadDate;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
@Override
public String toString() {
	return "DocumentDetails [documentId=" + documentId + ", documentName="
			+ documentName + ", documentDescription=" + documentDescription
			+ ", documentTypeId=" + documentTypeId + ", disciplineId="
			+ disciplineId + ", title=" + title + ", author=" + author
			+ ", uploadDate=" + uploadDate + ", price=" + price + "]";
}


}
