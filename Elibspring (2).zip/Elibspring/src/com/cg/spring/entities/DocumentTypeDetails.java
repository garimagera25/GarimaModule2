package com.cg.spring.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Document_Type_Details")
@SequenceGenerator(name="docType_id_seq", initialValue=1,allocationSize=9000,sequenceName="docTypeId_seq")
public class DocumentTypeDetails {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="docType_id_seq")
	@Column(name="Document_Type_ID")
	private int docTypeId;
	@Column(name="Document_Type_Name")
	private String docTypeName;
	public int getDocTypeId() {
		return docTypeId;
	}
	public void setDocTypeId(int docTypeId) {
		this.docTypeId = docTypeId;
	}
	public String getDocTypeName() {
		return docTypeName;
	}
	public void setDocTypeName(String docTypeName) {
		this.docTypeName = docTypeName;
	}
	@Override
	public String toString() {
		return "DocumentTypeDetails [docTypeId=" + docTypeId + ", docTypeName="
				+ docTypeName + "]";
	}
	
	
}
