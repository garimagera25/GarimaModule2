package com.cg.spring.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Disciplines")
@SequenceGenerator(name="disc_id_seq",initialValue=1,allocationSize=1004,sequenceName="discId_seq")
public class Disciplines {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="disc_id_seq")
	@Column(name="Discipline_ID")
private int discId;
	@Column(name="Discipline_Name")
private String discName;
	
	@Override
	public String toString() {
		return "Disciplines [discId=" + discId + ", discName=" + discName + "]";
	}
	public int getDiscId() {
		return discId;
	}
	public void setDiscId(int discId) {
		this.discId = discId;
	}
	public String getDiscName() {
		return discName;
	}
	public void setDiscName(String discName) {
		this.discName = discName;
	}
	
	
	
	
}
