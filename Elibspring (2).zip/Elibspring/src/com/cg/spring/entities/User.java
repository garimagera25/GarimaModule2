package com.cg.spring.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="User_Details")
public class User {
	@Id
	@Column(name="User_ID")
	private  String userId;
	@Column(name="First_Name")
	private String fname;
	@Column(name="Last_Name")
	private String lname;
	@Column(name="Date_Of_Birth")
	private Date dob;
	@Column(name="Address")
	private String address;
	@Column(name="Land_Line_Number")
	private String landline;
	@Column(name="Mobile_Number")
	private String mobno;
	@Column(name="Area_Of_Intrests")
	private String interest;
	@Column(name="Gender")
	private String gender;
	@Column(name="User_Type")
	private String userType;
	@Column(name="Date_Of_Registration")
	private Date rod;
	@Column(name="Password")
	private String password;
	
	
	@Override
	public String toString() {
		return "User [userId=" + userId + ", fname=" + fname + ", lname="
				+ lname + ", dob=" + dob + ", address=" + address
				+ ", landline=" + landline + ", mobno=" + mobno + ", interest="
				+ interest + ", gender=" + gender + ", userType=" + userType
				+ ", rod=" + rod + ", password=" + password + "]";
	}
	public String getLandline() {
		return landline;
	}
	public void setLandline(String landline) {
		this.landline = landline;
	}
	public String getMobno() {
		return mobno;
	}
	public void setMobno(String mobno) {
		this.mobno = mobno;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getInterest() {
		return interest;
	}
	public void setInterest(String interest) {
		this.interest = interest;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public Date getRod() {
		return rod;
	}
	public void setRod(Date rod) {
		this.rod = rod;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
}
