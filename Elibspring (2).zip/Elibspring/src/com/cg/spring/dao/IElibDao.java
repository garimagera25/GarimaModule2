package com.cg.spring.dao;

import java.util.List;

import com.cg.spring.entities.Disciplines;
import com.cg.spring.entities.DocumentDetails;
import com.cg.spring.entities.DocumentTypeDetails;
import com.cg.spring.entities.User;

public interface IElibDao {
	String getUserType(String uname, String password);

	String displayName(String uname);

	void updateGuestUserType(String id);
	DocumentDetails  searchDocumentById(int id);
	List<DocumentDetails> retrieveAllDocuments();
	
	DocumentDetails updateDoc(DocumentDetails docDetail);
	public DocumentDetails addDocumentDetails(DocumentDetails doc);
	List<Disciplines> retrieveAllDisciplinesId();
	List<DocumentTypeDetails> retrieveAllDocTypeId();
}
