package com.cg.spring.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.spring.entities.Disciplines;
import com.cg.spring.entities.DocumentDetails;
import com.cg.spring.entities.DocumentTypeDetails;
import com.cg.spring.entities.User;

@Repository
public class ElibDaoImpl implements IElibDao{
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public String getUserType(String uname, String password) {
		System.out.println("in dao impl"+uname+password);
		TypedQuery<String> query = entityManager.createQuery("select userType from  User user where user.userId=:username and user.password=:password" , String.class);
		query.setParameter("username", uname);
		query.setParameter("password", password);
		System.out.println("in dao class ");
		String userType =	query.getSingleResult();
		System.out.println("after getting "+userType);
		return userType;
	}
	
	@Override
	public String displayName(String uname) {
		User user = entityManager.find(User.class, uname);
		
		return user.getFname();	
	}
	
	
	
	@Override
	public void updateGuestUserType(String id){
		Query queryupdate = entityManager.createQuery("UPDATE User SET userType='subscriber' where userId=:uid");
		queryupdate.setParameter("uid", id);
		//queryupdate.setParameter("usertype", user.getUserType());
		queryupdate.executeUpdate();
		
		entityManager.getTransaction().commit();
		
		
	}

	@Override
	public DocumentDetails searchDocumentById(int id) {
		// TODO Auto-generated method stub
		DocumentDetails documentDetails = entityManager.find(DocumentDetails.class, id);
		return documentDetails;
	}

	@Override
	public List<DocumentDetails> retrieveAllDocuments() {
		TypedQuery<DocumentDetails> query= entityManager.createQuery("from DocumentDetails",DocumentDetails.class);
		List<DocumentDetails> dlist = query.getResultList();
		
		return dlist;
	}

	@Override
	public DocumentDetails updateDoc(DocumentDetails docDetail) {
		System.out.println("in dao"+docDetail.getAuthor());
		entityManager.merge(docDetail);
		entityManager.flush();
		return docDetail;
		
	}

	@Override
	public DocumentDetails addDocumentDetails(DocumentDetails doc) {
		entityManager.persist(doc);
		entityManager.flush();
		return doc;
		
	}

	@Override
	public List<Disciplines> retrieveAllDisciplinesId() {
		TypedQuery<Disciplines> query= entityManager.createQuery("from Disciplines",Disciplines.class);
		List<Disciplines> discIdlist = query.getResultList();
		
		return discIdlist;
	}

	@Override
	public List<DocumentTypeDetails> retrieveAllDocTypeId() {
		TypedQuery<DocumentTypeDetails> query= entityManager.createQuery("from DocumentTypeDetails",DocumentTypeDetails.class);
		List<DocumentTypeDetails> docTypeIdlist = query.getResultList();
		
		return docTypeIdlist;
	}
	
}
