package com.cg.spring.controller;
import java.text.ParseException;
import java.util.List;

import javax.validation.Valid;

import org.hibernate.loader.custom.Return;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.cg.spring.entities.Disciplines;
import com.cg.spring.entities.DocumentDetails;
import com.cg.spring.entities.DocumentTypeDetails;
import com.cg.spring.entities.User;
import com.cg.spring.service.IAdminService;
import com.cg.spring.service.IEbillService;
import com.cg.spring.service.IGuestService;
@Controller
public class LibController {
	
	@Autowired
	IAdminService adminService;
	@Autowired
	IGuestService guestService;
//	@Autowired
//	ISubscriberService subService;
	@Autowired
	IEbillService service;
	//IEbillService service = new EBillServiceImpl();
	@RequestMapping("/credentials")
	public String LoginUser(Model model,  @RequestParam("Uname") String Uname,@RequestParam("password") String password )

	{
		try{
		String userType= service.getUserType(Uname,password);
		User user =new User();
	    user.setUserId(Uname);
	    user.setPassword(password);
	    model.addAttribute("UserCredentials",user);
	   
		
			switch(userType.toLowerCase())
			{

			case "admin":
				return "Admin"; 
			case "guest":
				System.out.println("Controller user in guest id"+user.getUserId());
				String IdOfUser= guestService.displayName(Uname);
				model.addAttribute("fname",IdOfUser);
				return "Guest";
			case "subscriber":
				return "Subscriber";
			}//end of usertype switch

		return "Success";
		}catch (Exception e) {
			model.addAttribute("errorMsg",  "User is not registered with system");
			return "Error";
		}
		
	}
	@RequestMapping("/RegisterGuestPage")
	public String registerPage(Model model,@RequestParam("fname") String name)

		{
		model.addAttribute("name", name);	
		User UserCredentials=new User();
		model.addAttribute("UserCredentials",UserCredentials);
		return "RegisterGuest";
	}
	
	@RequestMapping("/registerGuest")
	public String registerGuestToSubscriber(Model model ,@RequestParam("name") String id)
	{
		
		System.out.println("controller checking value"+id);
		guestService.updateGuestUserType(id);
		return "Success";
	}
	@RequestMapping("/searchDocument")
	public String searchDocument(Model model,@RequestParam("id") int id)
	{
		DocumentDetails document =guestService.searchDocumentById(id);
		
		if(document!=null)
		{
			model.addAttribute("document",document);
			System.out.println("document is not null");
			return "SearchDocument";
		}
		else
		{
			System.out.println("document null and else part");
			model.addAttribute("errorMsg",  "Id doesnot exist");
			return "Error";
		}
		
		}
	@RequestMapping("/edit")
	public String editDocumentPage(Model model)
	{
		List<DocumentDetails> dlist = adminService.retrieveAllDocuments();
		model.addAttribute("dlist", dlist);
		
		return "EditPage";
	}
	
	@RequestMapping("/EditDocument")
	public String editDocumentPage(Model model,@RequestParam("documentId") int id ) 
	
	{
		
		DocumentDetails document = service.searchDocumentById(id);
		
       System.out.println("document in control"+document.getTitle());
		model.addAttribute("document",document);
		System.out.println("title"+document.getTitle());
		return "EditDocumentDetails";
	}
	
	@RequestMapping("/UpdateDocument")
	public String updateDocument(Model model , @Valid @ModelAttribute("document") DocumentDetails document,BindingResult result)
	{ 
		if(result.hasErrors())
		{
			return "EditDocumentDetails";
		}
		else
		{
			 adminService.updateDoc(document);
			    
				model.addAttribute("document",document);
				
				model.addAttribute("SuccessMsg", "Document with Id "+document.getDocumentId()+" Updated Successfully");
				return "Success";
		}
		
	   
	}
	
	@RequestMapping("/UploadPage")
	
	public String UploadPage(Model model)
	{
		DocumentDetails newdetails=new DocumentDetails();
		model.addAttribute("newdetails",newdetails);
		List<Disciplines> discIdlist = adminService.retrieveAllDisciplinesId();
		model.addAttribute("discIdlist", discIdlist);
		List<DocumentTypeDetails> docTypeId=adminService.retrieveAllDocTypeId();
		model.addAttribute("docTypeId", docTypeId);
		return "Upload";
	}
	@RequestMapping("/Upload")
	public String singleFileUpload(Model model, @Valid @ModelAttribute("newdetails") DocumentDetails newdocument, BindingResult result)
	{
		if(result.hasErrors())
		{
			List<Disciplines> discIdlist = adminService.retrieveAllDisciplinesId();
			model.addAttribute("discIdlist", discIdlist);
			List<DocumentTypeDetails> docTypeId=adminService.retrieveAllDocTypeId();
			model.addAttribute("docTypeId", docTypeId);

			return "Upload";
		}
		else
		{
			adminService.addDocumentDetails(newdocument);
			
			model.addAttribute("SuccessMsg", "Document with Id "+newdocument.getDocumentId()+" Inserted Successfully");
			return "Success";
		}
	    
		
	}
	
	
	
	
	
}
