var qArray=[["Bsc","BA","Bcom"],["Msc","MCA","MCom"]];
function populateQualification(){
var grad= frm1.graduation.value;
var qualification= frm1.qualification;
//var grad= document.getElementbyId("idofradiobutton").value;
if(grad=='UG')
{
for(i=0;i<qArray[0].length;i++)
{
var option = new Option();
option.text=qArray[0][i];
qualification.options[i]=option;
}
}
else
{
for(i=0;i<qArray[1].length;i++)
{
var option = new Option();
option.text=qArray[1][i];
qualification.options[i]=option;
}
}
}
function showData()
{
var win = window.open();
var username= frm1.username.value;
var dobStr= frm1.dob.value;
var contact= frm1.contact.value;
var useremail= frm1.useremail.value;
var graduation= frm1.graduation.value;
var qualification= frm1.qualification.value;


 var today = new Date();
 var dob = new Date(dobStr);
 var age = today.getYear()-dob.getYear();
 
win.document.write("<br/>Name:"+username);
win.document.write("<br/>dob:"+dob);
win.document.write("<br/>contact:"+contact);
win.document.write("<br/>useremail:"+useremail);
win.document.write("<br/>graduation:"+graduation);
win.document.write("<br/>age:"+age);
}