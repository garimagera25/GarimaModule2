function displayDetails()
{
var title=employeeForm.title.value;
var firstname=employeeForm.firstname.value;
var lastname=employeeForm.lastname.value;
var grosssalary=employeeForm.grosssalary.value;
if(grosssalary>0)
{
alert("All data for "+title+firstname+lastname+" entered successfully");
}
else
alert("gross salary should be positive no.")
}