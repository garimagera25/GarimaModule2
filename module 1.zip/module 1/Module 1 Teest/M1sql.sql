ANS1.
CREATE TABLE Departments (
Department_code	Number CONSTRAINT deptcode_PK PRIMARY KEY,
Department_Name		Varchar(15));
 
 ANS2.
 INSERT INTO Departments VALUES('10','Admin');
 INSERT INTO Departments VALUES('20','HR');
 INSERT INTO Departments VALUES('30','Finance');
 INSERT INTO Departments VALUES('40','Sales');
 INSERT INTO Departments VALUES('50','Marketing');
   
   
   Employees
   CREATE TABLE Employees (
Employee_code	Number CONSTRAINT empcode_PK PRIMARY KEY,
Employee_Name		Varchar(15),
Date_of_joining 	DATE,
Salary 				Number,
Grade               char(2),
Department_code		Number CONSTRAINT deptcode_fk REFERENCES Departments(Department_code));
   
   
   
INSERT INTO Employees VALUES('101','Preetam','10-Jan-2010','18000','A','20');
INSERT INTO Employees VALUES('102','AAkash','10-NOV-2005','48000','C','10');
INSERT INTO Employees VALUES('103','Kishore','19-DEC-2011','42000','C','40');
INSERT INTO Employees VALUES('104','Reena','23-JUN-2006','33000','B','20');
INSERT INTO Employees VALUES('105','Kailash','05-FEB-2004','36000','C','30');



query
q1.
SELECT Employee_code,Employee_Name,Salary FROM Employees where Employee_Name LIKE 'K%';
q2.

SELECT Grade,count(Employee_code) FROM Employees ORDER BY Grade;
Q3.

SELECT Employee_code,Employee_Name,Date_of_joining,Department_Name FROM Departments D1 ,Employees e1 WHERE D1.Department_code=e1.Department_code;



