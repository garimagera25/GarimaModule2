CREATE TABLE Gcustomer(
CustomerId number PRIMARY KEY,
Cust_Name varchar2(20) NOT NULL,
Address1 varchar2(30),
Address2 varchar2(30));

ALTER TABLE Gcustomer 
MODIFY (cust_name varchar2(30));


ALTER TABLE Gcustomer
ADD(Gender varchar2(1), Age Number(3),PhoneNo number(10), Email varchar2(30));


ALTER TABLE Gcustomer DROP COLUMN Email;

CREATE TABLE GAccountsMaster (
AccountNumber	Number(10,2) CONSTRAINT Acc_PK PRIMARY KEY,
CustomerId		Number(5) CONSTRAINT cust_id_fk REFERENCES Gcustomer(CustomerId),
AccountType		Char(3),
LedgerBalance	Number(10,2) Not Null);

ALTER TABLE GAccountsMaster add CHECK (AccountType='IND' OR AccountType='NRI');

ALTER TABLE GAccountsMaster add CONSTRAINTS Balance_Check CHECK (LedgerBalance>5000);


CREATE SEQUENCE seq_customer START WITH 1
INCREMENT BY 1;
 INSERT INTO Gcustomer VALUES(seq_customer.NEXTVAL,'Smith','46,LANE 1','New York','M','35','7890893433');
 INSERT INTO Gcustomer VALUES(seq_customer.NEXTVAL,'Jack','89,LANE 9','Washington','M','39','6690233433');
 INSERT INTO Gcustomer VALUES(seq_customer.NEXTVAL,'Mary','78,LANE 5','Chicago','F','32','8990893433');
 INSERT INTO Gcustomer VALUES(seq_customer.NEXTVAL,'James','46,LANE 8','New York','M','42','6690893123');
 
 CREATE SEQUENCE seq_AccountNumber START WITH 2001
INCREMENT BY 1;

UPDATE  GAccountsMaster SET AccountNumber=2001 WHERE AccountNumber=2003;

INSERT INTO GAccountsMaster VALUES(seq_AccountNumber.NEXTVAL,'1003','NRI','5001');
INSERT INTO GAccountsMaster VALUES(seq_AccountNumber.NEXTVAL,'1001','IND','7000');
INSERT INTO GAccountsMaster VALUES(seq_AccountNumber.NEXTVAL,'1000','IND','9000');
INSERT INTO GAccountsMaster VALUES(seq_AccountNumber.NEXTVAL,'1002','NRI','4000');


select * from GAccountsMaster;

SELECT Cust_Name,LedgerBalance FROM Gcustomer  c1 natural join GAccountsMaster a1 WHERE AccountType='IND';
OR
SELECT LedgerBalance FROM Gcustomer  c1 , GAccountsMaster a1 WHERE C1.CustomerId=a1.CustomerId AND Gender='M';
SELECT Cust_Name,LedgerBalance FROM Gcustomer  c1 natural join GAccountsMaster a1 WHERE Gender='M';

SELECT * FROM GAccountsMaster c1 natural join Gcustomer a1 WHERE Age<40;
