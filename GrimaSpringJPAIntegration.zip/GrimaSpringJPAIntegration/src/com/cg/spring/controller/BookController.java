package com.cg.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.spring.entities.Author;
import com.cg.spring.entities.BookDetails;
import com.cg.spring.service.BookService;



@Controller()
@RequestMapping("/book/")
public class BookController {
	@Autowired
	BookService service;
	
	@RequestMapping("/addBookPage")
	public String showAddBookPage(Model model){
		BookDetails book = new BookDetails();
		List<Author> list=service.getAuthorList();
		model.addAttribute("authorList",list);
		model.addAttribute("book",book);
		return "AddBookDetails";
	
	}
	
	@RequestMapping("/insertBook")
	public String insertBookRecord(Model model ,@ModelAttribute("book") BookDetails book)
	{
		BookDetails book1=service.addBookDetails(book);
		model.addAttribute("book",book1);
		model.addAttribute("successMsg", "Book Inserted Successfully with"+book1.getBookId());
		return "Success";
	}
	
	@RequestMapping("/getBookListPage")
	public String ShowBookList(Model model)
	{
		List<BookDetails> blist=service.getBookList();
		model.addAttribute("blist",blist);
		return "BookListPage";
	}
	
	@RequestMapping("showUpdateBookPage")
	public String showUpdatePage(Model model,@RequestParam("bookid") int bookid)
	{
		BookDetails book = service.getBookDetails(bookid);
		model.addAttribute("book",book);
		return "UpdateBook";
	}
	
	@RequestMapping("/updateBook")
	public String updateBookRecord(Model model,@ModelAttribute("book") BookDetails book)
	{
		service.updateBook(book);
		model.addAttribute("book",book);
		model.addAttribute("successMsg", "Book with"+book.getBookId()+"Updated Successfully");
		
		return "Success";
	}
	@RequestMapping("DeleteBookPage")
	public String removeBook(Model model,@RequestParam("bookid") int bookid)
			{
		BookDetails book = service.removeBook(bookid);
		model.addAttribute("book",book);
		model.addAttribute("successMsg", "Book deleted Successfully with "+bookid);
		return "Success";
			}
	
	
	
	
	
}
